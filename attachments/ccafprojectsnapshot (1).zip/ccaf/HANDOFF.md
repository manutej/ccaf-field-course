# HANDOFF — CCAF Exam-Prep

**Last updated:** 2026-08-01 ~20:15 UTC (Pulse 1 COMPLETE, at CP-1)
**Read CLAUDE.md first.** This file = current state + immediate next action.

## State
- [x] CP-0 approved by Manu (Pulse 1 only; Pulses 2–4 need re-approval; notebook approved in principle).
- [x] Extraction: 4 sonnet shards → extraction/part-{1..4}.md
- [x] W1 registry merge (live probe PASS) + W1-patch (scenario narratives; no domain overviews exist in source) → extraction/registry.{json,md}
- [x] W1R opus gate: FAIL → F-1..F-6 applied → re-verified **PASS-WITH-MINORS** (residuals F-7, F-8 minor, open) → extraction/W1R-review.md
- [x] W2p fable round 1: depth-4 operadic tree, 267 nodes (1 root / 5 L1 / 30 L2 / 60 L3 / 171 L4), 240/240 bullet coverage, 0 orphans, proportionality ±0.2pp, 12 sample-Qs mapped → question-tree/
- [x] W3a (coverage/fidelity, blinded): PASS-WITH-MINORS, 6 MINOR. W3b (operadic structure, blinded): PASS-WITH-MINORS, 5 MAJOR + 9 MINOR, 9 OC collapse tests executed (6 agree / 3 disagree at L0–L2, all fixed) → question-tree/reviews/
- [x] Fable round 2 (cap reached): ALL findings applied via build/ sources; answer_type colored edges added; scope-clamped OC protocol; 30 L2 slots made gradeable; gates clean. Changelog in question-tree/README.md.
- [x] Persistence scaffolding (CLAUDE.md, HANDOFF.md, planning/) created + committed to device at CP-1.
- [ ] **CP-1: Manu reviews the tree → approves Pulse 2 (noether-wiki + symmetry lines).**

## Next action (if resuming cold)
Await/confirm CP-1 verdict in DECISIONS.md. Then Pulse 2 per planning/META-PLAN.md: research agents sweep LATEST official Anthropic docs (docs.claude.com / anthropic.com) mapped to the 5 domains; noether-wiki extraction (nodes + typed edges, conservation discipline, official-URL citations + fetch timestamps + fallibility stamps); symmetry ledger (conserved invariants across corpus, guide-baseline vs live-docs partition). Then opus review. The tree's leaves define the wiki's demand ledger: wiki nodes must answer leaf questions.

## Pending / deferred
- W1R residuals F-7 (exercise Objective sentences), F-8 (Section 5 intro) — MINOR, fold into any later registry touch.
- Pulse 3 (field notebook, approved in principle) — gated on CP-2. Source skill: skills-attached/field-notebook-craft/SKILL.md + /root/.claude/skills/meta-notebook.
- Pulse 4 (persistence finalization + full device commit) — CP-4.
- NotebookLM 12-hr course via MCP — Manu provides later; drives wiki v2 enrichment.
- Tutor + exam-writer /meta-mvp — SPEC only this session.

## Fable round ledger (cap = 2/agent)
- Tree builder acd9f153ba350dc9f: 2/2 USED (build + revision). Any further tree edits → new agent or mechanical sonnet patches against build/ sources.
