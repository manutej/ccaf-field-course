# CCAF Operadic Question Tree (Pulse 1 / CP-1, round 2)

One typed, composable question tree mapping the complete conceptual question space of the
official CCAF exam guide (v1.0, July 2026). Canonical data source: `../extraction/registry.json`
(the guide's 5 domains, 30 task statements, 113 knowledge + 127 skills bullets, 6 scenarios,
12 sample questions, 18 in-scope / 16 out-of-scope topics). Built under /meta-prompting x
/operadic-interview x /meta-operad; round 2 applies both blinded reviews (W3a PASS-WITH-MINORS,
W3b PASS-WITH-MINORS conditional — all findings applied, see the changelog at the end).

## Files

| File | What it is |
|---|---|
| `tree.json` | THE canonical tree: `{meta, tree}` - root + 5 domains + 30 topics + 60 subtopics + 171 leaves (267 nodes). Programmatically merged; do not hand-edit (edit `build/d*.py`, re-run `build/build_all.py`). |
| `domain-{1..5}.json` | Each domain's full subtree (same node objects as tree.json). |
| `domain-{1..5}.md` | Readable indented tree: question + `▷` answer_slot + source (+ compose/oc for non-leaves); `->` marks the answer_type, `★` marks high-yield leaves. |
| `coverage-matrix.md` | (a) all-240-bullet -> node map, (b) sample Q1-12 -> leaf ids, (c) orphan ledger, (d) proportionality table, (e) non-commuting-pairs ledger. Generated, not hand-written. |
| `reviews/` | W3a (coverage/fidelity) and W3b (operadic structure) blinded round-1 reviews. |
| `build/` | Python sources: `d1.py..d5.py` (node content), `nodes_common.py` (constructor + invariant asserts), `build_all.py` (merge + gates + matrix generation). |

## Node schema

Every node at every level is a FULL ASKABLE QUESTION (operadic-interview's founding law:
node.askable - no category headers; all questions interrogative). Fields, all required:

- `id` - `D1` / `D1.T1` / `D1.T1.S1` / `D1.T1.S1.Q1` (level 1-4; root id `ROOT`, level 0)
- `question` - direct question in interview voice; scenario-invariant **across the scenarios
  listed in its `scenario_hooks`** (not claimed across all six - some concepts only live in
  entity-lookup or CI scenarios, and their questions rightly bind those nouns)
- `answer_type` - the named answer TYPE (the color of the edge to the parent, per
  operadic-interview `edge.typed` / meta-operad TREE). Bespoke at L0-L2 (e.g. root
  `() -> study-curriculum`, D2 `() -> competency-profile: tool-design-mcp`, D2.T2
  `() -> error-response-standard`); derived at L3 from the operator (AND->composite-doctrine,
  SEQUENCE->ordered-procedure, CASE-SPLIT->decision-rule-with-branches,
  TRADEOFF->arbitration-rule) and at L4 from difficulty (recall->fact-set,
  application->procedure-with-rationale, analysis->diagnosis-with-rationale), overridable.
  Composition is legal only when the composed children's colors support the parent's.
- `answer_slot` - 2-4 gradeable clauses a 100% answer must contain (the `▷` slot). At every
  level - including L1/L2 - each clause is a checkable proposition, not a topic label.
- `composition_rule` - `AND | SEQUENCE | CASE-SPLIT | TRADEOFF` + one line on how children's
  answers compose to this node's answer (`LEAF` for leaves). CASE-SPLIT rules must state
  branch precedence or exhaustiveness; SEQUENCE is used only where ALL children are
  order-bound (mixed nodes are AND with the internal ordering stated in the rule text).
- `oc_check` - the one-line collapse test for this node, always naming a SCOPED artifact or
  probe set and a registry clamp (see step 2.5 below)
- `source` - registry refs, e.g. `TS 4.3 K1,K3 S1` (bullet ordinals follow registry.md order);
  L1 cites domain+weight; L2 cites the whole task statement
- `scenario_hooks` - subset of SC1-SC6 where this question plausibly wears a scenario skin
- `difficulty` - `recall | application | analysis`
- `high_yield` - `★`: true on 60 leaves (1-2 per topic), seeded from the 12 official
  sample-question mappings in coverage-matrix (b); where a hurried candidate should spend
- `children` - subtree

## The composition algebra

The tree is a colored operad of questions (meta-operad TREE move). Each non-leaf node is a
many-in one-out operation: its children's answers are its inputs, its own answer the output.
The `composition_rule` operator states the algebra per node (round-2 census: AND 76,
SEQUENCE 9, CASE-SPLIT 10, TRADEOFF 1, LEAF 171 - every declared operator has >= 1 witness):

- **AND** - the parent's answer is the conjunction of the children's; dropping any child
  leaves the parent's answer incomplete. (Most nodes, including nodes whose children have a
  partial internal order - the order is then stated inside the rule text, e.g. D1.T1.S1.)
- **SEQUENCE** - ALL children compose in a stated order (pipeline, lifecycle-gate, runbook);
  reordering breaks the parent's answer. E.g. D4.T5.S2 (refine -> schedule -> handle
  failures), D5.T5.S1 (validate-before-automation -> sample-after).
- **CASE-SPLIT** - children are branches of a decision rule; the parent's answer is the
  discriminator plus the branch answers plus a stated precedence/exhaustiveness clause
  (branches are not assumed disjoint - the rule must say what dominates when they overlap,
  e.g. D3.T4.S1: architectural decisions dominate raw file count).
- **TRADEOFF** - children valuate opposing goods; the parent's answer is the arbitration
  rule. Sole witness: **D2.T3.S1** - coordinator purity vs latency, arbitrated by the
  scoped-tool compromise. (D1.T6, formerly mislabeled TRADEOFF, is AND over two orthogonal
  decomposition axes - reviewed and retyped in round 2.)

Sequential associativity: composing D1.T1.S1's leaves into S1 and then S1+S2 into T1 gives the
same T1 answer as composing all seven leaves at once. Parallel associativity: sibling subtrees
with disjoint sources may be studied/verified in any order. Cross-topic (L2) source
disjointness is verified ZERO-violation, so the licence holds unconditionally at topic level.
Within topics, 6 bullets couple sibling L3 subtrees (`TS 1.1 K3`, `TS 1.2 K4`, `TS 1.5 K3`,
`TS 1.7 K4`, `TS 4.2 S3`, `TS 4.5 K4` - ledgered in coverage-matrix (e)); for those pairs the
any-order licence must be checked, not assumed.

Root algebra (round 2): the root's four answer_slot clauses are exactly the AND of the five
domain answers (clause 1 <- D1, 2 <- D2, 3 <- D3, 4 <- D4∧D5). Tree-level QA properties
(240/240 bullet reachability, out-of-scope guard, hook-bounded scenario invariance) are NOT
root answer clauses - they live in `tree.json` `meta.tree_invariants` and are verified by
coverage-matrix.md and the W3a review, which is what the root's composition_rule says.

## How to run an OC collapse test (the verification invariant)

For any non-leaf node X (meta-operad COLLAPSE/CHECK, Tier 1 = 2 executions):

1. **Collapsed run:** ask X's `question` directly (fresh context, no children shown). Record
   the answer against X's `answer_slot`.
2. **Composed run:** answer each child's `question` independently, then combine per X's
   `composition_rule`.
2.5. **Clamp (mandatory):** the collapsed run is scored only against the guide's bullet set
   for this node's `source`. Content the cold answer adds that no cited bullet covers is
   **residue**, reported separately as a scope note, NOT as a disagreement. A disagreement is
   a clause the cold answer contains that a cited bullet DOES cover and no child produces -
   or a child-composed clause the clamped cold answer rejects. (Every oc_check in the tree
   names a scoped artifact and carries this clamp; the generic "cold-answer a general
   engineering question" probe style is banned by a build gate. Worked contrast from the
   round-1 review: D2.T2's scoped probe passed cleanly while unscoped domain probes
   false-failed on out-of-guide residue like monitoring and evals.)
3. **Compare** using X's `oc_check` line (each oc_check names the concrete agreement test,
   often with a small probe set, e.g. "classify these four tasks both ways").
4. **Agreement** -> elevated confidence in that subtree; **disagreement** -> a FINDING: name
   the node, quote both answers, localize which child edge broke (the inconsistency kernel).
   Never silently prefer either answer.

Round-1 execution record (W3b): 9 collapses run. All 4 L3 tests agreed on their full probe
sets (including both builder-flagged CASE-SPLITs, 4/4 each). The 3 disagreements sat at
L0-L2 and each traced to a protocol defect (root outside its algebra, no scope clamp, no
gradeable L2 slot) - all three repaired in round 2, not to a decomposition defect. Standing
caveat: consistency is calibration, not correctness - an OC pass does not prove an
answer_slot is faithful to the registry; that is W3a's separate fidelity lens.

## How the tree drives downstream artifacts

- **Scenario generation:** pick a scenario SC1-SC6, filter leaves by `scenario_hooks`, and
  re-skin each leaf's question with the scenario's nouns (tools, agents, documents). The
  answer_slot is unchanged by re-skinning within the leaf's hooked scenarios.
- **Tutor:** traverse by weight order (D1, D3, D4, D2, D5), `★` (high_yield) leaves first;
  quiz leaves; on a miss, climb to the parent and run its OC check (the parent's L2 slots are
  gradeable propositions, so the climb has something to grade against) to find whether the
  miss is local (one leaf) or structural (a broken compose). `difficulty` drives
  spaced-repetition ordering (recall first).
- **Exam-writer:** each leaf + its answer_slot is a stem+key seed; distractors come from the
  rejected branches of CASE-SPLIT siblings and the named anti-patterns in answer_slots (the
  registry's sample questions confirm this distractor style - W3a verified 4/4 sampled
  official questions are fully anticipated including every distractor rejection).
  coverage-matrix (b) shows the 12 worked precedents; those leaves are the `★` seed set.
- **Noether-wiki (Pulse 2):** wiki nodes attach to L3 subtopics via `source`; a symmetry line
  that spans multiple subtopics is a candidate conserved invariant.

## Node stats (from tree.json meta, verified by build_all.py)

- Nodes by level: L0 1, L1 5, L2 30, L3 60, L4 171 - total 267 (unchanged in round 2).
- Operator census: AND 76, SEQUENCE 9, CASE-SPLIT 10, TRADEOFF 1, LEAF 171.
- High-yield leaves: 60 (1-2 per topic, gate-enforced).
- L2 answer_slot clauses: 89, median 141 chars, min 81 - zero bare labels (round-1 medians
  were 46 chars with 66% bare labels; W3b MAJOR-3 closed).
- Leaves by domain vs weight: D1 46 (26.9% vs 27%), D2 31 (18.1% vs 18%), D3 34 (19.9% vs
  20%), D4 34 (19.9% vs 20%), D5 26 (15.2% vs 15%) - all within +/-5pp (well within +/-1pp).
- Bullet coverage: 240/240 (113 K + 127 S) cited by >= 1 L3/L4 node; 0 orphans; 0 phantom
  citations. Independently re-derived by W3a: all 240 matrix rows reproduce exactly from the
  tree's source fields under an independent parser.
- Sample questions: all 12 mapped to existing leaves (1-3 leaves each), coverage-matrix (b);
  W3a spot-verified Q1/Q3/Q9/Q11 fully anticipated, distractors included.
- Out-of-scope guard: no leaf requires any of the 16 out-of-scope topics (W3a Check 5:
  267-node keyword sweep, 2 adjudicated hits, both in-scope). Auth and cost appear only as
  the guide's own bullet facts - env-var expansion in `.mcp.json` (`TS 2.4 K2/S1`) and the
  Batch API's 50% savings (`TS 4.5 K1`) - never as authentication protocols, key rotation,
  or pricing calculations. Prompt caching appears only as `TS 3.5 S3`'s own 'cache
  invalidation' example and as a rejected sample-Q9 distractor. Streaming, tokenization,
  embeddings, vision, computer use, fine-tuning, cloud configuration, and benchmarking
  appear nowhere.

## Known shortfalls (honest ledger, round-2 revision)

1. **Bullet ordinals are positional, not quoted.** `TS 4.3 K1` means "1st knowledge bullet of
   TS 4.3 in registry.md order". W3a verified the two registry renderings agree (240/240
   bullet texts match in order) and semantically audited 34 leaves (19.9%): 33/34 TEST their
   cited bullets; the one partial (TS 5.1 K3 disclosed in a stem) was repaired in round 2.
   The remaining ~80% of leaves carry author-judged fidelity, unreviewed.
2. **A few bullets share a leaf with siblings rather than owning one.** E.g. `TS 5.1 S5`
   (subagent metadata) is the third required clause of `D5.T1.S2.Q2` rather than a standalone
   leaf, and `TS 1.2 K2` (isolated context) is the headline clause of `D1.T2.S1.Q2` (the same
   invariant recurs independently at `D1.T3.S2.Q1` under `TS 1.3 K2`). Reviewed W3a round 1:
   each such bullet is separately scored within its leaf, so an item targeting it head-on is
   still answerable. The residual risk is that these bullets get less drill time than
   leaf-owning bullets.
3. **OC coverage is partial.** 9 of 96 non-leaf collapse tests have been executed (W3b round
   1); the L0-L2 protocol defects they exposed are repaired, but the repaired probes and the
   other 87 nodes have not been re-run. The compose rules remain asserted-plus-spot-verified,
   not fully verified.
4. **Difficulty labels are author-estimated** (mix: recall ~18%, application ~55%, analysis
   ~27%) and uncalibrated against real item difficulty. The L4 answer_type derivation
   inherits this: a mislabeled difficulty mislabels the leaf's color.
5. **Scenario_hooks are plausibility judgments**, seeded from the registry's scenario ->
   primary-domain mapping but extended by content affinity. Hooks are a generation aid, not a
   claim the guide pairs that leaf with that scenario. 103/171 leaves carry exactly one hook.
6. **`max_tokens`** appears in the guide's "technologies and concepts that might appear" list
   but in none of the 240 task-statement bullets. Round 2 added it as a slot clause on
   `D1.T1.S1.Q1` (request-shaping fields the loop controls), closing the tree's only known
   guide-wide blind spot (W3a MINOR-6). Every other item on that list is reachable.

## Regenerating

```bash
cd /home/claude/work/ccaf/question-tree/build && python3 build_all.py
```

Edits go in `build/d{1..5}.py`; `build_all.py` re-derives every other generated file and
re-runs all gates: structure and breadth, typed compose operators, TRADEOFF witness count,
CASE-SPLIT precedence clauses, interrogative questions, no `Can you` stems at L0-L2, no
unclamped generic cold probes, answer_type presence, gradeable L2 clauses (>= 55 chars),
high-yield 1-2 per topic, 240-bullet coverage, phantom citations, sample-Q map integrity,
proportionality, and the non-commuting-pairs ledger. Treat the print output as the lint
report; a regeneration with any `PROBLEM:` line is a failed regeneration.

**Breadth deviation (documented, W3b MINOR-2):** operadic-interview's `treelint.py` expects
3-5 children per node; this tree runs 2 subtopics per topic (all 30) and 2-4 leaves per
subtopic, because task statements bisect naturally into knowledge-side and skills-side
clusters, and L1 breadth equals each domain's task-statement count (D1: 7, exceeding the
skill's 3-6 GROW guidance). The relaxed bounds are enforced explicitly by `build_all.py`
(L1 exact per-domain count, L2 2-5, L3 2-4). W3b verified the bisection did not produce thin
nodes (median parent-child content overlap 0.098; all 8 deep-read L3 nodes genuinely
decompose). **Linter supersession (W3b MINOR-4):** `treelint.py` cannot parse these `.md`
renderings (different node format); its checks are superseded by the bespoke gates above,
which cover node.askable (interrogative gate), compose.stated (operator gate), edge.typed
(answer_type gate), and ★ economy (high-yield gate) mechanically. The `▷` and `★` glyphs now
render in the `.md` files.

## Round 2 changelog (reviewer finding -> change)

All fixes were made in `build/` sources and regenerated; no generated file was hand-edited.
Node counts unchanged (267); leaf counts per domain unchanged; all round-1 quantitative
guarantees re-verified after the edits (0 orphans, 240/240, proportionality OK, sample-Q map
valid, JSON parses).

**W3b MAJORs**
- **M1 (root outside its algebra):** root answer_slot rewritten to four clauses that ARE the
  AND of the domain answers (1<-D1, 2<-D2, 3<-D3, 4<-D4∧D5); the three QA clauses moved to
  `meta.tree_invariants`; composition_rule and oc_check restated accordingly (`build_all.py`).
- **M2 (no scope clamp; 18 unpassable probes):** README OC protocol gained step 2.5 (clamp +
  residue rule); all 18 flagged oc_checks rewritten to scoped-artifact form with explicit
  registry clamps (ROOT; D1-D5; D1.T4; D2.T1.S1; D2.T5; D3.T1.S1; D3.T4; D4.T1; D4.T2.S1;
  D4.T2; D4.T4; D4.T6.S1; D5.T4; D5.T5; D5.T6) plus 2 more the new build gate caught
  (D3.T5.S1, D4.T6); the `Cold-answer '...'`/`Cold-define` pattern is now gate-banned.
- **M3 (58 bare-label L2 clauses):** all 30 L2 answer_slots rewritten as checkable
  propositions at the L3 register; measured after rewrite: median 141 chars, min 81, zero
  bare labels; gate added (>= 55 chars per L2 clause).
- **M4 (no edge colors; bool stems):** `answer_type` field added to the schema - bespoke at
  L0-L2, derived palette at L3 (by operator) and L4 (by difficulty), documented in
  `meta.answer_type_palette_note`; all 35 `Can you ...?` stems at L1/L2 rewritten as
  content-typed questions; gates added (answer_type presence; no `Can you` at L0-L2).
- **M5 (TRADEOFF had zero witnesses):** D1.T6 retyped AND (orthogonal axes, per the
  reviewer's analysis); D2.T3.S1 retyped TRADEOFF with a genuine opposing-goods arbitration
  rule (purity vs latency -> scoped-tool compromise); README operator definition updated to
  cite D2.T3.S1; gate added (TRADEOFF witness count >= 1).

**W3b MINORs**
- **m1 (SEQUENCE mislabels):** all 14 round-1 SEQUENCE nodes audited; 5 retyped AND with
  internal ordering stated (D1.T1.S1, D1.T4.S2, D1.T5.S2, D2.T5.S2, D5.T4.S2); 2 reworded to
  state what is order-bound (D3.T4.S2 phase order, D5.T5.S1 lifecycle order); 7 kept as
  genuine sequences. Census now SEQUENCE 9.
- **m2 (breadth off-spec, D1's 7 unchecked):** deviation documented above; L1 breadth gate
  added (exact per-domain task-statement count).
- **m3 (zero ★):** `high_yield` field added; 60 leaves marked (2 per topic), seeded from the
  sample-question map; 1-2-per-topic gate added; ★ rendered in `.md`.
- **m4 (treelint unusable, no ▷):** supersession documented above; `▷`/`★` now emitted in
  the `.md` renderings.
- **m5 (CASE-SPLIT disjointness unproven):** all CASE-SPLIT rules now carry an explicit
  precedence or exhaustiveness clause (incl. D3.T4.S1's "architectural decisions dominate
  file count" probe case); gate added.
- **m6 (7 shared bullets):** non-commuting-pairs ledger added as coverage-matrix (e) and
  `meta.non_commuting_bullets_within_topic`; now 6 pairs (the W3a-MINOR-3 source narrowing
  of D1.T7.S2.Q3 removed `TS 1.7 K1` from the set); cross-topic sharing verified 0.
- **m7 (D4.T4.S1 mistyped):** rule retyped `AND{ mechanics(Q1); CASE-SPLIT fixable vs
  unfixable; grounded by Q3 }` per the reviewer's honest shape.
- **m8 (12 imperative stems):** all 12 converted to interrogatives; endswith-`?` gate added
  over all 267 nodes.
- **m9 (scenario-invariance overclaimed):** README schema line and the former ROOT clause
  softened to "scenario-invariant across the scenarios listed in `scenario_hooks`" (the ROOT
  clause now lives in `meta.tree_invariants` with the softened wording).

**W3a MINORs**
- **MINOR-1 (TS 5.1 K3 disclosed in stem):** `D5.T1.S2.Q1` stem rewritten to elicit the cost
  mechanism; fourth slot clause added carrying K3's disproportionality content.
- **MINOR-2 (D4.T4.S2.Q3 cites K3 without testing it):** reviewer's option (b) applied -
  clause added naming detected_pattern as the feedback loop's instrument; citation now honest.
- **MINOR-3 (D1.T7.S2.Q3 4-bullets/2-slots):** source narrowed to `TS 1.7 K2,K4`; third slot
  added naming the three concrete mechanisms (--resume <name>, fork_session, fresh+summary).
- **MINOR-4 (stale shortfall item 2):** replaced with the reviewer's accurate statement
  (see Known shortfalls 2); the wrong `D1.T3.S2.Q1`-carries-`TS 1.2 K2` attribution removed.
- **MINOR-5 (out-of-scope guard overstatement):** reworded per the reviewer's text (see Node
  stats); "auth/pricing never appear" claim corrected to the bullet-fact-only statement.
- **MINOR-6 (max_tokens gap):** option (a) applied - slot clause added to `D1.T1.S1.Q1`;
  gap-closure recorded in Known shortfalls 6.
