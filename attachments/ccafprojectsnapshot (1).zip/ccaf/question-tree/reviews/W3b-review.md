# W3b — Operadic-structure review of the CCAF question tree

**Reviewer:** W3b (blinded; operadic/type lens only — coverage & source-fidelity are W3a's lens)
**Artifacts:** `question-tree/tree.json` (267 nodes), `domain-{1..5}.md`, `README.md`, `build/*.py`
**Method sources:** `/root/.claude/skills/operadic-interview/SKILL.md`, `/root/.claude/skills/meta-operad/SKILL.md`
**Date:** 2026-08-01

**VERDICT: PASS-WITH-MINORS (conditional).** The *decomposition* is sound and passes every
structural test I ran. The *verification layer above L3* — the whole point of the operadic
upgrade — is not executable as shipped. 0 BLOCKER / 5 MAJOR / 8 MINOR.
**Collapse tests executed: 9. Agreed on content: 6. Disagreed: 3. Rule-malformed: 2 (overlaid on
agreeing nodes).**

---

## CHECK 1 — OC collapse tests EXECUTED (9 nodes, L0→L3)

Protocol per README lines 58–68 and meta-operad move 3/4 (Tier 1: collapsed run vs composed run,
compared by the node's own `oc_check`). Derivations abbreviated where noted; abbreviation is
honest — no step omitted that changes the verdict.

### T1 — `ROOT` (L0, AND) → **DISAGREE**

> `"composition_rule": "AND (weighted): the root is answered iff every domain question is answered; domain weights order study effort and set leaf-count proportionality, not answer precedence."`
> `"oc_check": "Answer 'what must I master for CCAF?' cold from the exam metadata alone; the five competencies it names must be exactly the five domain children, with no sixth competency and none missing."`

**Collapsed run** (cold, from exam metadata alone): five competencies — agentic architecture &
orchestration; tool design & MCP integration; Claude Code configuration & workflows; prompt
engineering & structured output; context management & reliability. Exactly five, none missing.

**Composed run** (AND over D1..D5): the same five, verbatim.

**Verdict on the *stated* oc_check: agree — but the check is a rubber stamp.** meta-operad names
this failure explicitly: *"OC as a rubber stamp — running only collapses you expect to agree…
The informative collapses are the structurally different ones."* The root's children ARE the
guide's five domains, so this probe cannot fail.

**The informative collapse disagrees.** Compose D1∧D2∧D3∧D4∧D5 and compare against the root's
full `answer_slot`:

| ROOT answer_slot clause | produced by AND over children? |
|---|---|
| "mastery of all five domain-level competency questions, weighted D1 27 / D3 20 …" | YES |
| "every knowledge and skills bullet of the 30 task statements reachable through some leaf" | **NO** — no child node asserts anything about bullet reachability |
| "all answers scenario-invariant: correct under any of the six scenario skins" | **NO** — no D1..D5 answer_slot mentions scenario-invariance |
| "nothing out-of-scope required anywhere in the tree" | **NO** — no child; this is a property of the *artifact*, not an answer |

3 of 4 root slot clauses have **no child source**. Under the stated AND rule the composed answer
is a strict subset of the collapsed one. This is a failure of meta-operad's COMPOSE witness
(*"the tree is well-formed iff composing all nodes reproduces the root task"*) at the single most
load-bearing edge. Root cause: the root's answer_slot mixes two colors — a *competency* answer
(clause 1) and three *QA assertions about the tree*. → **MAJOR-1.**

### T2 — `D5` (L1 DOMAIN, AND) → **DISAGREE** (rule-malformed probe)

> `"oc_check": "Cold-answer 'what makes a Claude system reliable in production over time?'; every property must trace to exactly one topic's composed answer."`

**Collapsed run** (cold, honestly unfiltered as README step 1 demands — *"fresh context, no
children shown"*): (a) context managed so critical facts survive long conversations; (b)
calibrated escalation to humans + clarification on ambiguity; (c) structured error propagation
and honesty about coverage gaps; (d) recoverable long-running exploration; (e) sampled/calibrated
human review of automated output; (f) provenance and conflict/staleness handling; **(g)
monitoring & observability; (h) eval suites and regression testing; (i) latency/cost budgets;
(j) prompt-injection and safety guardrails; (k) prompt/model version pinning.**

**Composed run:** T1→(a), T2→(b), T3→(c), T4→(d), T5→(e), T6→(f).

**Comparison:** (a)–(f) trace 1:1. **(g)–(k) trace to nothing.** The oc_check as written —
"*every* property must trace to *exactly one* topic" — therefore FAILS for any competent cold
answerer. The defect is in the probe, not the subtree: the collapsed run answers a
*domain-general engineering* question while the composed run answers an *exam-guide-scoped*
question. Different colors on the two sides of the comparison; meta-operad calls this out
directly — *"Type the probes themselves. A :css-typed predicate answered from :page_text passed a
failing page. Ill-typed grafts are illegal for audit instruments too."*

This is not one bad node: **18/96 non-leaf oc_checks use the `Cold-answer '<general question>'`
pattern, including all 5/5 L1 domain nodes.** The entire domain layer has no executable OC gate.
→ **MAJOR-2.**

### T3 — `D1.T6` (L2, TRADEOFF — the tree's ONLY TRADEOFF) → **AGREE on content / RULE-MALFORMED**

> `"composition_rule": "TRADEOFF: both subtopics trade structure against adaptivity/focus; the topic answer is the meta-rule 'decompose along the axis where quality degrades' with S1 covering predictability and S2 covering attention scale."`
> `"oc_check": "State the meta-rule cold, then verify each subtopic's composed answer is a special case of it (predictability axis, attention axis) with no residue."`

**Collapsed run** (cold meta-rule): *decompose along the axis on which a single pass degrades* —
if it degrades because the steps cannot be known in advance, decompose adaptively; if it degrades
because attention spreads thin over many items, split into passes (per-item + integration).

**Composed run:** S1 = predictability axis (fixed chain vs dynamic; wrong-choice symptoms).
S2 = attention axis (per-file + integration passes; dilution symptoms; scale threshold). Both are
special cases of the cold meta-rule; residue = none.

**Content verdict: AGREE.** **Rule verdict: MALFORMED.** README defines the operator as
*"TRADEOFF — children valuate opposing axes; the parent's answer is the meta-rule that arbitrates
them (used where the exam tests judgment between two goods, e.g. D1.T6)."* S1 and S2 here are
**orthogonal and jointly applicable**, not opposing goods: an adaptive plan can *also* be
pass-split, and nothing is arbitrated. The rule text's own words — *"both subtopics trade
structure against adaptivity/focus"* — are false of S2, which trades breadth against depth within
one pass, not structure against adaptivity. The correct operator is AND over two independent
decomposition axes. Since D1.T6 is the sole TRADEOFF in 267 nodes **and** README's defining
example of it, the TRADEOFF operator has **zero valid witnesses in the algebra.** → **MAJOR-5.**

### T4 — `D3.T4.S1` (L3, CASE-SPLIT — builder-flagged) → **AGREE (4/4)**

> `"oc_check": "Cold-classify: microservice restructure, 45-file migration, one-line date validation, stack-trace bug fix; the composed classifier must agree on all four."`

**Collapsed run** (cold): plan mode when the task is large-scale/multi-file, carries architectural
decisions, or admits multiple valid approaches; direct execution when the change is simple,
single-file, and its cause is clear; deferral is wrong because complexity known at decision time
must be consumed at decision time, and early direct edits create partial state that constrains
the later plan. → restructure **plan**, 45-file migration **plan**, date validation **direct**,
stack-trace fix **direct**.

**Composed run:** Q1 supplies the plan branch + its payoff (safe exploration before commitment);
Q2 supplies the direct branch + its criterion (*"scoping clarity, not file count alone"*); Q3
supplies the no-deferral rule. Classifier = complexity discriminator + both branches.
→ restructure **plan** (Q1 verbatim), migration **plan** (Q1 scale), date validation **direct**
(Q2 verbatim), stack-trace fix **direct** (Q2 clarity criterion).

**4/4 agreement. AGREE.** *Caveat (MINOR-5):* the branches are not provably disjoint. Probe
"rename one symbol across 45 files": Q1's scale discriminator says plan, Q2's clarity criterion
says direct. README claims *"Disjoint branches commute (parallel associativity)"* — that licence
needs a stated precedence to hold here.

### T5 — `D4.T4.S1` (L3, CASE-SPLIT — builder-flagged) → **AGREE (4/4)**

> `"oc_check": "Cold-triage four validation failures (bad date format, missing-from-source field, sum mismatch, malformed JSON) into retry/no-retry/cannot-happen; must match the children's composition."`

**Collapsed run** (cold): retry payload = original document + failed extraction + the specific
validation errors; retries fix format/structural errors; they cannot supply information absent
from the source; with tool use + strict schemas, syntax errors do not occur, so the loop exists
for semantic errors. → date format **retry**, missing-from-source **no-retry**, sum mismatch
**retry** (semantic), malformed JSON **cannot-happen**.

**Composed run:** Q1 = the three payload components + why each; Q2 = the unfixable class (info
absent) + stop signal; Q3 = semantic-vs-syntax taxonomy, syntax eliminated by tool use.
→ date format **retry** (¬Q2 + Q1), missing-from-source **no-retry** (Q2 verbatim), sum mismatch
**retry** (Q3 lists *"values that do not sum"* as the loop's responsibility), malformed JSON
**cannot-happen** (Q3 verbatim).

**4/4 agreement, and the test is genuinely informative** — the `cannot-happen` bucket is
unreachable without Q3, so the composed run could have failed. **AGREE.**
*Caveat (MINOR-7):* the rule is typed CASE-SPLIT but Q1 is *mechanics*, not a branch. Honest
shape: `AND{ mechanics(Q1), CASE-SPLIT{fixable(¬Q2), unfixable(Q2)} grounded-by Q3 }`.

### T6 — `D2.T1.S2` (L3, CASE-SPLIT) → **AGREE (3/3)**

> `"oc_check": "Cold-fix a toolset with analyze_content/analyze_document plus a do-everything analyze_document; the moves must match the children's composed case-split."`

**Collapsed run:** (i) rename `analyze_content` → `extract_web_results` with a domain-specific
description; (ii) split the do-everything `analyze_document` into purpose-specific tools each with
its own I/O contract; (iii) do **not** consolidate — these are genuinely distinct capabilities.
**Composed run:** Q1 = the rename branch; Q2 = the split branch; Q3 = the consolidation criterion,
which here returns "no". **3/3 moves match, including the negative branch. AGREE.** Best-formed
CASE-SPLIT I tested: three mutually exclusive overlap types, and the probe exercises two branches
plus the refutation of the third.

### T7 — `D1.T1.S1` (L3, SEQUENCE) → **AGREE on content / RULE-MALFORMED**

> `"composition_rule": "SEQUENCE: children trace the lifecycle in execution order (send/inspect -> branch on stop_reason -> append results -> model re-reasons); composing them in order reproduces the full iteration narrative."`

**Collapsed run** (one narrative): send request with tools → read `stop_reason` → if `tool_use`,
execute the requested tools, append `tool_result` into the history, resend the whole conversation
→ model reasons over the appended results and either calls more tools or finishes → if
`end_turn`, stop and present.
**Composed run:** Q1 (steps + `stop_reason` as sole continuation signal) → Q2 (obligations of each
value, failures if swapped) → Q3 (why results must be appended) → Q4 (what the next decision is
conditioned on). Same loop, same branch points. **AGREE.**

**Rule verdict: MALFORMED.** README: *"SEQUENCE — children compose in a stated order …
**reordering breaks it**."* Falsified here: only Q1 narrates the sequence; Q2, Q3, Q4 are
counterfactual/rationale questions *about* steps 2–4. Swap Q3 and Q4 and the parent's answer is
unchanged. The real shape is `AND{ sequence(Q1), rationale(Q2,Q3,Q4) }`. → **MINOR-1** (recheck
the other 13 SEQUENCE nodes; e.g. `D5.T5.S1` — *"Why do aggregate accuracy metrics deceive…"* —
is not a lifecycle at all).

### T8 — `D2.T2` (L2, AND) → **AGREE**

> `"oc_check": "Cold-write the error-handling section of an MCP tool spec; every requirement must trace to one subtopic's composition."`

**Collapsed run** (abbrev.): structured errors with `isError`; four categories (transient /
validation / business / permission); `isRetryable` + human-readable description; distinguish
"valid empty" from "failed"; enough context for the agent to choose a recovery; no generic
"Operation failed"; customer-safe explanations on business violations; subagents retry transient
locally, propagate only unresolvables with partials.
**Composed run:** S1 = taxonomy + field contract + business specialization; S2 = uniform-error
failure analysis + empty-vs-failure + local-vs-propagate. Every collapsed requirement traces.
**AGREE.** Residue: only "backoff/retry delay" (not a guide bullet — TS 2.2 K1–K4, S1–S4 do not
mention it). The probe is *scoped to an artifact* ("an MCP tool spec"), which is exactly why it
survives where D5's unscoped probe fails — this is the proof of the MAJOR-2 fix.

### T9 — `D3.T2` (L2, AND) → **DISAGREE (residue)** — same kernel as T2

> `"oc_check": "Cold-spec a team skill from scratch (location + full frontmatter); the spec must decompose exactly into the two subtopics' composed answers."`

**Collapsed run:** `.claude/skills/<name>/SKILL.md`, version-controlled; frontmatter `name`,
`description`, plus `context: fork`, `allowed-tools`, `argument-hint`.
**Composed run:** S1 = location/scoping; S2 covers **only** `context: fork`, `allowed-tools`,
`argument-hint` (`D3.T2.S2` slot, verbatim). `name`/`description` decompose into **nothing**.
Against the word "**exactly**", this DISAGREES.

I verified the cause against the registry: `TS 3.2 K2` reads *"Skills in .claude/skills/ with
SKILL.md files that support frontmatter configuration including context: fork, allowed-tools, and
argument-hint"* — the guide itself omits `name`/`description`. So the residue is out-of-guide,
not a coverage gap. **The tree is right and the OC test is wrong**, which is precisely MAJOR-2:
the protocol has no *scope clamp* and no *residue rule*.

### Tally

| node | level | operator | content verdict | rule verdict |
|---|---|---|---|---|
| ROOT | 0 | AND | **DISAGREE** | ok |
| D5 | 1 | AND | **DISAGREE** | probe ill-typed |
| D1.T6 | 2 | TRADEOFF | AGREE | **MALFORMED** |
| D2.T2 | 2 | AND | AGREE | ok |
| D3.T2 | 2 | AND | **DISAGREE** | probe unclamped |
| D3.T4.S1 | 3 | CASE-SPLIT | AGREE (4/4) | branches not disjoint |
| D4.T4.S1 | 3 | CASE-SPLIT | AGREE (4/4) | Q1 not a branch |
| D2.T1.S2 | 3 | CASE-SPLIT | AGREE (3/3) | ok |
| D1.T1.S1 | 3 | SEQUENCE | AGREE | **MALFORMED** |

**6 agree / 3 disagree.** All three disagreements sit at **L0–L2**; all four L3 tests agreed
cleanly. The inconsistency kernel is the **top three levels' verification layer**, not the
decomposition. **CHECK 1: PARTIAL.**

---

## CHECK 2 — Type discipline: **PASS on schema, MAJOR on colors**

Programmatic gates over **all 267 nodes** (`python3`, my own walker, independent of `build_all.py`):

```
total nodes 267
missing required fields: {}          empty required fields: {}
duplicate ids: []
levels: {0:1, 1:5, 2:30, 3:60, 4:171}   types: ROOT1/DOMAIN5/TOPIC30/SUBTOPIC60/LEAF171
composition_rule operator prefixes: AND 70, SEQUENCE 14, CASE-SPLIT 11, TRADEOFF 1, LEAF 171
malformed rule prefixes: 0     leaf/LEAF mismatches: 0
id↔level mismatches: 0         parent-prefix violations: 0
duplicate question strings: 0
answer_slot clause counts: {3:246, 2:15, 4:6}   (constructor asserts 2–4)
```

Schema completeness, id integrity, operator typing: **clean, 267/267.** No duplicate ids, no
duplicate question text.

**Rule one-liners are meaningful, not boilerplate.** 28/30 L2 rules follow the template
`AND: X (S1) AND Y (S2)` but each carries a domain-specific failure statement, e.g.
`D3.T2`: *"a well-configured skill in the wrong scope, or well-scoped skill misbehaving, both
fail the team"*; `D2.T4`: *"a perfectly configured server the agent ignores is the classic
integration failure."* Not filler.

**oc_checks are concrete, not circular.** 55/96 name a scoped artifact to produce
(`Cold-write the error response for a policy-violating refund attempt`), 27/96 name an explicit
N-item probe set (`Cold-classify: microservice restructure, 45-file migration, …`). Zero repeat a
generic "check the children agree" formula. The 18 `Cold-answer '<general question>'` instances
are the exception and are MAJOR-2.

**MAJOR-4 — no edge colors anywhere.** The schema has no answer-type field. `type` is
`ROOT|DOMAIN|TOPIC|SUBTOPIC|LEAF` — a *level* label, not the answer color flowing along the edge.
meta-operad TREE: *"each edge carries a **color** (the answer type flowing along it) … composition
is only legal when colors match — an ill-typed decomposition is rejected before any inference is
spent."* operadic-interview lists `edge.typed` as **critical**: *"root and L1 nodes carry named
answer types."* Neither is satisfied — README dodges with *"answer_slot … (the ▷ slot, typed by
content)"*, which is not a named type. Concrete consequence: **all 35 L1+L2 questions open with
"Can you …?"**, whose literal answer color is `bool`, while their answer_slots hold
competency descriptions. Every edge in the top two levels carries a color mismatch. This is also
the mechanism behind MAJOR-1: no one noticed the root's slot was a different color from its
children's because no color was ever named.

---

## CHECK 3 — Askability: **PASS**

15+ nodes read closely across all levels (samples in Checks 1/4, plus the seeded 23-node sample
`ROOT, D1, D4, D2.T5, D3.T2, D3.T4, D4.T1, D4.T5, D5.T1, D1.T4.S1, D2.T1.S1, D2.T2.S2, D2.T3.S1,
D3.T2.S1, D5.T2.S2, D1.T1.S1.Q4, D1.T2.S1.Q3, D2.T3.S2.Q1, D3.T3.S1.Q1, D5.T1.S1.Q2,
D5.T2.S2.Q2, D5.T6.S2.Q1, D5.T6.S2.Q2`).

**Zero category labels.** operadic-interview's founding law — *"on regeneration, mid-level
questions decay into category headers ('The hand-check', 'Inventory')"* — is not violated at any
level. Every node parses as a question a person could answer out loud. Sample evidence:

- L2: *"Can you implement structured error responses whose taxonomy and metadata let agents
  recover intelligently in any failure scenario?"* — full question, not "Error responses".
- L3: *"How do you scope tool access per agent role - why too many tools degrade selection, and
  how scoped cross-role tools resolve the latency/purity tradeoff?"*
- L4: *"get_customer returns three plausible matches - what must the agent do, and why is picking
  the best-looking match an anti-pattern?"*

L4 questions are episode-grounded (operadic-interview's `episode.grounded` soft lens) — they open
on a concrete symptom, not an abstraction: *"A new team member's Claude Code ignores conventions
everyone else gets - what misplacement explains it and what is the fix?"*

12 questions are imperatives rather than `?`-terminated (`D2.T3.S2.Q1`: *"Enumerate the
tool_choice options and state exactly what behavior each permits or compels."*). All 12 are
genuinely askable; only the mechanical linter rule is violated. **MINOR-8.**

**Scenario-invariance: qualified pass.** The re-skinning claim holds structurally — questions name
mechanisms, and scenario nouns are swappable. But 103/171 leaves carry exactly one
`scenario_hook`, and 21 leaf questions hard-bind a scenario noun (`customer` 8, `refund` 5,
`codebase` 5, `CI ` 3, `PR ` 2, `terraform` 1). `D5.T2.S2.Q2` (*"get_customer returns three
plausible matches"*) cannot be re-skinned into SC5 (CI) without becoming nonsense. That is
*correct design* — the concept only lives in entity-lookup scenarios — but it contradicts two
literal claims: README node schema *"question — direct, **scenario-invariant** question"* and
ROOT's slot *"all answers scenario-invariant: correct under any of the six scenario skins"*.
**MINOR-9:** soften to "scenario-invariant across the scenarios listed in `scenario_hooks`".

---

## CHECK 4 — Answer-slot quality: **L3/L4 PASS, L1/L2 FAIL**

Measured over all 792 slot clauses (bare-label = <55 chars with no verb, no punctuation, no
concrete artifact):

| level | clauses | median chars | bare-label clauses |
|---|---|---|---|
| L0 | 4 | 81 | 0 (0%) |
| L1 | 20 | 66 | **5 (25%)** |
| L2 | 88 | **46** | **58 (66%)** |
| L3 | 180 | 95 | 3 (2%) |
| L4 | 500 | 78 | 26 (5%) |

**L3/L4 slots are exemplary** — checkable clauses that state what a 100% answer must contain:

> `D4.T3.S1`: *"tool use with JSON schemas guarantees schema-compliant output and eliminates JSON
> syntax errors" | "it does NOT prevent semantic errors (wrong-field values, sums that do not add
> up)" | "tool_choice: auto = may answer in text; any = must call some tool; forced
> {type:tool,name} = must call that tool"*

Only 13 of 792 clauses contain a vague hedge (`appropriate|properly|effectively|relevant|…`), and
most of those are legitimate uses (*"appropriate when prior context … is still mostly valid"*).

**L2 slots have decayed into topic labels.** Verbatim: `D1.T1` → *"result-append discipline"*;
`D1.T3` → *"goal-level delegation prompts"*; `D3.T4` → *"complexity-based mode selection"*,
*"plan-then-execute combination"*; `D4.T1` → *"trust-aware category management"*; `D5.T1` →
*"position-aware input organization"*. These name a topic; they do not state anything a grader
could check an answer against. This is the `node.askable` decay failure displaced from the
question field into the slot field.

**Functional consequence (why this is MAJOR-3, not cosmetic):** README OC step 1 says
*"Record the answer against X's `answer_slot`."* At 30/30 L2 nodes there is nothing gradeable to
record against — I hit this directly running T8 and T9. It also breaks the documented tutor loop:
*"on a miss, climb to the parent and run its OC check to find whether the miss is local … or
structural"* — the parent has no checkable slot to run against.

---

## CHECK 5 — Algebra documentation: **PARTIAL**

**What README gets right (verified):**

- *"Sequential associativity: composing D1.T1.S1's leaves into S1 and then S1+S2 into T1 gives the
  same T1 answer as composing all seven leaves at once."* — I counted: D1.T1 has exactly 7 leaves
  (S1: 4, S2: 3). The worked example is numerically correct.
- *"Parallel associativity: sibling subtrees with disjoint sources … may be studied/verified in
  any order."* — I computed leaf-level source disjointness: **0 bullets are cited by leaves in two
  different L2 subtrees.** That half of the claim is verified. **7 bullets** are shared across two
  L3 subtrees within one topic (`TS 1.1 K3`, `TS 1.2 K4`, `TS 1.5 K3`, `TS 1.7 K1`, `TS 1.7 K4`,
  `TS 4.2 S3`, `TS 4.5 K4`) — for those pairs the licence must be checked, not assumed. **MINOR-6.**
- The 4-step OC protocol (README 58–68) is procedurally complete and a fresh agent *can* follow
  steps 1–4 mechanically.

**Where the documentation does not match the implementation:**

1. **TRADEOFF's definition is contradicted by its only instance** (MAJOR-5, T3).
2. **SEQUENCE's law "reordering breaks it" is falsified** by `D1.T1.S1` (MINOR-1, T7).
3. **CASE-SPLIT's "disjoint branches commute"** is asserted with no disjointness obligation on the
   node author; `D3.T4.S1`'s branches overlap (MINOR-5, T4).
4. **No residue rule and no scope clamp** — the single largest documentation gap. A fresh agent
   following README verbatim will run T2/T9 and correctly report DISAGREE on sound subtrees,
   because nothing tells it to clamp the collapsed run to the guide's bullet set or to classify
   out-of-guide residue separately from missing coverage. Root of MAJOR-2.

**"Could a fresh agent run a collapse test from README alone?"** At L3 — yes, I did it four times
and it worked. At L1/L2 — no: it cannot grade the collapsed answer (no gradeable slot, MAJOR-3)
and it cannot interpret the comparison (no residue rule, MAJOR-2).

**Regeneration discipline gap.** README claims *"operadic-interview regeneration discipline: run
the lint on every regeneration, not just the first."* The lint run is `build_all.py`'s bespoke
gate set, **not the skill's own linter**. I ran it:

```
$ python3 /root/.claude/skills/operadic-interview/scripts/treelint.py domain-1.md
FAIL no nodes found (expected '**Qx — question?**' format)
VERDICT: FAIL (1 critical, 0 warnings)
```

The `.md` renderings use `**[D3.T1]**` and are unparseable by `treelint.py`; `grep -c '▷'` and
`grep -c '★'` return **0 for all five domain files**. **MINOR-4.**

---

## CHECK 6 — Depth integrity: **PASS**

- **Depth is exactly 4 below root everywhere.** All 171 leaves sit at level 4
  (`leaf levels {4: 171}`); 0 leaves with children; 0 L2/L3 nodes without children; 0 id↔level
  mismatches; 0 parent-prefix violations.
- **L3 nodes genuinely decompose, they do not restate L2.** Median Jaccard overlap between an L3
  question's content tokens and its L2 parent's: **0.098**; maximum across all 60: **0.33**
  (`D2.T5.S1`). L3-slot vs L2-slot median overlap: **0.088**.
- **8 L3 nodes read in full against their L2 parent and their own L4 children** — `D2.T5.S1`,
  `D1.T2.S1`, `D4.T3.S1`, `D1.T5.S1`, `D3.T5.S2`, `D4.T6.S1`, `D5.T3.S2`, `D2.T4.S1` (the two
  highest-overlap cases deliberately included). Every one is a real half of its parent, and every
  L4 child adds content its L3 parent does not state. Example — `D2.T5` splits into S1 *"select
  the right built-in tool — Grep vs Glob vs Read/Write vs Edit … by what it actually matches"*
  and S2 *"handle Edit failures and run efficient codebase exploration"*: selection vs operation,
  no restatement. `D1.T5` splits into S1 (PostToolUse, results **in**) and S2 (interception, calls
  **out**) — the rule even names the split: *"the two hook directions (results in, calls out) are
  independent capabilities sharing one principle."*
- **Materiality holds:** every leaf I read could change its parent's answer. `D4.T4.S1.Q3`
  (semantic-vs-syntax) is load-bearing — without it the `cannot-happen` bucket in the parent's
  own oc_check is unreachable (T5).

**Breadth is off-spec** (MINOR-2): **all 30 L2 nodes have exactly 2 children**; 15 L3 nodes have
2. `treelint.py` treats this as critical — *"breadth: {parent} has {n} children (need 3-5)"*, and
operadic-interview GROW says *"Peel the root into 3–6 child questions."* `D1` has 7 (also >5).
`build_all.py:138-141` relaxes the gate to `2 <= n <= 5` (L2) and `2 <= n <= 4` (L3) without
documenting the deviation. Structurally this is uniform binary bisection at L2 — it did not
produce thin nodes (verified above), but it is why CASE-SPLIT/TRADEOFF can barely appear at L2.

---

## FINDINGS

### MAJOR-1 — ROOT's answer_slot is outside its own composition algebra
**Evidence:** T1. 3 of 4 ROOT slot clauses ("every knowledge and skills bullet … reachable",
"all answers scenario-invariant", "nothing out-of-scope required anywhere in the tree") are
produced by no child; the AND rule cannot yield them. meta-operad COMPOSE witness fails at the
root edge.
**Fix (build/build_all.py, root `N(...)` call ~line 118-127):** delete those three clauses from
`answer_slot`; replace with clauses that ARE the AND of D1..D5, e.g. *"agentic architecture:
loop mechanics, hub-spoke orchestration, deterministic enforcement, decomposition, session state"*
… one per domain. Move the three deleted clauses into `meta` as a new
`tree_invariants: [...]` block (they are true and worth keeping — they are just not answers).

### MAJOR-2 — The OC protocol has no scope clamp; 18/96 oc_checks (incl. 5/5 L1) cannot pass
**Evidence:** T2 (D5: residue g–k), T9 (D3.T2: `name`/`description` residue, confirmed
out-of-guide against `TS 3.2 K2`). Pattern `Cold-answer '<general engineering question>'` appears
18 times, at every L1 node.
**Fix, two parts:**
(a) **README §"How to run an OC collapse test"** — insert a step 2.5: *"Clamp: the collapsed run
is scored only against the guide's bullet set for this node's `source`. Content the cold answer
adds that no cited bullet covers is **residue**, reported separately as a scope note, not as a
disagreement. A disagreement is a clause the cold answer contains that a cited bullet DOES cover
and no child produces."*
(b) **Rewrite the 18 unscoped probes** to name a scoped artifact, on the model of D2.T2's
(*"Cold-write the error-handling section of an MCP tool spec"*) which passed cleanly. For the five
L1 nodes, e.g. D5 → *"Cold-write the reliability section of a runbook for a Claude support agent,
restricted to what the exam guide's TS 5.1–5.6 cover."*

### MAJOR-3 — 66% of L2 answer_slot clauses are topic labels, not checkable clauses
**Evidence:** Check 4 table; 58/88 L2 clauses are bare labels (median 46 chars vs 95 at L3).
Verbatim: `D1.T1` *"result-append discipline"*, `D3.T4` *"plan-then-execute combination"*,
`D5.T1` *"position-aware input organization"*. Blocks README OC step 1 and the documented tutor
climb-to-parent loop at all 30 topic nodes.
**Fix (build/d{1..5}.py, every L2 `N(...)` `slot=[...]`):** rewrite each clause as a proposition
with a verb and a checkable object, at the L3 register. E.g. `D1.T1` *"result-append discipline"*
→ *"every tool result must be appended to the history before the next request, or the model
re-calls, hallucinates outcomes, or stalls."* Target: median ≥80 chars at L2, 0 bare labels.

### MAJOR-4 — No node carries a named answer type; every L1/L2 edge is color-mismatched
**Evidence:** Check 2. No answer-type field in the schema (`type` is a level label). All 35 L1+L2
questions open *"Can you …?"* — literal color `bool`, slot color competency-description.
Violates operadic-interview's **critical** `edge.typed` lens and meta-operad's TREE move.
**Fix:** add a required field `answer_type` to `nodes_common.py:N()` (assert non-empty for
levels 0–2, optional at 3–4), e.g. ROOT `() -> study-curriculum`, D1 `() -> competency-profile`,
D2.T2 `(taxonomy, recovery-semantics) -> error-response-standard`, `D2.T3.S2.Q1`
`() -> tool_choice-mode-table`. Then reframe the 35 *"Can you …?"* stems so their literal answer
matches the declared type — e.g. D2.T2 → *"What must an MCP tool's error responses contain, and
what recovery decision does each element license?"* Add a `build_all.py` gate: reject any node
whose `answer_type` is missing at level ≤2.

### MAJOR-5 — The TRADEOFF operator has zero valid witnesses
**Evidence:** T3. `TRADEOFF` appears exactly once in 267 nodes (`D1.T6`), and that instance is an
AND over two orthogonal axes, not an arbitration between opposing goods. README cites D1.T6 as the
operator's defining example (line 50).
**Fix, pick one:**
(a) **Retype D1.T6 to AND** — rule text: *"AND: two independent decomposition axes — predictability
(S1) and attention scale (S2); the topic answer is the union rule 'decompose along whichever axis
degrades', applied per axis independently"* — and **delete TRADEOFF from the declared operator
set** in README line 49-50, `nodes_common`/`build_all.py:142`, and the README schema line 27; or
(b) **find a real tradeoff and type it** — the best candidate I saw is `D2.T3.S1`
(*"how scoped cross-role tools resolve the latency/purity tradeoff"*, currently AND): coordinator
purity vs. latency ARE opposing goods and the node's third clause IS the arbitration rule
(*"high-frequency cross-role needs get a scoped tool … while complex cases still route through
the coordinator"*). Retype it TRADEOFF and keep D1.T6 as AND.
Either way, the four-operator claim must be backed by ≥1 honest witness each.

### MINOR-1 — SEQUENCE's "reordering breaks it" is falsified on D1.T1.S1
Q2/Q3/Q4 are rationale questions, order-free (T7). **Fix:** either retype to
`AND{sequence(Q1), rationale(Q2..Q4)}` or reword the rule to *"Q1 states the ordered lifecycle;
Q2–Q4 justify its branch points and are order-free."* Audit the other 13 SEQUENCE nodes the same
way — `D5.T5.S1` (*"Why do aggregate accuracy metrics deceive…"*) is not a lifecycle at all.

### MINOR-2 — Breadth off-spec: 30/30 L2 nodes have exactly 2 children; D1 has 7
`treelint.py` treats both as critical (`need 3-5`); `build_all.py:138-141` silently relaxes to
2–5/2–4. **Fix:** document the deviation in README §"Regenerating" with the reason (task
statements bisect naturally into knowledge-side and skills-side halves), and add an L1 breadth
gate (currently absent — D1's 7 children pass unchecked).

### MINOR-3 — Zero ★ markers anywhere in 267 nodes
operadic-interview GROW: *"Mark ★ on the one or two highest-yield questions per subtree so a
hurried respondent knows where to spend."* For a 171-leaf instrument targeting a 60-item exam,
there is no priority signal at all. **Fix:** add a boolean `high_yield` field, set on 1–2 leaves
per L2 subtree (≈40 total), seeded from `coverage-matrix (b)` — the leaves the guide's own 12
sample questions map to are the empirically highest-yield set.

### MINOR-4 — The skill's own linter cannot parse the tree's .md renderings; no ▷ slots
`treelint.py domain-1.md` → `FAIL no nodes found`; `grep -c '▷'` and `grep -c '★'` are 0 across
all five files. README claims lint-on-every-regeneration but runs only the bespoke gates.
**Fix:** emit a second rendering `domain-N.lint.md` in `**Qx.y — question?**` + `▷` form from
`build_all.py`, and call `treelint.py` on it as a build gate; or state plainly in README that
`treelint.py` is superseded by `build_all.py` and why.

### MINOR-5 — CASE-SPLIT branches are not verified disjoint
`D3.T4.S1`: probe "rename one symbol across 45 files" — Q1's scale discriminator says plan, Q2's
*"scoping clarity, not file count alone"* says direct (T4). README's *"Disjoint branches commute"*
needs an obligation. **Fix:** require every CASE-SPLIT rule to state branch precedence explicitly
(e.g. *"architectural-decision presence dominates file count"*), and add a build gate that flags
any CASE-SPLIT rule lacking a precedence or exhaustiveness clause. Audit the other 10.

### MINOR-6 — 7 bullets are shared across sibling L3 subtrees
`TS 1.1 K3`, `TS 1.2 K4`, `TS 1.5 K3`, `TS 1.7 K1`, `TS 1.7 K4`, `TS 4.2 S3`, `TS 4.5 K4`.
Cross-L2 sharing is **0**, so the parallel-associativity licence holds at topic level.
**Fix:** list these 7 pairs in README §"The composition algebra" as the explicit exceptions to
"study/verify in any order", or in `coverage-matrix` as a non-commuting-pairs ledger.

### MINOR-7 — D4.T4.S1's rule is typed CASE-SPLIT but Q1 is mechanics, not a branch
**Fix:** rule text → *"AND{ retry mechanics (Q1), CASE-SPLIT on error nature: fixable (¬Q2) vs
unfixable (Q2), grounded by the semantic-vs-syntax taxonomy (Q3) }"*. The collapse test still
passes 4/4 — this is a labeling correction only.

### MINOR-8 — 12 questions are imperatives, not `?`-terminated
`D2.T1.S1.Q2`, `D2.T1.S1.Q4`, `D2.T2.S1.Q1`, `D2.T2.S2.Q1`, `D2.T3.S2.Q1`, `D2.T5.S1.Q1`,
`D2.T5.S1.Q3`, `D4.T3.S1.Q2`, `D4.T5.S1.Q2`, `D5.T1.S2.Q2`, `D5.T2.S1.Q2`, `D5.T3.S2.Q1`.
All genuinely askable; only `treelint`'s mechanical `node.askable` rule fires. **Fix:** cosmetic —
convert to interrogative (*"Which options does tool_choice offer, and what does each permit or
compel?"*) if the lint gate of MINOR-4 is adopted.

### MINOR-9 — "scenario-invariant" is overclaimed
103/171 leaves carry exactly one `scenario_hook`; 21 leaf questions hard-bind a scenario noun
(`get_customer`, `refund`, `terraform`, `PR`). **Fix:** README node-schema line 29 and ROOT slot
clause 3 → *"scenario-invariant across the scenarios listed in its `scenario_hooks`"*.

---

## Verdict

**PASS-WITH-MINORS, conditional on MAJOR-1..5 being closed in round 2.**

What passes, with evidence: 267/267 nodes schema-complete with zero missing/empty fields, zero
duplicate ids, zero duplicate questions; depth exactly 4 everywhere; all four declared operators
present and mechanically well-formed; zero category-label nodes at any level (the founding law
holds); L3/L4 answer_slots are genuinely checkable (2%/5% bare-label); L3 decomposition is real
(median parent-child overlap 0.098); parallel associativity verified disjoint at L2 (0 violations);
and **4/4 L3 collapse tests agreed exactly on their own probe sets, including the two the builder
flagged as highest-risk.**

What does not pass: the verification layer above L3. All three disagreeing collapse tests were at
L0–L2, and each traces to one of three repairable defects — the root sits outside its own algebra
(M1), the collapsed-vs-composed comparison has no scope clamp (M2), and L2 has no gradeable slot
to compare against (M3) — compounded by the absence of any named answer type on any edge (M4) and
one declared operator with no valid witness (M5). None of these require re-decomposing the tree;
all five are text-field edits in `build/d*.py`, `nodes_common.py` and README. The expensive part
of this artifact is correct.

Standing caveat, per meta-operad and README line 72: consistency is calibration, not correctness.
The 6 agreements above raise confidence in those subtrees' internal coherence; they say nothing
about whether an answer_slot faithfully tests its cited registry bullet. That is W3a's lens.
