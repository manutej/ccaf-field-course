# W3a Review — Coverage & Source-Fidelity Lens (BLINDED)

**Reviewer:** W3a. **Lens:** does the depth-4 operadic question tree FAITHFULLY and COMPLETELY test the
official exam guide as extracted into `extraction/registry.json` / `registry.md`?
**Not my lens:** operadic algebra / OC-check execution (W3b). I did not read `question-tree/reviews/`.
**Evidence rule applied:** every verdict below quotes the tree node AND the registry text. No unquoted PASS.

**Artifacts audited:** `question-tree/tree.json` (267 nodes), `domain-{1..5}.{json,md}`,
`coverage-matrix.md`, `README.md`, against `extraction/registry.json` + `registry.md`.

**FINAL VERDICT: PASS-WITH-MINORS** — 0 BLOCKER, 0 MAJOR, 6 MINOR.

---

## Pre-check: is the ground truth itself self-consistent?

Before scoring the tree I verified the two registry renderings agree, because every `source` field is a
*positional* ordinal (`TS 4.3 K1` = "1st knowledge bullet of TS 4.3 in registry.md order"). If the two
files ordered bullets differently, every citation in the tree would be unverifiable.

Programmatic diff of all 240 bullet strings, in order, `registry.json` vs the `**Knowledge of:** / **Skills
in:**` lists in `registry.md`:

```
checked 240 bad 1     # the single "bad" is a regex artifact: TS 5.6 is the last section,
                      # so the greedy tail captured 132 trailing "- " lines from later sections.
                      # All 240 bullet TEXTS matched exactly, in order.
```

**Result:** bullet ordinals are unambiguous. Citation verification below is sound.

---

## CHECK 1 — SEMANTIC FIDELITY SAMPLE

**Sample size:** 34 distinct leaves inspected in full (question + answer_slot + composition_rule + oc_check
+ source, each against the verbatim registry text of every cited bullet). That is **19.9% of 171 leaves**,
against a ≥18-leaf (~10%) requirement. Composition of the sample:

| Stratum | Leaves |
|---|---|
| All 5 builder-flagged dense-cite leaves | D5.T1.S2.Q1, D5.T1.S2.Q2, D5.T4.S2.Q1, D5.T4.S2.Q2, D2.T5.S1.Q1 |
| Stratified random, 4 per domain (seed 3141) | D1.T4.S1.Q3, D1.T4.S1.Q1, D1.T2.S2.Q3, D1.T5.S1.Q3, D2.T5.S1.Q2, D2.T1.S1.Q1, D2.T4.S2.Q1, D2.T1.S1.Q3, D3.T4.S2.Q3, D3.T4.S2.Q1, D3.T5.S2.Q2, D3.T2.S1.Q1, D4.T5.S1.Q3, D4.T4.S2.Q2, D4.T3.S2.Q1, D4.T1.S2.Q2, D5.T3.S2.Q1, D5.T1.S1.Q2, D5.T1.S2.Q1, D5.T5.S2.Q2 |
| Targeted (highest bullets-per-slot ratio; sole-carrier leaves) | D1.T7.S2.Q3, D1.T5.S2.Q1, D2.T4.S1.Q1, D4.T3.S1.Q1, D4.T6.S1.Q1, D5.T2.S2.Q1, D5.T3.S2.Q2, D5.T6.S1.Q1, D5.T6.S2.Q2, D4.T3.S2.Q2, D4.T4.S2.Q1, D4.T4.S2.Q3, D1.T7.S1.Q4, D3.T3.S2.Q1, D1.T3.S2.Q4 |

**Verdict test used:** does a 100%-complete answer to this leaf *demonstrate* the cited bullet (TESTS),
or does it merely make the bullet's noun appear (NAMES = coverage illusion)?

**Result: 33 of 34 leaves TEST. 1 partially NAMES (MINOR-1).**

### 1a. The five builder-flagged dense-cite leaves

**D5.T1.S2.Q1 — cites `TS 5.1 K3 S3,S6` (3 bullets, 3 slots) — TESTS S3 and S6; K3 is disclosed, not elicited.**

Tree:
> Q: "Order lookups return 40+ fields per call and context fills with irrelevance - what do you trim, when, and what is the multi-agent generalization?"
> - "trim tool outputs to only decision-relevant fields (e.g. return-relevant fields) before they accumulate in context"
> - "trim at ingestion time, not after the window is already burdened"
> - "generalization: modify upstream agents to return structured data (key facts, citations, relevance scores) instead of verbose content when downstream budgets are limited"

Registry:
> `TS 5.1 K3` "How tool results accumulate in context and consume tokens disproportionately to their relevance (e.g., 40+ fields per order lookup when only 5 are relevant)"
> `TS 5.1 S3` "Trimming verbose tool outputs to only relevant fields before they accumulate in context (e.g., keeping only return-relevant fields from order lookups)"
> `TS 5.1 S6` "Modifying upstream agents to return structured data (key facts, citations, relevance scores) instead of verbose content and reasoning chains when downstream agents have limited context budgets"

Slot 1 ↔ S3 (clause-for-clause, including the "before they accumulate" timing). Slot 3 ↔ S6 (all three
payload types named: key facts, citations, relevance scores). Slot 2 is a genuine added discrimination
(ingestion-time vs post-hoc) not in either bullet — a strengthening, not a drift.
**But K3's own content — "40+ fields per call", "context fills with irrelevance" — is stated *in the stem*.**
The candidate is handed the diagnosis and asked only for the remedy. No slot requires the candidate to
articulate the disproportionality mechanism. K3's only other citation is its parent `D5.T1.S2` (whose slot 1
does state it: "tool results consume tokens disproportionately to relevance (40+ fields when 5 matter)"),
so the bullet is not orphaned — but at leaf level it is disclosed, not elicited. → **MINOR-1**.

**D5.T1.S2.Q2 — cites `TS 5.1 K2 S4,S5` — TESTS all three. Clean.**

Tree:
> Q: "Findings from the middle of a long aggregated input keep getting omitted - name the effect and the two structural mitigations, plus what subagent outputs must carry for synthesis to stay accurate."
> - "the lost-in-the-middle effect: beginning and end process reliably, middles get dropped"
> - "mitigate: key-findings summary at the beginning, detailed results organized with explicit section headers"
> - "subagent outputs must include metadata (dates, source locations, methodological context) so downstream synthesis stays accurate"

Registry:
> `TS 5.1 K2` "The \"lost in the middle\" effect: models reliably process information at the beginning and end of long inputs but may omit findings from middle sections"
> `TS 5.1 S4` "Placing key findings summaries at the beginning of aggregated inputs and organizing detailed results with explicit section headers to mitigate position effects"
> `TS 5.1 S5` "Requiring subagents to include metadata (dates, source locations, methodological context) in structured outputs to support accurate downstream synthesis"

One slot per bullet, and each slot carries the bullet's *discriminating* content: the stem asks the
candidate to **name** the effect (K2 not given away — the stem describes only the symptom "findings from
the middle keep getting omitted"), lists **two** mitigations (forcing both halves of S4), and names the
three metadata categories of S5 verbatim. This is the textbook case of a dense-cite leaf done right.

**D5.T4.S2.Q1 — cites `TS 5.4 K3 S1,S3` — TESTS all three. Clean.**

> Q: "How do subagent delegation and phase summaries jointly preserve the main agent's context during a long exploration, and what does the main agent keep for itself?"
> - "subagents absorb verbose investigation of specific questions; the main agent keeps high-level coordination"  ↔ `K3` "Subagent delegation for isolating verbose exploration output while the main agent coordinates high-level understanding" + `S1` "Spawning subagents to investigate specific questions (e.g., \"find all test files,\" \"trace refund flow dependencies\") while the main agent preserves high-level coordination"
> - "at each phase boundary, key findings are summarized and injected into the next phase's initial context"  ↔ `S3` "Summarizing key findings from one exploration phase before spawning sub-agents for the next phase, injecting summaries into initial context"
> - "the main context holds understanding, never raw discovery output"  ↔ the K3/S1 invariant, stated as a rule

The "what does the main agent keep for itself?" sub-question is what converts K3 from a definition into a
discrimination the candidate must produce.

**D5.T4.S2.Q2 — cites `TS 5.4 K4 S4` — TESTS both. Clean.**

> Q: "Design crash recovery for a long multi-agent exploration - what does each agent export, what does the coordinator load on resume, and where does recovered state go?"
> - "each agent exports structured state to a known location as it works" / "on resume the coordinator loads a manifest of that state" / "recovered state is injected into agent prompts so work resumes rather than restarts"
> ↔ `K4` "Structured state persistence for crash recovery: each agent exports state to a known location, and the coordinator loads a manifest on resume"
> ↔ `S4` "Designing crash recovery using structured agent state exports (manifests) that the coordinator loads on resume and injects into agent prompts"

The three-part stem maps one-to-one onto the three mechanisms; nothing is given away, and the third slot
(injection into prompts) is the piece S4 adds over K4 — correctly assigned.

**D2.T5.S1.Q1 — cites `TS 2.5 K1,K2 S1,S2` (4 bullets, 3 slots — the densest leaf in the tree) — TESTS all four. Clean.**

> Q: "State the Grep/Glob discrimination precisely - what does each search over, and give one task that each is uniquely right for."
> - "Grep: file contents - patterns like function names, error messages, import statements"  ↔ `K1` "Grep for content search (searching file contents for patterns like function names, error messages, or import statements)"
> - "Glob: file paths - names and extension patterns"  ↔ `K2` "Glob for file path pattern matching (finding files by name or extension patterns)"
> - "find all callers of a function -> Grep; find all *.test.tsx files -> Glob"  ↔ `S1` "Selecting Grep for searching code content across a codebase (e.g., finding all callers of a function, locating error messages)" + `S2` "Selecting Glob for finding files matching naming patterns (e.g., **/*.test.tsx)"

4 bullets in 3 slots is safe here *because* K1/S1 and K2/S2 are knowledge/skill pairs over the same fact,
and the "give one task that each is uniquely right for" clause forces the S-half explicitly. The
`**/*.test.tsx` example is carried verbatim.

**Adjudication of builder self-weakness (1):** the dense-cite risk the builder flagged is **not realised**.
4 of the 5 named leaves place one bullet-bearing clause per cited bullet with the discriminating content
intact; the fifth (D5.T1.S2.Q1) has one bullet disclosed in the stem. This is a MINOR, not the systemic
fidelity failure the flag anticipated.

### 1b. Representative fidelity evidence from the random strata

**D1.T4.S1.Q1 (D1) — cites `TS 1.4 K1,K2 S1` — TESTS all three, and pre-answers official sample Q1's full distractor set.**
> - "prompt and few-shot compliance is probabilistic; any non-zero failure rate is unacceptable when errors have financial consequences" ↔ `K2` "When deterministic compliance is required (e.g., identity verification before financial operations), prompt instructions alone have a non-zero failure rate"
> - "right fix: programmatic prerequisite that blocks the downstream tools until verification returns a verified ID" ↔ `S1` "...blocking process_refund until get_customer has returned a verified customer ID"
> - "distinguishes tool-ordering problems from tool-availability problems (routing classifiers solve the wrong problem)" ↔ `K1` "The difference between programmatic enforcement (hooks, prerequisite gates) and prompt-based guidance for workflow ordering"

**D2.T1.S1.Q3 (D2) — cites `TS 2.1 K4 S4` — TESTS both.**
> Q: "Tool descriptions look excellent yet selection is still skewed - what in the system prompt do you audit for, and what does the failure look like?"
> - "audit for keyword-sensitive instructions that create unintended tool associations" ↔ `K4` "The impact of system prompt wording on tool selection: keyword-sensitive instructions can create unintended tool associations"
> - "system prompt wording can override well-written descriptions" ↔ `S4` "Reviewing system prompts for keyword-sensitive instructions that might override well-written tool descriptions"
The stem's premise ("descriptions look excellent yet selection is still skewed") is exactly the condition
that makes K4 the *only* remaining explanation — the leaf tests diagnosis, not recall.

**D3.T3.S2.Q1 (D3) — cites `TS 3.3 K3 S3` — TESTS both, plus explicit distractor rejection.**
> - ".claude/rules/ file with a glob like **/*.test.tsx - matches by path pattern regardless of directory" ↔ `K3` "The advantage of glob-pattern rules over directory-level CLAUDE.md files for conventions that span multiple directories (e.g., test files spread throughout a codebase)"
> - "directory CLAUDE.md files are directory-bound and cannot follow scattered files" ↔ `S3` "Choosing path-specific rules over subdirectory CLAUDE.md files when conventions must apply to files spread across the codebase"

**D4.T3.S1.Q1 (D4) — cites `TS 4.3 K1,K3 S1` — TESTS all three, including the *negative* half of K3.**
> - "output arrives in the tool_use response conforming to the schema - no malformed JSON" ↔ `K1` + `S1`
> - "eliminates syntax errors (broken JSON, missing brackets, wrong types)" ↔ `K3` first half
> - "survives: semantic errors - line items not summing to totals, values in wrong fields" ↔ `K3` "...but do not prevent semantic errors (e.g., line items that don't sum to total, values in wrong fields)"
The "what error class survives?" clause is what makes K3 testable rather than nameable.

**D5.T2.S2.Q1 (D5) — cites `TS 5.2 K2 S2,S3` — TESTS all three including S3's reiteration condition.**
> - "explicit demand: honor immediately, without first attempting investigation" ↔ `S2` "Honoring explicit customer requests for human agents immediately without first attempting investigation"
> - "frustration + straightforward issue: acknowledge the frustration while offering to resolve" / "if the customer reiterates their preference after the offer, escalate" ↔ `S3` "Acknowledging frustration while offering resolution when the issue is within the agent's capability, escalating only if the customer reiterates their preference"
> - the two-branch stem ↔ `K2` "The distinction between escalating immediately when a customer explicitly demands it versus offering to resolve when the issue is straightforward"

**Two loose citations found (redundant, not gaps):**

- `D4.T4.S2.Q3` cites `TS 4.4 K3` ("Feedback loop design: tracking which code constructs trigger findings
  (detected_pattern field)...") but its slots are "retry: per-request correction" / "feedback loop:
  cross-request analysis" / "retry heals instances; feedback heals the distribution" — the `detected_pattern`
  content is **absent**. K3 is genuinely tested by sibling `D4.T4.S2.Q1` ("add a detected_pattern field
  recording which code construct triggered the finding"), so no bullet loses coverage. → **MINOR-2**.
- `D1.T7.S2.Q3` cites 4 bullets (`TS 1.7 K1,K2,K4 S2`) against only 2 answer_slot clauses — the lowest
  slot-per-bullet ratio in the tree. K1's specific mechanism (`--resume <session-name>`) is compressed to the
  word "resume". All four bullets are properly tested elsewhere (`D1.T7.S1.Q1` for K1/S1, `D1.T7.S1.Q4` for
  K4, `D1.T7.S2.Q1` for K2/S2), so this is a discriminator leaf over-citing. → **MINOR-3**.

---

## CHECK 2 — OBLIQUE COVERAGE (3 flagged bullets)

**Verdict: all 3 are ACCEPTABLE CARRIAGE. Zero MAJOR gaps. Two of the three are not oblique at all.**

**TS 1.2 K2 — NOT OBLIQUE. It is the leaf's primary subject.**
Registry:
> `TS 1.2 K2` "How subagents operate with isolated context—they do not inherit the coordinator's conversation history automatically"

Tree `D1.T2.S1.Q2` (source `TS 1.2 K2,K3`):
> Q: "**Why can a subagent not simply 'know' what the coordinator or a sibling learned earlier**, and what does that force the coordinator to do?"
> - "subagents run with isolated context - no automatic inheritance of coordinator history or sibling results"

The stem *is* K2 posed as a why-question and slot 1 *is* K2's assertion. An exam item targeting K2 head-on
is answered by this leaf's headline clause, not by a subordinate clause. Additionally, the same conceptual
invariant is re-tested from the D1.T3 angle at `D1.T3.S2.Q1` — "cause: findings were never placed in its
prompt - subagents do not inherit parent context or share memory between invocations" ↔ `TS 1.3 K2`
"That subagent context must be explicitly provided in the prompt—subagents do not automatically inherit
parent context or share memory between invocations". Two independent leaves, two task statements, same
invariant. **This bullet is over-covered, not under-covered.**

**TS 5.1 S5 — CARRIED EXPLICITLY, with all three of its named metadata categories.**
> `TS 5.1 S5` "Requiring subagents to include metadata (**dates, source locations, methodological context**) in structured outputs to support accurate downstream synthesis"

`D5.T1.S2.Q2` stem: "...**plus what subagent outputs must carry for synthesis to stay accurate**."
Slot 3: "subagent outputs must include metadata (**dates, source locations, methodological context**) so
downstream synthesis stays accurate."

The stem allocates an explicit third clause to this bullet ("plus what..."), and the slot reproduces all
three category names. A candidate cannot score the leaf without producing S5. This is the builder's own
description ("rides inside D5.T1.S2.Q2's third slot clause rather than owning a leaf") being *more*
pessimistic than the artifact warrants: the third clause is a required, individually-scored slot, not an
aside. Acceptable carriage.

**TS 4.5 K4 — CARRIED TWICE, once as recall and once as application.**
> `TS 4.5 K4` "custom_id fields for correlating batch request/response pairs"

`D4.T5.S1.Q2` (recall): "Recite the Batch API's property sheet you must know cold - cost, window, SLA,
**correlation**..." → slot: "**custom_id correlates request/response pairs** - the bookkeeping primitive".
`D4.T5.S2.Q2` (application): "...**how do you know which items those are**...?" → slot: "identify them via
their **custom_id** correlation fields."

Recall + application on the same fact. Acceptable carriage — and note this matters for official sample Q11,
whose option C is rejected precisely on custom_id (see Check 4).

**Adjudication of builder self-weakness (2):** the flag is over-cautious. None of the three is a MAJOR gap;
two are not oblique. The README's honest-ledger entry describing them should be corrected (**MINOR-4**).

---

## CHECK 3 — COVERAGE MATRIX HONESTY

### 3a. Programmatic re-verification (python3, independent of `build_all.py`)

I re-derived the canonical bullet set from `registry.json` and re-parsed both `coverage-matrix.md` and every
`source` field in `tree.json`, then cross-checked all four directions:

```
canonical bullets:                       240   (113 K + 127 S — matches meta.bullets_expected)
nodes in tree.json:                      267
matrix rows in section (a):              240
duplicate matrix rows:                     0
bullets MISSING from matrix:              []
bullets EXTRA in matrix:                  []
matrix-cited node ids not in tree.json:   []
tree source fields citing a NONEXISTENT bullet ordinal: []   (no phantom citations)
bullets with ZERO tree-derived L3/L4 node:              []   (no orphans)
matrix rows disagreeing with tree-derived coverage:      0   (240/240 exact set match)
```

The last line is the strongest result: the matrix is not a hand-maintained parallel document that *claims*
coverage — every one of its 240 cells is reproducible byte-for-byte from the tree's own `source` fields by
an independent parser. The "(c) Orphan ledger" claim ("ZERO orphans... verified programmatically") is TRUE.

Derived-artifact integrity also verified: all five `domain-N.json` subtrees match `tree.json` node-for-node
(id, question, answer_slot), and all five `domain-N.md` files contain every node id, every question verbatim,
and every source string — 0 divergences across 267 nodes.

### 3b. Ten matrix rows checked SEMANTICALLY (not id-existence)

Rows selected across all five domains and both bullet kinds. For each I read the cited leaf in full and
compared against the registry text.

| # | Row | Cited leaf | Semantic verdict |
|---|---|---|---|
| 1 | `TS 1.1 K3` → D1.T1.S2.Q3 | "What distinguishes model-driven decision-making from a pre-configured decision tree of tool calls, and when would you defend each design?" / "model-driven: Claude chooses the next tool from context each iteration" | **TESTS.** ↔ `K3` "The distinction between model-driven decision-making (Claude reasons about which tool to call next based on context) and pre-configured decision trees or tool sequences" |
| 2 | `TS 1.7 K4` → D1.T7.S1.Q4 | "what concretely goes wrong when an agent trusts stale tool results in a resumed session, and why is the failure hard to notice?" / "hard to notice because outputs remain fluent and internally consistent" | **TESTS.** ↔ `K4` "Why starting a new session with a structured summary is more reliable than resuming with stale tool results" — leaf supplies the *why*, which is the bullet's whole content |
| 3 | `TS 2.2 K4` → D2.T2.S2.Q1 | "name two concrete agent misbehaviors this causes and the metadata whose absence causes each" / "retrying non-retryable errors (wasted attempts) - absent isRetryable/errorCategory" | **TESTS.** ↔ `K4` "The difference between retryable and non-retryable errors, and how returning structured metadata prevents wasted retry attempts" |
| 4 | `TS 3.3 K3` → D3.T3.S2.Q1 | see Check 1b | **TESTS.** |
| 5 | `TS 3.6 S5` → D3.T6.S2.Q2 | "document testing standards, valuable-test criteria, and available fixtures in CLAUDE.md" | **TESTS.** ↔ `S5` "Documenting testing standards, valuable test criteria, and available fixtures in CLAUDE.md to improve test generation quality..." |
| 6 | `TS 4.2 S3` → D4.T2.S2.Q1 | "also include examples distinguishing acceptable patterns from genuine issues to cut false positives" | **TESTS.** ↔ `S3` "Providing few-shot examples distinguishing acceptable code patterns from genuine issues to reduce false positives while enabling generalization" |
| 7 | `TS 4.4 K3` → D4.T4.S2.Q1 **and** Q3 | Q1: "add a detected_pattern field recording which code construct triggered the finding" → **TESTS**. Q3: slots are retry-vs-feedback only → **NAMES** | **Row is TRUE via Q1**; the Q3 cite is redundant → MINOR-2 |
| 8 | `TS 5.5 K4` → D5.T5.S1.Q1 | "analyze accuracy by document type and by field to verify consistent performance across all segments" / "automate only segments individually proven, not the average" | **TESTS.** ↔ `K4` "The importance of validating accuracy by document type and field segment before automating high-confidence extractions" |
| 9 | `TS 5.6 K3` → D5.T6.S2.Q1 | "complete the analysis with BOTH values included and the conflict explicitly annotated with source attribution" / "never arbitrarily select one value" | **TESTS.** ↔ `K3` "...annotating conflicts with source attribution rather than arbitrarily selecting one value" |
| 10 | `TS 1.3 K4` → D1.T3.S2.Q4 | "fork_session creates independent branches from the shared analysis baseline" / "each branch preserves the pre-fork context but its post-fork work stays isolated" | **TESTS.** ↔ `K4` "Fork-based session management for exploring divergent approaches from a shared analysis baseline" |

**9.5 / 10 semantically honest.** The matrix does not inflate.

### 3c. Sole-carrier stress test (my own addition)

I computed which bullets are cited by exactly **one leaf** and of those, which sit inside a leaf citing ≥3
bullets — i.e. the population where a coverage illusion would hide:

```
bullets with exactly ONE leaf citation:            196 / 240
of those, carried inside a >=3-bullet leaf:         42
```

I read **all leaves** in that 42-bullet set (D1.T4.S1.Q1, D1.T5.S2.Q1, D2.T3.S1.Q1, D2.T4.S1.Q1,
D2.T5.S1.Q1, D3.T6.S2.Q2, D4.T3.S1.Q1, D4.T6.S1.Q1, D5.T1.S2.Q1/Q2, D5.T2.S2.Q1, D5.T3.S2.Q2, D5.T4.S2.Q1,
D5.T5.S1.Q1, D5.T6.S1.Q1, D5.T6.S2.Q2). **41 of 42 bullets are genuinely tested**; the exception is
`TS 5.1 K3` (MINOR-1). Example of the class done right — `D5.T6.S2.Q2`, sole carrier of `TS 5.6 K4, S4, S5`:

> "dates enable temporal interpretation - without them, values from different periods masquerade as contradictions" ↔ `K4`/`S4` ("requiring publication/collection dates... to prevent temporal differences from being misinterpreted as contradictions")
> "render by content type: financial data as tables, news as prose, technical findings as structured lists" ↔ `S5` (all three renderings verbatim)

---

## CHECK 4 — SAMPLE-QUESTION ANTICIPATION (4 of 12, across 4 domains)

Test applied: would mastering *only* the mapped leaves produce the correct option **and** the rejection of
every distractor? (Rejecting distractors is the harder half — that is where a coverage-only tree fails.)

### Sample Q1 (D1) → D1.T4.S1.Q1, D1.T4.S1.Q2, D1.T5.S2.Q3 — **YES, including all 3 distractors**

Guide stem: *"in 12% of cases, your agent skips get_customer entirely and calls lookup_order using only the
customer's stated name... What change would most effectively address this reliability issue?"* Correct: **A**
("programmatic prerequisite that blocks lookup_order and process_refund calls until get_customer has returned
a verified customer ID"). Guide rationale rejects **B/C** as "probabilistic LLM compliance" and **D** as
"tool availability rather than tool ordering".

`D1.T4.S1.Q1` slots, verbatim:
> - "prompt and few-shot compliance is probabilistic; any non-zero failure rate is unacceptable when errors have financial consequences"  → kills **B** and **C**
> - "right fix: programmatic prerequisite that blocks the downstream tools until verification returns a verified ID"  → selects **A**
> - "distinguishes tool-ordering problems from tool-availability problems (routing classifiers solve the wrong problem)"  → kills **D**

One leaf reproduces the guide's entire rationale, distractor-by-distractor.

### Sample Q3 (D5) → D5.T2.S1.Q1, D5.T2.S1.Q2 — **YES, all 3 distractors**

Guide stem: escalation miscalibration, 55% FCR. Correct **A** (explicit escalation criteria + few-shot).
Rationale rejects **B** (self-reported confidence poorly calibrated), **C** (over-engineered classifier),
**D** (sentiment ≠ complexity).

`D5.T2.S1.Q1` stem: *"...what fix addresses the root cause, and **why do confidence thresholds, trained
classifiers, and sentiment routing all miss it**?"* Slots:
> - "root cause: unclear decision boundaries - add explicit escalation criteria with few-shot escalate-vs-resolve examples to the system prompt" → **A**
> - "self-reported confidence is poorly calibrated (the agent is already wrongly confident); classifiers are over-engineering before prompt optimization is tried" → **B**, **C**
> - "sentiment tracks emotion, not case complexity - a different variable entirely" → **D**

The leaf's own stem names the three distractors as a required part of the answer. `D5.T2.S1.Q2` adds the
legitimate-trigger enumeration ("explicit customer request for a human; policy exceptions or gaps; inability
to make meaningful progress") that back-stops the same judgement.

### Sample Q9 (D2) → D2.T3.S1.Q2, D2.T3.S1.Q1 — **YES, all 3 distractors**

Guide stem: synthesis agent verification round-trips, 85% simple / 15% deep, +40% latency. Correct **A**
(scoped `verify_fact` tool). Rationale rejects **B** (batching creates blocking dependencies), **C**
(over-provisions, violates separation of concerns), **D** (speculative caching cannot predict needs).

`D2.T3.S1.Q2` slots:
> - "give it a scoped verify_fact tool for the high-frequency simple case" → **A**
> - "complex verifications still delegate through the coordinator to the search agent" → preserves the pattern
> - "full search access over-provisions and violates separation of concerns; **batching creates blocking dependencies**; **speculative caching cannot predict needs**" → **C**, **B**, **D**

`D2.T3.S1.Q1` supplies the underlying principle ("18 tools misselects... 4-5 well-chosen tools beat 18").

### Sample Q11 (D4) → D4.T5.S1.Q1, D4.T5.S1.Q2 — **YES, all 3 distractors, but only because both leaves are studied**

Guide stem: batch both the blocking pre-merge check and the overnight tech-debt report? Correct **A** (batch
the report only). Rationale rejects **B** ("often faster isn't acceptable for blocking"), **C** ("a
misconception—batch results can be correlated using custom_id fields"), **D** (unnecessary complexity).

`D4.T5.S1.Q1`:
> - "batch the overnight report; keep the pre-merge check synchronous" → **A**
> - "deciding property: batch has no latency SLA and can take up to 24 hours - unacceptable where developers block" → **B**
> - "'usually faster' is not a guarantee; matching API to latency requirement beats uniform migration" → **B**, **D**

Option **C**'s rejection requires the custom_id fact, which lives in the *other* mapped leaf `D4.T5.S1.Q2`
("custom_id correlates request/response pairs - the bookkeeping primitive"). The mapping lists both, so the
composed answer is complete — this is the map being correct rather than generous.

**Verdict: 4/4 sample questions are fully anticipated, distractors included.** The tree is not merely
topic-aligned with the sample items; the answer_slots encode the guide's own rejection reasoning. All 12
map entries additionally resolve to existing leaf ids (programmatic check, 0 bad ids).

---

## CHECK 5 — OUT-OF-SCOPE GUARD (16 excluded topics)

Method: keyword sweep of every node's `question` + `answer_slot` (267 nodes) for lexical proxies of all 16
exclusions, then manual adjudication of each hit. Sweep produced 74 hits; **72 were substring false
positives** — `SSE` inside "pa**sse**s"/"a**sse**ss", "**stream**" inside "up**stream**", "**train**" inside
"cons**train**t"/"res**truct**uring", "**vision**" inside "pro**vision**ing", "**host**" inside adjacent
words. Two hits warranted adjudication:

**Hit A — `D2.T4.S1.Q2` (auth tokens / secrets). VERDICT: IN SCOPE.**
> Q: "The shared .mcp.json needs an auth token but must not leak secrets into the repo - what mechanism resolves this and how does it work?"
> - "environment variable expansion in .mcp.json, e.g. ${GITHUB_TOKEN}"

↔ `TS 2.4 K2` "**Environment variable expansion in .mcp.json (e.g., ${GITHUB_TOKEN}) for credential
management without committing secrets**" and `TS 2.4 S1` "Configuring shared MCP servers in project-scoped
.mcp.json with environment variable expansion for authentication tokens".

Exclusion #12 is "**OAuth, API key rotation, or authentication protocol details**". The leaf requires none of
those — it requires the guide's own env-var-expansion mechanism, which is an explicit in-scope bullet AND an
in-scope topic ("MCP server configuration: project vs user scope, **environment variable expansion**").
No violation.

**Hit B — `D4.T5.*` (50% cost savings). VERDICT: IN SCOPE.**
> `D4.T5.S1.Q2`: "50% cost savings versus synchronous - the motive" ↔ `TS 4.5 K1` "The Message Batches API: **50% cost savings**, up to 24-hour processing window, no guaranteed latency SLA"

Exclusion #11 is "**Rate limiting, quotas, or API pricing calculations**". The leaf asks for a recited guide
fact, never a calculation. Confirmed against the guide's own technologies list: "Message Batches API — 50%
cost savings...". No violation.

**Nil results (searched, zero occurrences anywhere in the tree):** fine-tuning / model training, RLHF /
Constitutional AI, model weights or internal architecture, embeddings, vector databases, computer use /
browser / desktop automation, vision or image analysis, streaming / SSE, token-counting or tokenization
algorithms, rate limits or quotas, OAuth or key rotation, AWS / GCP / Azure, benchmarking or model-comparison
metrics, MCP server hosting / containers / networking, billing or account management. Prompt caching appears
only as (i) the domain noun in `TS 3.5 S3`'s own verbatim example ("cache invalidation strategies") at
`D3.T5.S2.Q1` and (ii) the phrase "speculative caching" as a sample-Q9 distractor rejection — neither
requires caching implementation knowledge ("beyond knowing it exists").

**Verdict: 0 leaves require out-of-scope knowledge. CLEAN PASS.** The README's summary of this guard is
slightly overstated in wording (**MINOR-5**).

---

## CHECK 6 — WEIGHT / BALANCE

Recomputed from `tree.json` leaf counts against `registry.json` domain weights, independent of the build
script and of `meta.leaves_by_domain`:

| Domain | Guide weight | Leaves | Leaf share | Δ (pp) | Matrix (d) claims | Match |
|---|---|---|---|---|---|---|
| D1 Agentic Architecture & Orchestration | 27% | 46 | 26.9% | −0.1 | 46 / 26.9% / YES | ✔ |
| D2 Tool Design & MCP Integration | 18% | 31 | 18.1% | +0.1 | 31 / 18.1% / YES | ✔ |
| D3 Claude Code Configuration & Workflows | 20% | 34 | 19.9% | −0.1 | 34 / 19.9% / YES | ✔ |
| D4 Prompt Engineering & Structured Output | 20% | 34 | 19.9% | −0.1 | 34 / 19.9% / YES | ✔ |
| D5 Context Management & Reliability | 15% | 26 | 15.2% | +0.2 | 26 / 15.2% / YES | ✔ |
| **Total** | 100% | **171** | 100% | | 171 | ✔ |

Also confirmed: `meta.node_counts_by_level` `{L0:1, L1:5, L2:30, L3:60, L4:171}` reproduces exactly from a
fresh traversal; `meta.total_nodes` 267 correct; every leaf is at level 4 (no ragged depth); 30 topics ↔ 30
task statements 1:1 by `source`; L1 sources carry the correct weights (`D1 (27%) - TS 1.1-1.7`, etc.).

**Verdict: proportionality table is accurate. Max deviation 0.2pp against a ±5pp tolerance. CLEAN PASS.**

---

## FINDINGS

No BLOCKERs. No MAJORs. Six MINORs, each with an exact fix addressed to the tree builder. All fixes are
edits to `build/d*.py` or `README.md` followed by `python3 build/build_all.py` (per the regeneration
discipline in README §Regenerating — do not hand-edit `tree.json`).

### MINOR-1 — `TS 5.1 K3` is disclosed in `D5.T1.S2.Q1`'s stem instead of elicited
**Where:** `build/d5.py`, node `D5.T1.S2.Q1`. **Why it matters:** this leaf is K3's only leaf-level carrier;
a candidate can score the leaf without ever articulating *why* tool results are expensive, which is what an
exam item on K3 would ask.
**Fix:** move the mechanism out of the stem and into a required slot. Change the question from
`"Order lookups return 40+ fields per call and context fills with irrelevance - what do you trim, when, and what is the multi-agent generalization?"`
to something like
`"An order-lookup tool returns everything it has on each call and the agent's context degrades within a few turns - explain the cost mechanism precisely, then say what you trim, when, and what the multi-agent generalization is."`
and prepend a fourth slot clause:
`"tool results accumulate in context and consume tokens disproportionately to relevance - 40+ fields returned when ~5 are decision-relevant"`.
(4 slots is within the README's stated `answer_slot` contract of "2-4 clauses".)

### MINOR-2 — `D4.T4.S2.Q3` cites `TS 4.4 K3` but does not test it
**Where:** `build/d4.py`, node `D4.T4.S2.Q3`, `source: "TS 4.4 K3"`. The slots test feedback-loop vs
retry-loop; the bullet's `detected_pattern` content is absent. K3 is fully tested at `D4.T4.S2.Q1`, so no
coverage is lost — but the citation makes the matrix row `TS 4.4 K3 | D4.T4.S2, D4.T4.S2.Q1, D4.T4.S2.Q3`
imply two tests where there is one.
**Fix (pick one):** (a) drop `TS 4.4 K3` from `D4.T4.S2.Q3`'s source — the leaf then needs a source, so
re-cite it to the task statement level or fold it under `TS 4.4 K1` if the retry semantics are the intent;
or (b) keep the cite and add the missing clause, e.g.
`"the feedback loop's instrument is the detected_pattern field - it is what makes cross-request analysis possible"`.
Option (b) is preferred: it preserves the leaf's integrative role and makes the citation honest.

### MINOR-3 — `D1.T7.S2.Q3` cites 4 bullets against 2 slots (lowest density in the tree)
**Where:** `build/d1.py`, node `D1.T7.S2.Q3`, `source: "TS 1.7 K1,K2,K4 S2"`, `answer_slot` length 2.
`TS 1.7 K1`'s specific mechanism (`--resume <session-name>`) is compressed to the bare word "resume". All
four bullets are tested elsewhere (K1/S1 at `D1.T7.S1.Q1`, K4 at `D1.T7.S1.Q4`, K2/S2 at `D1.T7.S2.Q1`), so
this is over-citation on a discriminator leaf.
**Fix:** narrow the source to `TS 1.7 K2,K4` (the two bullets the discrimination actually turns on) and add
a third slot naming the mechanisms rather than the concepts, e.g.
`"the three mechanisms concretely: --resume <session-name>, fork_session, and a fresh session seeded with a structured summary"`.
This keeps the matrix rows for K1/S2 pointing only at leaves that test them.

### MINOR-4 — README "Known shortfalls" item 2 is stale and miscites a node
**Where:** `README.md` lines 111–115. Two problems.
(i) It attributes `TS 1.2 K2` coverage to `D1.T3.S2.Q1`, but that leaf's source is `TS 1.3 K2 S1` — a
different task statement. The *concept* recurs there; the *bullet* does not.
(ii) The characterisation "tested obliquely... an exam item targeting such a bullet head-on would be answered
from a slot clause, not a whole leaf" is contradicted by the artifacts: `D1.T2.S1.Q2`'s entire stem is
`TS 1.2 K2` as a why-question, and `D5.T1.S2.Q2`'s stem allocates an explicit third clause to `TS 5.1 S5`
("plus what subagent outputs must carry for synthesis to stay accurate").
**Fix:** replace item 2 with an accurate statement, e.g.:
> "2. **A few bullets share a leaf with siblings rather than owning one.** E.g. `TS 5.1 S5` (subagent
> metadata) is the third required clause of `D5.T1.S2.Q2` rather than a standalone leaf, and `TS 1.2 K2`
> (isolated context) is the headline clause of `D1.T2.S1.Q2` (the same invariant recurs independently at
> `D1.T3.S2.Q1` under `TS 1.3 K2`). Reviewed W3a round 2: each such bullet is separately scored within its
> leaf, so an item targeting it head-on is still answerable. The residual risk is that these bullets get
> less *drill* time than leaf-owning bullets."

### MINOR-5 — README overstates the out-of-scope guard
**Where:** `README.md` lines 99–101: *"...batch-API leaves stop at the facts the guide lists,
prompt-caching/streaming/**auth/pricing** never appear."* Auth *does* appear (`D2.T4.S1.Q2`: "The shared
.mcp.json needs an **auth token**...") and cost *does* appear (`D4.T5.S1.Q2`: "**50% cost savings**..."). Both
are legitimate — they are guide bullets `TS 2.4 K2/S1` and `TS 4.5 K1` — but the absolute wording is false as
written and invites a reader to conclude the guard was run loosely.
**Fix:** reword to:
> "Out-of-scope guard: no leaf requires any of the 16 out-of-scope topics. Auth and cost appear only as the
> guide's own bullet facts — env-var expansion in `.mcp.json` (`TS 2.4 K2/S1`) and the Batch API's 50%
> savings (`TS 4.5 K1`) — never as authentication protocols, key rotation, or pricing calculations.
> Prompt caching appears only as `TS 3.5 S3`'s own 'cache invalidation' example and as a rejected
> sample-Q9 distractor. Streaming, tokenization, embeddings, vision, computer use, fine-tuning, cloud
> configuration and benchmarking appear nowhere."

### MINOR-6 — `max_tokens` is in the guide's technologies list but in no bullet and no node
**Where:** scope boundary, `README.md`. `registry.json.technologies_and_concepts.items` includes
*"Claude API — tool_use with JSON schemas, tool_choice options... stop_reason values ("tool_use",
"end_turn"), **max_tokens**, system prompts"*, prefaced by *"technologies and concepts that **might appear on
the exam**"*. A full-text scan of all 267 nodes finds zero occurrences of `max_tokens`; a scan of all 240
bullets also finds zero. (Every other item on that list *is* reachable: `Pydantic` at `D4.T4.S1.Q3`,
`stratified sampling` at `D5.T5.S1.Q2`, `/memory`, `/compact`, `fork_session`, `--resume`, `--json-schema`,
`--output-format`, `isError`, `context: fork`, `argument-hint`, `allowed-tools`, `custom_id`, `scratchpad`,
`Explore subagent`, multi-server simultaneous discovery at `D2.T4.S1.Q3` — all present.)
The tree's stated coverage contract is the 240 bullets, and that contract is met 240/240; this is a hole in
the *guide-wide* surface, not a broken promise. But it is the tree's only known blind spot against the
official document.
**Fix (pick one):** (a) add one clause to an existing D4/D1 leaf — e.g. append to `D1.T1.S1.Q1`'s slots
`"request-shaping fields the loop controls: max_tokens and the system prompt, set per iteration"`; or
(b) if the builder holds that only bullets are examinable, record it explicitly in README §Known shortfalls
as: *"`max_tokens` appears in the guide's 'technologies and concepts that might appear' list but in none of
the 240 task-statement bullets; the tree follows the bullets and therefore does not cover it. Accepted gap."*
Either is fine — an undocumented gap is not.

---

## SUMMARY TABLE

| Check | Verdict | Basis |
|---|---|---|
| 1. Semantic fidelity (34 leaves, 19.9%) | **PASS** | 33/34 TEST their cited bullets clause-for-clause; 1 partial (MINOR-1). All 5 dense-cite leaves verified; 4 clean. |
| 2. Oblique coverage (3 flagged) | **PASS** | All 3 acceptable carriage; `TS 1.2 K2` and `TS 4.5 K4` are not oblique at all. 0 MAJOR gaps. |
| 3. Coverage-matrix honesty | **PASS** | 240/240 bullets present, 0 dupes, 0 phantom cites, 0 orphans, 0 bad node ids, and all 240 rows reproduce exactly from tree `source` fields under an independent parser. 9.5/10 semantic spot checks honest. 41/42 sole-carrier-in-dense-leaf bullets genuinely tested. |
| 4. Sample-question anticipation (Q1/Q3/Q9/Q11) | **PASS** | 4/4 fully anticipated *including every distractor rejection*, quoting the guide's own rationale language. |
| 5. Out-of-scope guard (16 topics) | **PASS** | 0 leaves require excluded knowledge; 2 adjudicated hits both trace to explicit in-scope bullets. |
| 6. Weight / balance | **PASS** | Recomputed independently; max deviation 0.2pp vs ±5pp tolerance; matrix (d) and `meta` both accurate. |

**FINAL: PASS-WITH-MINORS.** The tree is a faithful and complete instrument for the exam guide as extracted.
Its coverage claims survive independent programmatic re-derivation, and — the harder test — its answer_slots
encode the *discriminating* content of the bullets rather than their nouns, including the rejection reasoning
the official sample items reward. The builder's two self-flagged fidelity risks were both over-cautious. The
six MINORs are three narrow citation/stem tightenings (MINOR-1/2/3), two README accuracy corrections
(MINOR-4/5), and one documented-or-closed scope gap (MINOR-6). None blocks CP-1 sign-off.
