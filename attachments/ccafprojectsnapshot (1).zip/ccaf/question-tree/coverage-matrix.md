# CCAF Question Tree - Coverage Matrix

Generated programmatically by build_all.py from the source fields of all L3/L4 nodes. 
Bullet IDs follow registry.md ordering: TS x.y K/S n = nth knowledge-of / skills-in bullet of that task statement.

## (a) Bullet -> node map (all 240 bullets)

| Bullet | Covered by (L3/L4 nodes) |
|---|---|
| TS 1.1 K1 | D1.T1.S1, D1.T1.S1.Q1, D1.T1.S1.Q2 |
| TS 1.1 K2 | D1.T1.S1, D1.T1.S1.Q3, D1.T1.S1.Q4 |
| TS 1.1 K3 | D1.T1.S1.Q4, D1.T1.S2, D1.T1.S2.Q3 |
| TS 1.1 S1 | D1.T1.S1, D1.T1.S1.Q1, D1.T1.S1.Q2 |
| TS 1.1 S2 | D1.T1.S1, D1.T1.S1.Q3, D1.T1.S1.Q4 |
| TS 1.1 S3 | D1.T1.S2, D1.T1.S2.Q1, D1.T1.S2.Q2 |
| TS 1.2 K1 | D1.T2.S1, D1.T2.S1.Q1 |
| TS 1.2 K2 | D1.T2.S1, D1.T2.S1.Q2 |
| TS 1.2 K3 | D1.T2.S1, D1.T2.S1.Q2, D1.T2.S1.Q3, D1.T2.S1.Q4 |
| TS 1.2 K4 | D1.T2.S1.Q4, D1.T2.S2, D1.T2.S2.Q1 |
| TS 1.2 S1 | D1.T2.S1, D1.T2.S1.Q3 |
| TS 1.2 S2 | D1.T2.S2, D1.T2.S2.Q2 |
| TS 1.2 S3 | D1.T2.S2, D1.T2.S2.Q3 |
| TS 1.2 S4 | D1.T2.S1, D1.T2.S1.Q1 |
| TS 1.3 K1 | D1.T3.S1, D1.T3.S1.Q1 |
| TS 1.3 K2 | D1.T3.S2, D1.T3.S2.Q1 |
| TS 1.3 K3 | D1.T3.S1, D1.T3.S1.Q3 |
| TS 1.3 K4 | D1.T3.S2, D1.T3.S2.Q4 |
| TS 1.3 S1 | D1.T3.S2, D1.T3.S2.Q1 |
| TS 1.3 S2 | D1.T3.S2, D1.T3.S2.Q2 |
| TS 1.3 S3 | D1.T3.S1, D1.T3.S1.Q2 |
| TS 1.3 S4 | D1.T3.S2, D1.T3.S2.Q3 |
| TS 1.4 K1 | D1.T4.S1, D1.T4.S1.Q1, D1.T4.S1.Q3 |
| TS 1.4 K2 | D1.T4.S1, D1.T4.S1.Q1 |
| TS 1.4 K3 | D1.T4.S2, D1.T4.S2.Q2, D1.T4.S2.Q3 |
| TS 1.4 S1 | D1.T4.S1, D1.T4.S1.Q1, D1.T4.S1.Q2 |
| TS 1.4 S2 | D1.T4.S2, D1.T4.S2.Q1 |
| TS 1.4 S3 | D1.T4.S2, D1.T4.S2.Q2 |
| TS 1.5 K1 | D1.T5.S1, D1.T5.S1.Q1, D1.T5.S1.Q2, D1.T5.S1.Q3 |
| TS 1.5 K2 | D1.T5.S2, D1.T5.S2.Q1 |
| TS 1.5 K3 | D1.T5.S1.Q3, D1.T5.S2, D1.T5.S2.Q3 |
| TS 1.5 S1 | D1.T5.S1, D1.T5.S1.Q1, D1.T5.S1.Q3 |
| TS 1.5 S2 | D1.T5.S2, D1.T5.S2.Q1, D1.T5.S2.Q2 |
| TS 1.5 S3 | D1.T5.S2, D1.T5.S2.Q1, D1.T5.S2.Q3 |
| TS 1.6 K1 | D1.T6.S1, D1.T6.S1.Q1 |
| TS 1.6 K2 | D1.T6.S2, D1.T6.S2.Q1, D1.T6.S2.Q2, D1.T6.S2.Q3 |
| TS 1.6 K3 | D1.T6.S1, D1.T6.S1.Q2 |
| TS 1.6 S1 | D1.T6.S1, D1.T6.S1.Q1 |
| TS 1.6 S2 | D1.T6.S2, D1.T6.S2.Q1, D1.T6.S2.Q2 |
| TS 1.6 S3 | D1.T6.S1, D1.T6.S1.Q3 |
| TS 1.7 K1 | D1.T7.S1, D1.T7.S1.Q1 |
| TS 1.7 K2 | D1.T7.S2, D1.T7.S2.Q1, D1.T7.S2.Q2, D1.T7.S2.Q3 |
| TS 1.7 K3 | D1.T7.S1, D1.T7.S1.Q3 |
| TS 1.7 K4 | D1.T7.S1, D1.T7.S1.Q2, D1.T7.S1.Q4, D1.T7.S2.Q3 |
| TS 1.7 S1 | D1.T7.S1, D1.T7.S1.Q1 |
| TS 1.7 S2 | D1.T7.S2, D1.T7.S2.Q1 |
| TS 1.7 S3 | D1.T7.S1, D1.T7.S1.Q2 |
| TS 1.7 S4 | D1.T7.S1, D1.T7.S1.Q3 |
| TS 2.1 K1 | D2.T1.S1, D2.T1.S1.Q1, D2.T1.S1.Q4 |
| TS 2.1 K2 | D2.T1.S1, D2.T1.S1.Q2 |
| TS 2.1 K3 | D2.T1.S2, D2.T1.S2.Q1, D2.T1.S2.Q3 |
| TS 2.1 K4 | D2.T1.S1, D2.T1.S1.Q3 |
| TS 2.1 S1 | D2.T1.S1, D2.T1.S1.Q1, D2.T1.S1.Q2, D2.T1.S1.Q4 |
| TS 2.1 S2 | D2.T1.S2, D2.T1.S2.Q1, D2.T1.S2.Q3 |
| TS 2.1 S3 | D2.T1.S2, D2.T1.S2.Q2 |
| TS 2.1 S4 | D2.T1.S1, D2.T1.S1.Q3 |
| TS 2.2 K1 | D2.T2.S1, D2.T2.S1.Q2 |
| TS 2.2 K2 | D2.T2.S1, D2.T2.S1.Q1 |
| TS 2.2 K3 | D2.T2.S2, D2.T2.S2.Q1 |
| TS 2.2 K4 | D2.T2.S2, D2.T2.S2.Q1 |
| TS 2.2 S1 | D2.T2.S1, D2.T2.S1.Q2 |
| TS 2.2 S2 | D2.T2.S1, D2.T2.S1.Q3 |
| TS 2.2 S3 | D2.T2.S2, D2.T2.S2.Q3 |
| TS 2.2 S4 | D2.T2.S2, D2.T2.S2.Q2 |
| TS 2.3 K1 | D2.T3.S1, D2.T3.S1.Q1 |
| TS 2.3 K2 | D2.T3.S1, D2.T3.S1.Q1 |
| TS 2.3 K3 | D2.T3.S1, D2.T3.S1.Q2 |
| TS 2.3 K4 | D2.T3.S2, D2.T3.S2.Q1 |
| TS 2.3 S1 | D2.T3.S1, D2.T3.S1.Q1 |
| TS 2.3 S2 | D2.T3.S1, D2.T3.S1.Q3 |
| TS 2.3 S3 | D2.T3.S1, D2.T3.S1.Q2 |
| TS 2.3 S4 | D2.T3.S2, D2.T3.S2.Q2 |
| TS 2.3 S5 | D2.T3.S2, D2.T3.S2.Q3 |
| TS 2.4 K1 | D2.T4.S1, D2.T4.S1.Q1 |
| TS 2.4 K2 | D2.T4.S1, D2.T4.S1.Q2 |
| TS 2.4 K3 | D2.T4.S1, D2.T4.S1.Q3 |
| TS 2.4 K4 | D2.T4.S2, D2.T4.S2.Q2 |
| TS 2.4 S1 | D2.T4.S1, D2.T4.S1.Q1, D2.T4.S1.Q2 |
| TS 2.4 S2 | D2.T4.S1, D2.T4.S1.Q1 |
| TS 2.4 S3 | D2.T4.S2, D2.T4.S2.Q1 |
| TS 2.4 S4 | D2.T4.S2, D2.T4.S2.Q3 |
| TS 2.4 S5 | D2.T4.S2, D2.T4.S2.Q2 |
| TS 2.5 K1 | D2.T5.S1, D2.T5.S1.Q1 |
| TS 2.5 K2 | D2.T5.S1, D2.T5.S1.Q1 |
| TS 2.5 K3 | D2.T5.S1, D2.T5.S1.Q2 |
| TS 2.5 K4 | D2.T5.S2, D2.T5.S2.Q1 |
| TS 2.5 S1 | D2.T5.S1, D2.T5.S1.Q1, D2.T5.S1.Q3 |
| TS 2.5 S2 | D2.T5.S1, D2.T5.S1.Q1, D2.T5.S1.Q3 |
| TS 2.5 S3 | D2.T5.S2, D2.T5.S2.Q1 |
| TS 2.5 S4 | D2.T5.S2, D2.T5.S2.Q2 |
| TS 2.5 S5 | D2.T5.S2, D2.T5.S2.Q3 |
| TS 3.1 K1 | D3.T1.S1, D3.T1.S1.Q2 |
| TS 3.1 K2 | D3.T1.S1, D3.T1.S1.Q1 |
| TS 3.1 K3 | D3.T1.S2, D3.T1.S2.Q2, D3.T1.S2.Q3 |
| TS 3.1 K4 | D3.T1.S2, D3.T1.S2.Q1, D3.T1.S2.Q3 |
| TS 3.1 S1 | D3.T1.S1, D3.T1.S1.Q1 |
| TS 3.1 S2 | D3.T1.S2, D3.T1.S2.Q2 |
| TS 3.1 S3 | D3.T1.S2, D3.T1.S2.Q1 |
| TS 3.1 S4 | D3.T1.S1, D3.T1.S1.Q3 |
| TS 3.2 K1 | D3.T2.S1, D3.T2.S1.Q1 |
| TS 3.2 K2 | D3.T2.S2, D3.T2.S2.Q3 |
| TS 3.2 K3 | D3.T2.S2, D3.T2.S2.Q1 |
| TS 3.2 K4 | D3.T2.S1, D3.T2.S1.Q2 |
| TS 3.2 S1 | D3.T2.S1, D3.T2.S1.Q1 |
| TS 3.2 S2 | D3.T2.S2, D3.T2.S2.Q1 |
| TS 3.2 S3 | D3.T2.S2, D3.T2.S2.Q2 |
| TS 3.2 S4 | D3.T2.S2, D3.T2.S2.Q3 |
| TS 3.2 S5 | D3.T2.S1, D3.T2.S1.Q3 |
| TS 3.3 K1 | D3.T3.S1, D3.T3.S1.Q1 |
| TS 3.3 K2 | D3.T3.S1, D3.T3.S1.Q2 |
| TS 3.3 K3 | D3.T3.S2, D3.T3.S2.Q1, D3.T3.S2.Q3 |
| TS 3.3 S1 | D3.T3.S1, D3.T3.S1.Q1 |
| TS 3.3 S2 | D3.T3.S2, D3.T3.S2.Q2 |
| TS 3.3 S3 | D3.T3.S2, D3.T3.S2.Q1 |
| TS 3.4 K1 | D3.T4.S1, D3.T4.S1.Q1, D3.T4.S1.Q3 |
| TS 3.4 K2 | D3.T4.S1, D3.T4.S1.Q2 |
| TS 3.4 K3 | D3.T4.S2, D3.T4.S2.Q1 |
| TS 3.4 K4 | D3.T4.S2, D3.T4.S2.Q2 |
| TS 3.4 S1 | D3.T4.S1, D3.T4.S1.Q1 |
| TS 3.4 S2 | D3.T4.S1, D3.T4.S1.Q2 |
| TS 3.4 S3 | D3.T4.S2, D3.T4.S2.Q2 |
| TS 3.4 S4 | D3.T4.S2, D3.T4.S2.Q3 |
| TS 3.5 K1 | D3.T5.S1, D3.T5.S1.Q1 |
| TS 3.5 K2 | D3.T5.S1, D3.T5.S1.Q2 |
| TS 3.5 K3 | D3.T5.S2, D3.T5.S2.Q1, D3.T5.S2.Q3 |
| TS 3.5 K4 | D3.T5.S2, D3.T5.S2.Q2 |
| TS 3.5 S1 | D3.T5.S1, D3.T5.S1.Q1 |
| TS 3.5 S2 | D3.T5.S1, D3.T5.S1.Q2 |
| TS 3.5 S3 | D3.T5.S2, D3.T5.S2.Q1, D3.T5.S2.Q3 |
| TS 3.5 S4 | D3.T5.S1, D3.T5.S1.Q3 |
| TS 3.5 S5 | D3.T5.S2, D3.T5.S2.Q2 |
| TS 3.6 K1 | D3.T6.S1, D3.T6.S1.Q1 |
| TS 3.6 K2 | D3.T6.S1, D3.T6.S1.Q2 |
| TS 3.6 K3 | D3.T6.S2, D3.T6.S2.Q2 |
| TS 3.6 K4 | D3.T6.S1, D3.T6.S1.Q3 |
| TS 3.6 S1 | D3.T6.S1, D3.T6.S1.Q1 |
| TS 3.6 S2 | D3.T6.S1, D3.T6.S1.Q2 |
| TS 3.6 S3 | D3.T6.S2, D3.T6.S2.Q1 |
| TS 3.6 S4 | D3.T6.S2, D3.T6.S2.Q2 |
| TS 3.6 S5 | D3.T6.S2, D3.T6.S2.Q2 |
| TS 4.1 K1 | D4.T1.S1, D4.T1.S1.Q2 |
| TS 4.1 K2 | D4.T1.S1, D4.T1.S1.Q1 |
| TS 4.1 K3 | D4.T1.S2, D4.T1.S2.Q1, D4.T1.S2.Q2 |
| TS 4.1 S1 | D4.T1.S1, D4.T1.S1.Q1 |
| TS 4.1 S2 | D4.T1.S2, D4.T1.S2.Q1 |
| TS 4.1 S3 | D4.T1.S1, D4.T1.S1.Q3 |
| TS 4.2 K1 | D4.T2.S1, D4.T2.S1.Q1 |
| TS 4.2 K2 | D4.T2.S1, D4.T2.S1.Q3 |
| TS 4.2 K3 | D4.T2.S1, D4.T2.S1.Q2 |
| TS 4.2 K4 | D4.T2.S2, D4.T2.S2.Q2 |
| TS 4.2 S1 | D4.T2.S1, D4.T2.S1.Q1, D4.T2.S1.Q3 |
| TS 4.2 S2 | D4.T2.S2, D4.T2.S2.Q1 |
| TS 4.2 S3 | D4.T2.S1, D4.T2.S1.Q2, D4.T2.S2.Q1 |
| TS 4.2 S4 | D4.T2.S2, D4.T2.S2.Q3 |
| TS 4.2 S5 | D4.T2.S2, D4.T2.S2.Q2 |
| TS 4.3 K1 | D4.T3.S1, D4.T3.S1.Q1 |
| TS 4.3 K2 | D4.T3.S1, D4.T3.S1.Q2 |
| TS 4.3 K3 | D4.T3.S1.Q1 |
| TS 4.3 K4 | D4.T3.S2, D4.T3.S2.Q1, D4.T3.S2.Q2 |
| TS 4.3 S1 | D4.T3.S1, D4.T3.S1.Q1 |
| TS 4.3 S2 | D4.T3.S1, D4.T3.S1.Q3 |
| TS 4.3 S3 | D4.T3.S1, D4.T3.S1.Q4 |
| TS 4.3 S4 | D4.T3.S2, D4.T3.S2.Q1 |
| TS 4.3 S5 | D4.T3.S2, D4.T3.S2.Q2 |
| TS 4.3 S6 | D4.T3.S2, D4.T3.S2.Q3 |
| TS 4.4 K1 | D4.T4.S1, D4.T4.S1.Q1 |
| TS 4.4 K2 | D4.T4.S1, D4.T4.S1.Q2 |
| TS 4.4 K3 | D4.T4.S2, D4.T4.S2.Q1, D4.T4.S2.Q3 |
| TS 4.4 K4 | D4.T4.S1, D4.T4.S1.Q3 |
| TS 4.4 S1 | D4.T4.S1, D4.T4.S1.Q1 |
| TS 4.4 S2 | D4.T4.S1, D4.T4.S1.Q2 |
| TS 4.4 S3 | D4.T4.S2, D4.T4.S2.Q1 |
| TS 4.4 S4 | D4.T4.S2, D4.T4.S2.Q2 |
| TS 4.5 K1 | D4.T5.S1, D4.T5.S1.Q2 |
| TS 4.5 K2 | D4.T5.S1, D4.T5.S1.Q1 |
| TS 4.5 K3 | D4.T5.S1, D4.T5.S1.Q3 |
| TS 4.5 K4 | D4.T5.S1.Q2, D4.T5.S2, D4.T5.S2.Q2 |
| TS 4.5 S1 | D4.T5.S1, D4.T5.S1.Q1 |
| TS 4.5 S2 | D4.T5.S2, D4.T5.S2.Q1 |
| TS 4.5 S3 | D4.T5.S2, D4.T5.S2.Q2 |
| TS 4.5 S4 | D4.T5.S2, D4.T5.S2.Q3 |
| TS 4.6 K1 | D4.T6.S1, D4.T6.S1.Q1 |
| TS 4.6 K2 | D4.T6.S1, D4.T6.S1.Q1 |
| TS 4.6 K3 | D4.T6.S2, D4.T6.S2.Q1, D4.T6.S2.Q2 |
| TS 4.6 S1 | D4.T6.S1, D4.T6.S1.Q1 |
| TS 4.6 S2 | D4.T6.S2, D4.T6.S2.Q1, D4.T6.S2.Q2 |
| TS 4.6 S3 | D4.T6.S1, D4.T6.S1.Q2 |
| TS 5.1 K1 | D5.T1.S1, D5.T1.S1.Q1 |
| TS 5.1 K2 | D5.T1.S2, D5.T1.S2.Q2 |
| TS 5.1 K3 | D5.T1.S2, D5.T1.S2.Q1 |
| TS 5.1 K4 | D5.T1.S1, D5.T1.S1.Q2 |
| TS 5.1 S1 | D5.T1.S1, D5.T1.S1.Q1 |
| TS 5.1 S2 | D5.T1.S1, D5.T1.S1.Q3 |
| TS 5.1 S3 | D5.T1.S2, D5.T1.S2.Q1 |
| TS 5.1 S4 | D5.T1.S2, D5.T1.S2.Q2 |
| TS 5.1 S5 | D5.T1.S2, D5.T1.S2.Q2 |
| TS 5.1 S6 | D5.T1.S2, D5.T1.S2.Q1 |
| TS 5.2 K1 | D5.T2.S1, D5.T2.S1.Q2 |
| TS 5.2 K2 | D5.T2.S2, D5.T2.S2.Q1 |
| TS 5.2 K3 | D5.T2.S1, D5.T2.S1.Q1, D5.T2.S1.Q2 |
| TS 5.2 K4 | D5.T2.S2, D5.T2.S2.Q2 |
| TS 5.2 S1 | D5.T2.S1, D5.T2.S1.Q1 |
| TS 5.2 S2 | D5.T2.S2, D5.T2.S2.Q1 |
| TS 5.2 S3 | D5.T2.S2, D5.T2.S2.Q1 |
| TS 5.2 S4 | D5.T2.S1, D5.T2.S1.Q3 |
| TS 5.2 S5 | D5.T2.S2, D5.T2.S2.Q2 |
| TS 5.3 K1 | D5.T3.S1, D5.T3.S1.Q1 |
| TS 5.3 K2 | D5.T3.S2, D5.T3.S2.Q2 |
| TS 5.3 K3 | D5.T3.S1, D5.T3.S1.Q2 |
| TS 5.3 K4 | D5.T3.S2, D5.T3.S2.Q1 |
| TS 5.3 S1 | D5.T3.S1, D5.T3.S1.Q1 |
| TS 5.3 S2 | D5.T3.S2, D5.T3.S2.Q2 |
| TS 5.3 S3 | D5.T3.S2, D5.T3.S2.Q1 |
| TS 5.3 S4 | D5.T3.S2, D5.T3.S2.Q2 |
| TS 5.4 K1 | D5.T4.S1, D5.T4.S1.Q1 |
| TS 5.4 K2 | D5.T4.S1, D5.T4.S1.Q2 |
| TS 5.4 K3 | D5.T4.S2, D5.T4.S2.Q1 |
| TS 5.4 K4 | D5.T4.S2, D5.T4.S2.Q2 |
| TS 5.4 S1 | D5.T4.S2, D5.T4.S2.Q1 |
| TS 5.4 S2 | D5.T4.S1, D5.T4.S1.Q2 |
| TS 5.4 S3 | D5.T4.S2, D5.T4.S2.Q1 |
| TS 5.4 S4 | D5.T4.S2, D5.T4.S2.Q2 |
| TS 5.4 S5 | D5.T4.S1, D5.T4.S1.Q1 |
| TS 5.5 K1 | D5.T5.S1, D5.T5.S1.Q1 |
| TS 5.5 K2 | D5.T5.S1, D5.T5.S1.Q2 |
| TS 5.5 K3 | D5.T5.S2, D5.T5.S2.Q1 |
| TS 5.5 K4 | D5.T5.S1, D5.T5.S1.Q1 |
| TS 5.5 S1 | D5.T5.S1, D5.T5.S1.Q2 |
| TS 5.5 S2 | D5.T5.S1, D5.T5.S1.Q1 |
| TS 5.5 S3 | D5.T5.S2, D5.T5.S2.Q1 |
| TS 5.5 S4 | D5.T5.S2, D5.T5.S2.Q2 |
| TS 5.6 K1 | D5.T6.S1, D5.T6.S1.Q1 |
| TS 5.6 K2 | D5.T6.S1, D5.T6.S1.Q1 |
| TS 5.6 K3 | D5.T6.S2, D5.T6.S2.Q1 |
| TS 5.6 K4 | D5.T6.S2, D5.T6.S2.Q2 |
| TS 5.6 S1 | D5.T6.S1, D5.T6.S1.Q1 |
| TS 5.6 S2 | D5.T6.S1, D5.T6.S1.Q2 |
| TS 5.6 S3 | D5.T6.S2, D5.T6.S2.Q1 |
| TS 5.6 S4 | D5.T6.S2, D5.T6.S2.Q2 |
| TS 5.6 S5 | D5.T6.S2, D5.T6.S2.Q2 |

## (b) Official sample questions -> leaves

| Sample Q | Answerable by composing leaves | Domain tested |
|---|---|---|
| Q1 | D1.T4.S1.Q1, D1.T4.S1.Q2, D1.T5.S2.Q3 | D1 |
| Q2 | D2.T1.S1.Q1, D2.T1.S1.Q2, D2.T1.S1.Q4 | D2 |
| Q3 | D5.T2.S1.Q1, D5.T2.S1.Q2 | D5 |
| Q4 | D3.T2.S1.Q1 | D3 |
| Q5 | D3.T4.S1.Q1, D3.T4.S1.Q3 | D3 |
| Q6 | D3.T3.S2.Q1, D3.T3.S2.Q2 | D3 |
| Q7 | D1.T2.S2.Q1, D1.T2.S1.Q4 | D1 |
| Q8 | D5.T3.S1.Q1, D5.T3.S2.Q1 | D5 |
| Q9 | D2.T3.S1.Q2, D2.T3.S1.Q1 | D2 |
| Q10 | D3.T6.S1.Q1 | D3 |
| Q11 | D4.T5.S1.Q1, D4.T5.S1.Q2 | D4 |
| Q12 | D4.T6.S2.Q1, D4.T6.S2.Q2, D1.T6.S2.Q1 | D4 |

## (c) Orphan ledger

- ZERO orphans: all 113 knowledge bullets and 127 skills bullets are cited by at least one L3/L4 node (verified programmatically by this script).

## (d) Weight proportionality (leaves per domain vs domain weight, tolerance +/- 5pp)

| Domain | Weight | Leaves | Leaf share | Within +/-5pp |
|---|---|---|---|---|
| D1 Agentic Architecture & Orchestration | 27% | 46 | 26.9% | YES |
| D2 Tool Design & MCP Integration | 18% | 31 | 18.1% | YES |
| D3 Claude Code Configuration & Workflows | 20% | 34 | 19.9% | YES |
| D4 Prompt Engineering & Structured Output | 20% | 34 | 19.9% | YES |
| D5 Context Management & Reliability | 15% | 26 | 15.2% | YES |

Total leaves: 171

## (e) Non-commuting-pairs ledger (W3b MINOR-6)

Bullets whose leaf-level citations span two sibling L3 subtrees of the same topic. For these,
the parallel-associativity licence ('study/verify sibling subtrees in any order') must be checked,
not assumed - the shared bullet couples the subtrees. Cross-topic (L2) sharing remains ZERO, so the
licence holds unconditionally at topic level and above.

| Bullet | Coupled L3 subtrees |
|---|---|
| TS 1.1 K3 | D1.T1.S1, D1.T1.S2 |
| TS 1.2 K4 | D1.T2.S1, D1.T2.S2 |
| TS 1.5 K3 | D1.T5.S1, D1.T5.S2 |
| TS 1.7 K4 | D1.T7.S1, D1.T7.S2 |
| TS 4.2 S3 | D4.T2.S1, D4.T2.S2 |
| TS 4.5 K4 | D4.T5.S1, D4.T5.S2 |
