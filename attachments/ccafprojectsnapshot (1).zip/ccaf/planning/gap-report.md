# GAP REPORT — CCAF Exam-Mastery Pipeline

**Companion to** `META-PLAN.md` (same directory). **Status:** `ready_for_approval` — not blocked.
**Human-of-record:** Manu (named, reachable, present in session).
**Rule:** nothing spawns until `approvals/CP-0.md` exists on disk, recorded by Manu. `recorded_by` must be a named human — an agent may never mint it (IC-7). The graph fails closed.

---

## 1. VERIFICATION PATH (the spawned probe, and what replaces it)

The generator's mandatory minimum is a **spawned** fresh-agent probe on ≥1 context packet. It was **skipped at plan time by instruction** — the orchestrator will run it live instead. This is a disclosed deviation, not an omission.

**Chosen path — W1 is the live probe.** Pulse 1's second unit (`W1 — Objective registry merge`) is spawned with its rendered ExecutorPrompt and **must**, in its `solution_sketch` and *before it builds anything*, restate from the prompt alone: (i) its job, (ii) its inputs and their locations, (iii) its done-check, (iv) its upstream and downstream neighbors. Any reach for outside knowledge, or any request for information the packet should have carried, is **a finding against this meta-plan's packet-writing habit** — not against the executor.

**Why W1 and not another unit:** per `execution-handoff.md` §3, probe the unit whose half-failure hurts most. W1 produces `objectives.json`, the frozen spine; a silent objective loss there propagates through the tree, the wiki, and the volume and is discovered only at the exam.

**Repair rule if the probe fails:** halt Pulse 1, repair W1's packet, and re-render **every remaining packet** against the same defect before continuing. This rests on the named assumption that packet defects are *planner-systemic* rather than unit-local (falsifier: W1's packet passes but later packets block at material rates — if that happens, probe one unit per lane-set instead).

**Secondary probe, free of charge:** the fable agent's round-1 `solution_sketch` (W2) is the legibility probe for **W2p's** output, the composed tree meta-prompt. Because sketches are gated *before* build, a failed restatement costs no I8 round. This is also how W2p — an opus-produced artifact — satisfies I7 without a second opus reviewer.

**Honest scope:** the probe checks *legibility* (can a cold agent restate the packet), not *executability* (whether the work succeeds). The done-checks cover the latter.

---

## 2. UNKNOWNS LEDGER — every entry spiked or assumed-with-falsifier

| ID | Unknown | Resolution | Owner | Falsifier / spike output |
|---|---|---|---|---|
| **U1** | **Workspace root divergence.** `/home/claude/work/ccaf/` holds only an empty `extraction/`; `/root/work/ccaf/` holds `extraction/ notebook/ plan/ question-tree/ skills-attached/ wiki/`. `/home/claude` is **not** a symlink to `/root` (verified). The brief names `/home/claude/...` for both the extraction outputs and `field-notebook-craft`, but the skill actually exists **only** at `/root/work/ccaf/skills-attached/field-notebook-craft/SKILL.md`. | **SPIKE — W0, ~2 min, haiku.** Emits `PATHS.json` declaring `canonical_root`. Mitigated now: this report and `META-PLAN.md` are written to **both** `plan/` directories. | Orchestrator | Both roots contain non-empty and *differing* shard sets ⇒ W0 HALTs; Manu picks the root. |
| **U2** | **Extraction shard schema and page partition.** The four sonnet agents were still in flight at plan time; both `extraction/` dirs were empty. Whether they agree on schema, and whether their page ranges tile 5–39 without gaps, is unknown. | **SPIKE — inside W1.** W1 emits `extraction-gaps.md` enumerating unclaimed pages and shard disagreements. | W1 | Any unclaimed page range ⇒ **replan trigger**: insert a targeted re-extraction unit (sonnet, +1 agent, ~60k). W1 must **never** interpolate a missing objective. |
| **U3** | **Total atomic objective count.** Pages 1–6 show 5 domains and, for D1 alone, task statements 1.1/1.2/1.3 with ~3 *Knowledge of* + ~4 *Skills in* bullets each. | **ASSUMPTION:** 5 domains × 3–5 task statements × ~6–7 bullets ≈ **100–160 objectives**. | Meta-planner | W1's reported count falls outside **60–250** ⇒ re-tune the tree fan-out and the fable round budget before spawning W2. |
| **U4** | **Fable "2 response rounds" semantics** — 2 messages total, or initial + 1 revision? | **ASSUMPTION:** initial + one consolidated revision (IC-8 is built on this). | Orchestrator | Round 1 truncates, or a third round is needed ⇒ **replan**: shard W2 into two fable agents by domain (D1–D3 / D4–D5), ≤2 rounds each. +1 agent, ~90k. |
| **U5** | **Is operadic consistency machine-checkable?** | **ASSUMPTION:** *structural* OC is script-checkable (every parent's `composition_rule` references exactly its own children's slots; type/colour transitions are legal), *semantic* OC requires opus judgment (composed vs. collapsed answers). Both are gated at G-1b. | W3b | `check_tree.py` passes a tree that W3b judges incoherent ⇒ the script's rule set is under-specified; it must be strengthened before it is trusted as a gate anywhere else. |
| **U6** | **Device-folder grant** for `CETI/CERTIFICATIONS/CCAF` is pending. | **ASSUMPTION + FALLBACK:** grant arrives by Pulse 4. If not, deliver via `SendUserFile` + retain the container bundle; `PROJECT-STATE.md` records `delivery: PENDING_GRANT`. | Manu | Grant still pending at CP-4 ⇒ fallback fires. **Delivery mode is not a success criterion** — the pipeline completes either way. |
| **U7** | **Which official pages are canonical per exam domain**, and whether any exam topic has no official doc page at all. | **SPIKE — W4** (opus), before any bulk fetching. Emits `doc-corpus-index.json` + an `orphan_topic` list. | W4 | A topic with no official page is a *finding about docs-vs-guide drift* (S4), recorded — **never** patched with a third-party source. |
| **U8** | **NotebookLM 12-hour course** does not exist yet; its content and its agreement with the docs are unknown. | **ASSUMPTION:** enrichment is a later noether-wiki GROW pass. The wiki must be shaped so folding it in requires no restructuring. | W6 / future session | Course content contradicts a wiki claim ⇒ run the conservation-law audit and update the claim's stamp — **not** a wiki rewrite. If a rewrite is forced, the GROW-shaping assumption was wrong. |
| **U9** | **How much may the orchestrator read** under I6 without becoming the bottleneck it is forbidden to be? | **ASSUMPTION:** manifests, verdict files, counts, and machine-check exit codes only — ≤200 lines per read. The registry, tree, and wiki are read by executors, never by the orchestrator. | Orchestrator | A gate becomes unverifiable without a bulk read ⇒ that gate is mis-designed; route it to a named opus reviewer instead of relaxing I6. |

**Ledger discipline note:** this ledger must **not grow** across pulses. Growth over two consecutive pulses is a stop-the-line trigger (drift check D4).

### Where human input is genuinely required (not merely nice to have)
1. **CP-0** — approval of this report before any spawn (structural; fails closed).
2. **CP-1** — the tree's shape. This is the one place where a wrong "yes" is expensive: freezing the tree is what makes four parallel lanes safe, and unfreezing it after Pulse 1 invalidates wiki anchors *and* notebook plates.
3. **CP-4** — the device write, the pipeline's only externally-visible action.
4. **U1 tie-break** if W0 finds two divergent workspace roots.
5. Any **stop-the-line** escalation (halt is indefinite until Manu responds).

---

## 3. TIER DERIVATION (shown, not asserted)

| Tier-determining fact | Value | Effect |
|---|---|---|
| Work units | **17** (23 agent-spawns) | > 5 ⇒ above Tier 1 |
| Irreversible actions **inside** the pipeline | **0** — every output is a file in the container | no Tier-3 pressure |
| Externally-visible actions | **1** — the Pulse-4 device commit (`force=false`, `expectedMtimeMs` set, nothing deleted, human-gated at CP-4, fallback stated) | reversible-with-care |
| …but its reversibility is | **UNKNOWN until the grant resolves (U6)** | **an "unknown" among tier facts ⇒ escalate one tier** |
| Parallel lane-sets | **4** (LS-1 wiki ×5 · LS-2 notebook build ×2 · LS-3 blinded audit pair · LS-4 persistence pair) | > 1 ⇒ Tier 3 *by the letter* |
| External stakeholders | **Yes** — Anthropic Certification Program (not in the room), other candidates if the volume is shared, the doc authors cited | ⇒ Tier 3 *by the letter* |

**Letter of the protocol: Tier 3.**

**What was actually run, and the recommendation: Tier 2 at generation time, with Tier-3-equivalent independence purchased at execution time.**

The generation-time audit of `META-PLAN.md` was **Tier 2** — three sequential lenses (OPUS → FABLE → MERCURIO) in separate sittings by one agent, plus an OPUS re-pass on changed slots, reaching a fixpoint in 4 passes of a 6-pass budget. All twelve findings and the DEFERRED list are in `META-PLAN.md` §11.

Four reasons for the deviation, offered so Manu can overrule with full information:

1. **Nothing inside the pipeline is irreversible.** Every unit produces files in a container; the worst half-failure is wasted tokens and a directory to delete.
2. **The one externally-visible action is already maximally gated** — human checkpoint, mtime guard, `force=false`, no deletions, and a stated fallback under which the pipeline still counts as complete.
3. **The independence Tier 3 buys is already in the execution graph.** `execution-handoff.md` §3's Tier-3 rule is "probe one unit per parallel lane-set." This plan does better: it staffs **six independent opus reviewers at the lane-set boundaries** — W1R (spine), W3a **blinded against** W3b (tree), W7 (wiki), W10 (volume), W13 (delivery) — each required to produce *quoted evidence*, with a PASS-without-evidence recorded as FAIL. Independence is bought where the artifacts are, not where the document is.
4. **Four human checkpoints already review this document's consequences.** Spending three more opus subagents to blind-audit an L2 document that Manu will see the output of four separate times is disproportionate.

**Cost of overruling** (Manu's call, and a legitimate one): +3 opus subagents, ~250k tokens, and one extra round-trip before Pulse 1 begins.

**Not negotiable regardless of tier:** the evidence requirement on every gate verdict, the blinding of W3a/W3b, and I12 (exam integrity).

---

## 4. CHECKPOINT LIST FOR THE HUMAN-OF-RECORD (Manu)

Approve the **placement** of these checkpoints now, not just their eventual firing. Approval of this list is the typed artifact `approvals/CP-0.md`, declared as an input to **every root work unit** (W0 and W2p) — so no entry point of the graph, including the parallel root, can spawn before it exists.

| ID | When | What Manu is approving | If it is refused |
|---|---|---|---|
| **CP-0** | **Before any spawn** | This gap report: the checkpoint placements, the Tier-2 deviation, the ~2M-token estimate, and the top five risks. | Nothing spawns. The graph fails closed. |
| **CP-1** | End of Pulse 1 (after G-1) | **The DEPTH-4 question tree** — coverage matrix (I1), weight proportionality (I11), askability (I2), and the OC report (I3). *"Is this the tree you want to be examined by?"* **On approval the tree structure freezes**; answer slots become append-only (IC-4). | Fable's round 2 is spent on one consolidated revision packet (IC-8). If round 2 is already spent, this is a replan: shard the tree across two fresh fable agents. |
| **CP-2** | End of Pulse 2 (after G-2) | **The wiki + symmetry ledger** — official-URL-only sourcing, the visible first-pass fallibility stamp, the guide-baseline-vs-live-docs partition (S4), and the recorded `guide_vs_docs` conflicts. *"Do you accept this docs-drift posture?"* | Re-scope W4's corpus index and re-run the affected domain lanes only (per-domain dirs make this cheap). |
| **CP-3** | End of Pulse 3 (after G-3) | **The field-notebook volume** — the enact test plate by plate, single-file/offline, weight-proportional plate counts, working interactions, stamp visible in the rendered page. *"Does it teach when you touch it, or only when you read it?"* | Re-spec (W8) and rebuild the payload lane (W9b) only; the shell survives. |
| **CP-4** | End of Pulse 4 (after G-4) | **The device write** to `CETI/CERTIFICATIONS/CCAF` — the pipeline's only externally-visible action — plus the final coverage re-run, the MANIFEST hash check, and the I12 integrity statement. | The fallback fires: `SendUserFile` + container bundle; `PROJECT-STATE.md` records `PENDING_GRANT`. **This is not a failure.** |
| **STOP** | Any time | Stop-the-line escalations: two replans without progress · blast radius reclassified upward · unknowns ledger growing across two pulses · mtime-drift rejection at the device commit · any agent proposing to ingest non-official or leaked exam material (I12) · any agent proposing to mint an approval record. | **A halt is indefinite until Manu responds.** An unanswered escalation is never license to resume. |

---

## 5. ORDER-OF-MAGNITUDE COST ESTIMATE

Agent count × rough tokens (input + output per spawn). Estimates are order-of-magnitude, not measurements.

| Pulse | Unit | Model | Spawns | ~Tokens |
|---|---|---|---|---|
| P1 | W0 path/shard recon | haiku | 1 | 5k |
| P1 | W1 registry merge *(live probe)* | sonnet | 1 | 75k |
| P1 | W1R registry review | opus | 1 | 90k |
| P1 | W2p compose tree meta-prompt | opus | 1 | 70k |
| P1 | W2 tree build (2 rounds) | **fable** | 1 | 130k |
| P1 | W3a coverage + proportionality | opus | 1 | 130k |
| P1 | W3b clarity + OC | opus | 1 | 130k |
| P2 | W4 doc corpus map | opus | 1 | 60k |
| P2 | W5a–e per-domain wiki | sonnet | **5** | 300k |
| P2 | W6 symmetry ledger + fan-in | opus | 1 | 90k |
| P2 | W7 wiki review | opus | 1 | 90k |
| P3 | W8 notebook corpus spec | opus | 1 | 100k |
| P3 | W9a shell / W9b payload | sonnet | 2 | 160k |
| P3 | W9m assembly | sonnet | 1 | 50k |
| P3 | W10 notebook review | opus | 1 | 90k |
| P4 | W11 persistence layer | sonnet | 1 | 40k |
| P4 | W12 meta-mvp spec (build deferred) | opus | 1 | 40k |
| P4 | W13 final review + delivery | opus | 1 | 60k |
| | **Executor subtotal** | | **23** | **≈ 1.71M** |
| | Orchestrator overhead (spawns, gates, fan-ins, manifests — bounded by I6) | fable | — | ≈ 150k |
| | Contingency: 1 gate re-run + 1 replan (U2 re-extraction *or* U4 fable shard) | | +1–2 | ≈ 300k |
| | **TOTAL** | | **23–25 agents** | **≈ 2.0M tokens (band 1.5–2.5M)** |

**Mix:** 11 opus (~950k, the dominant cost), 9 sonnet (~625k), 1 fable (~130k), 1 haiku (~5k), plus orchestrator. Within the stated 15–25 agent budget.

**Wall clock:** four pulses. Machine time is roughly 30–50 min per pulse with the lanes running concurrently; **the real latency is Manu's four checkpoint responses**, which is the intended trade (I10).

**Two cost levers if the estimate is too high (each with its stated loss):**
- **Merge W3a + W3b into one opus gate** — saves ~130k, **loses blinding**, which was FABLE finding #3 and is the main defense against a single reviewer anchoring coverage judgments on clarity impressions. *Not recommended.*
- **Downgrade W8 (notebook spec) and W12 (meta-mvp spec) to sonnet** — saves ~90k, requires an opus review of each to preserve I7, which gives most of it back. *Marginal.*
- **The honest lever:** cut Pulse 3 (the volume) entirely and ship tree + wiki + persistence. Saves ~490k and 5 agents. The tree and wiki are the exam-passing artifacts; the volume is the artifact that makes studying them pleasant. *This is Manu's call about what he'll actually use.*

---

## 6. TOP RISKS

| # | Risk | Blast radius | Mitigation already in the plan | Residual |
|---|---|---|---|---|
| **1** | **Coverage illusion (I1 satisfied structurally, violated semantically).** Leaves that name an objective without testing it — the single failure mode that produces a confident candidate with silent holes, discovered only at the exam. | Manu; $125 + a 120-minute sitting | W3a runs the mechanical matrix **and** judges a ≥10%/min-15 sample against *"would answering this leaf actually demonstrate its objective?"*, quoting each judgment. A structural-only pass is a FAIL. Plus I11 proportionality. | Sampling is not exhaustive. Raise the sample rate at CP-1 if Manu wants. |
| **2** | **Docs drift vs. the July 2026 exam baseline.** Live official docs may describe post-guide behavior. A wiki claim can be simultaneously true of the product and **wrong for the exam** (second-order relation S4). | Manu memorizes a stale or premature API | Official hosts only (I5); `fetched_at` on every claim; the fallibility stamp rendered in the volume, not just filed in source; the symmetry ledger **partitions** `corpus-conserved` from `guide-baseline-conserved`; `guide_vs_docs_conflict` flags adjudicated at W6/W7; NotebookLM enrichment folds in later via GROW (U8). | The exam guide itself says "subject to change without notice." Irreducible; managed by stamping, not by pretending. |
| **3** | **Fable round budget vs. tree size (U4).** A 5×~4×~4×~3 depth-4 tree is ~250–400 nodes — plausibly more than one fable response, with only 2 rounds available (I8). | The tree, and therefore every downstream unit | W2p exists solely to make round 1 land (its quality is probed by the fable round-1 sketch); explicit continuation-marker protocol instead of silent truncation; a pre-declared replan (shard into two fable agents by domain) rather than an improvised third round. | If both fable agents also truncate, the tree must be built at opus tier — a real plan change, escalated. |
| **4** | **Environment assumptions: workspace root divergence (U1) + pending device grant (U6).** Two live `work/ccaf` trees on disk that are not the same directory, the brief's `field-notebook-craft` path not existing where stated, and no grant yet on the delivery target. | Artifacts split across two trees; Pulse 4 delivery blocked | W0 is a 2-minute haiku spike resolving `canonical_root` before anything writes; the plan documents are mirrored to both `plan/` dirs now; delivery has a stated fallback under which the pipeline still completes. | If the extraction agents have already written to the *other* root, W0 HALTs for Manu's tie-break. Cheap to detect, cheap to fix. |
| **5** | **Gate theater + exam-integrity drift.** Five opus reviewers could rubber-stamp ("looks comprehensive"), which under I6 the orchestrator cannot detect — it never reads the artifacts. Separately, an agent could drift toward reconstructing secured exam items rather than deriving questions from public objectives. | Every quality claim in the pipeline becomes unbacked; Anthropic Certification Program (not in the room) bears the integrity harm | **Every verdict must carry named evidence** — quoted samples, counts, exit codes — and a PASS without evidence is recorded as FAIL by the orchestrator. W3a/W3b are blinded from each other. **I12** is an invariant in every executor's constitution, specified in W12's spec, gated at W13, and any proposal to ingest non-official or leaked material is a **stop-the-line trigger**. | An opus reviewer could still fabricate evidence. Backstop: Manu's four checkpoints look at the evidence, not the verdict. |

---

## 7. WHAT MANU IS BEING ASKED TO APPROVE, IN ONE PARAGRAPH

Twenty-three agents across four pulses, roughly two million tokens, producing only files — a verified objective registry, a depth-4 operadic question tree covering every exam objective and OC-checked for consistency, a five-domain wiki of official Anthropic docs where every claim is cited and stamped fallible, an interactive single-file field-notebook volume, and a persistence layer that lets a future session start warm. Four checkpoints, of which **CP-1 (the tree) matters most** and **CP-4 (the device write) is the only externally-visible action**. Audited at Tier 2 with the reasoning shown above and the independence bought at execution time instead. Nothing spawns until `approvals/CP-0.md` exists.
