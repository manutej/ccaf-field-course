# DECISIONS.md — append-only decision log

- **D-1 (2026-08-01, Manu, CP-0):** Approve META-PLAN; execute **Pulse 1 only**; re-approve before Pulse 2+. Full field notebook approved in principle for this session (biggest cost item retained).
- **D-2 (2026-08-01, Manu):** Delivery = device grant dialog → granted; all artifacts commit to CETI/CERTIFICATIONS/CCAF at CP-4 (+ SendUserFile cards along the way).
- **D-3 (2026-08-01, orchestrator):** Registry schema = the nested `registry.json` (domains[].task_statements[]) given in W1's packet, NOT META-PLAN IC-1's flat `objectives.json`. W1 flagged the conflict; nested schema is canonical from here. (Planner finding logged; META-PLAN not retro-edited — plan history is append-only.)
- **D-4 (2026-08-01, orchestrator):** W1 shard gaps (6 scenario narrative texts pp.3–4; Domain 5 section overview) patched by a dedicated sonnet patch agent BEFORE W1R review — tree builder needs scenario narratives for scenario_hooks.
- **D-5 (2026-08-01, Manu, mid-turn):** Persistence scaffolding (CLAUDE.md, HANDOFF.md, planning/, decision+status logs) created NOW and maintained at every checkpoint, not deferred to Pulse 4.
- **D-6 (2026-08-01, plan):** Audit Tier 2 with execution-time independence (blinded dual opus reviewers at boundaries) instead of Tier 3; rationale in planning/gap-report.md.
- **D-7 (2026-08-01, plan):** Fable cap: max 2 response rounds per fable agent → round 1 builds tree, round 2 applies review findings. If tree >~400 nodes forces overflow, pre-declared replan: shard across two fable agents by domain.
- **D-8 (2026-08-01, gates):** W1R FAIL remediated in-place (F-1..F-6), re-verified PASS-WITH-MINORS; residuals F-7/F-8 deferred as MINOR.
- **D-9 (2026-08-01, gates):** Tree round 2 applied ALL W3a (6 MINOR) + W3b (5 MAJOR, 9 MINOR) findings; TRADEOFF re-witnessed at D2.T3.S1; root recomposed as AND of domain answers with tree_invariants moved to meta. Fable cap for tree builder now exhausted (2/2).
