# STATUS.md — pulse-by-pulse status ledger (newest first)

## 2026-08-01 — Pulse 1 (COMPLETE — at CP-1)
| Step | Owner | Status | Output |
|---|---|---|---|
| Extraction shards ×4 | sonnet ×4 | ✅ | extraction/part-{1..4}.md |
| META-PLAN generation | opus | ✅ | planning/META-PLAN.md, gap-report.md |
| CP-0 approval | Manu | ✅ Pulse 1 only | planning/DECISIONS.md D-1 |
| W1 registry merge (live probe) | sonnet | ✅ probe PASS | extraction/registry.{json,md} |
| Device folder + grant | orchestrator | ✅ | CETI/CERTIFICATIONS/CCAF |
| Persistence scaffolding | orchestrator | ✅ | CLAUDE.md, HANDOFF.md, planning/ |
| W1-patch (scenarios; no D5 overview in source) | sonnet | ✅ | registry.{json,md} updated |
| W1R registry review (FAIL→fixes→PASS-W-MINORS) | opus | ✅ | extraction/W1R-review.md |
| W2p operadic tree round 1 (267 nodes, 100% cov) | fable | ✅ | question-tree/* |
| W3a/W3b blinded reviews (0 BLOCKER; 5 MAJ fixed) | opus ×2 | ✅ | question-tree/reviews/* |
| Fable round 2 revision (all findings applied) | fable | ✅ | question-tree/* v2 |
| CP-1 | Manu | 🔄 awaiting | — |

## Registry headline numbers
5 domains (27/18/20/20/15), 30 task statements, 113 knowledge + 127 skills bullets, 12 sample questions, 6 scenarios, 18 in-scope / 16 out-of-scope topics. Exam: 60 items / 120 min / $125 / pass 720/1000 / valid 12 mo / effective July 2026 (v1.0).

## Tree headline numbers (post round 2)
267 nodes: root + 5 domains + 30 topics + 60 subtopics + 171 leaves (D1 46, D2 31, D3 34, D4 34, D5 26). Coverage 240/240 bullets, 0 orphans, 0 phantom cites. Proportionality max Δ0.2pp. 12/12 sample questions mapped to leaves. 60 ★ high-yield leaves marked. Colored answer types on all nodes; scope-clamped OC protocol; 9 collapse tests executed during review.
