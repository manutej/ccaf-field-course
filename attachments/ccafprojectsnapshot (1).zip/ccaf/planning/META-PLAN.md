# META-PLAN — CCAF Exam-Mastery Pipeline (L2)

**Produced by:** `/meta-planning` generator (`references/meta-meta-planning-prompt.md`, canonical) run at opus tier.
**Deliverable level:** L2 — the typed planning instrument. The L1 pulse plan is instantiated inside (§ *Instantiated L1 Plan*).
**Companion:** `gap-report.md` (unknowns, tier derivation, checkpoints, cost, risks) — **read and approved by the human-of-record BEFORE any spawn.**
**Date:** 2026-08-01. **Human-of-record:** Manu (present in session, reachable).

---

## 0. LEVEL CHECK

| Question | Answer |
|---|---|
| Input class | **Hybrid.** `task_to_plan_for` is an *instance* (CCAF, exam code CCAR-F) of a *category*, and one of its stages (B) is defined by a *composed meta-prompt* (meta-prompting × operadic-interview × meta-operad). The meta-prompt pathway of `domain-mapping.md` §4 therefore applies to stage B. |
| **CATEGORY the meta-plan serves** | **BLUEPRINT → TREE → WIKI → VOLUME → PERSIST**: converting any *weighted, blueprinted, scenario-framed certification exam guide* into (i) a depth-N typed operadic question tree with total objective coverage, (ii) a provenance-stamped wiki of the vendor's live official docs, (iii) an interactive editorial study volume, and (iv) a warm-start persistence layer — executed by a hub-spoke agent fleet under a context-hygienic orchestrator. |
| Sibling tasks this must also fit (overfit test) | AWS Solutions Architect Associate guide; CNCF CKA curriculum; Google Cloud PCA guide. Each supplies a weighted domain list + task statements + a live vendor doc corpus. The meta-plan is written against those slots, not against CCAF strings. |

### Free variables (per-instance slots)

```
EXAM_GUIDE          : PDF | pages | authority date        [CCAF: 39pp, v1.0, effective July 2026]
DOMAIN_SET          : list[{id, name, weight_pct}]        [CCAF: 5 domains, 27/18/20/20/15]
SCENARIO_SET        : list[{id, narrative, primary_domains}]  [CCAF: 6 scenarios, 4 sampled per sitting]
ITEM_MODEL          : {count, format, scoring, time}      [CCAF: 60 items, MC+MR, scaled 720/1000, 120 min]
TREE_DEPTH          : int                                  [CCAF: 4]
DOC_CORPUS          : list[authoritative domains]          [CCAF: docs.claude.com, anthropic.com]
DELIVERY_TARGET     : device path | fallback               [CCAF: CETI/CERTIFICATIONS/CCAF — grant pending]
HUMAN_OF_RECORD     : named human                          [CCAF: Manu]
AGENT_TIERS         : {fable, opus, sonnet, haiku}         [as supplied]
```

### Invariants (what every plan generated from this meta-plan must preserve)

| ID | Invariant | Where enforced |
|---|---|---|
| **I1 COVERAGE CLOSURE** | Every atomic objective (every *Knowledge of* / *Skills in* bullet under every task statement) maps to ≥1 depth-4 leaf question. | IC-6 coverage matrix; gate G-1a |
| **I2 NODE TOTALITY** | Every node at every depth is a *full askable question* with its own answer slot. No bare labels. | IC-2 schema check; gate G-1b |
| **I3 OPERADIC CONSISTENCY (OC)** | At each internal node, the answer obtained by *composing* children's answers agrees with the answer obtained by *collapsing* the subtree. Disagreement is localized to a node, not reported globally. | Gate G-1b (structural = script, semantic = opus) |
| **I4 STATED COMPOSITION** | Every internal node carries an explicit upward `composition_rule` naming exactly its own children's slots. | IC-2 |
| **I5 PROVENANCE + FALLIBILITY** | Every wiki claim cites an official URL with a fetch timestamp and carries the first-pass fallibility stamp. | IC-3; gate G-2 |
| **I6 ORCHESTRATOR CONTEXT HYGIENE** | The orchestrator never reads the PDF or bulk agent outputs. It reads manifests, counts, verdicts, and machine-check exit codes only (≤200 lines per read). | Every `done` is a MachineCheck **or** a named reviewer agent |
| **I7 REVIEW ASYMMETRY** | Anything produced by an opus-or-lower agent is reviewed by an **opus agent that did not produce it**. | Gates G-0…G-4 |
| **I8 FABLE ROUND CAP** | Each fable agent gets ≤2 response rounds. Revisions arrive as **one consolidated packet**, never as iterative nudges. | IC-8; W3m fan-in |
| **I9 REVERSIBILITY** | All outputs are files inside the container. The only externally-visible write is the Pulse-4 device commit, which is human-gated and mtime-guarded. | FailureSemantics; CP-4 |
| **I10 PULSE DISCIPLINE** | Execution proceeds in 4 verified batches; each ends at a human checkpoint; no pulse starts before the prior checkpoint is signed. | CP-1…CP-4 |
| **I11 WEIGHT PROPORTIONALITY** | Leaf-question density per domain tracks blueprint weight within ±40% relative (a 27% domain gets meaningfully more leaves than a 15% domain). Coverage is necessary; proportionality is the quality target. | Gate G-1a |
| **I12 EXAM INTEGRITY** | All questions are *derived from the public exam guide's objectives*. No artifact claims to reproduce secured exam items; no leaked item bank is sought, ingested, or cited. | Gate G-4; MERCURIO lens |

### Consumed meta-prompt (stage B) — mapping per `domain-mapping.md` §4

| Meta-prompt part | Becomes |
|---|---|
| Typed slots of the composed tree-prompt (`Objective`, `Domain`, `Depth`, `AnswerSlot`, `CompositionRule`) | Free variables of IC-2, the tree schema |
| operadic-interview persona (every node a full askable question, answers compose upward, composed-vs-collapsed check) | Invariants **I2, I3, I4** |
| meta-operad rules (typed/colored decomposition, OC check, inconsistency localization) | Gate **G-1b** rubric |
| meta-prompting output contract (example-agnostic, typed slots, zero pre-solved work) | The **SOLUTION-stage gate** for W2p and W2 |
| The composed meta-prompt itself | Embedded verbatim in the ContextPackets of **W2, W3a, W3b** (constitution slot) |

---

## 1. PIPELINE CONTRACT

```xml
<pipeline_contract>
  <stage name="TASK"           output="level-checked task statement"          gate="category + free variables named; stage-B meta-prompt consumed"/>
  <stage name="PLAN"           output="typed work-unit graph"                 gate="all units typed; acyclic; parallel pairs pass 5 criteria; closure check passed"/>
  <stage name="PROMPT"         output="executor prompts rendered from packets" gate="live probe passed on W1 (see gap-report §Verification Path); every packet has escalation rule + budget"/>
  <stage name="SOLUTION"       output="SolutionSketch per unit"               gate="orchestrator accepts sketch BEFORE build; decisions trace to invariants; rejected alternatives recorded"/>
  <stage name="IMPLEMENTATION" output="built artifacts"                       gate="machine checks green; opus review verdicts carry EVIDENCE; HumanChecks signed by Manu"/>
  <stage name="EVALUATION"     output="judged done-criteria + appended script" gate="PLAN-stage criteria evaluated; drift checks run; retro answered; script appended to audit_record"/>
</pipeline_contract>
```

---

## 2. DOMAIN MAP

### 2.1 Entities (each interrogated: lifecycle / failure mode / owner)

| # | Entity | Lifecycle (create → mutate → destroy) | Failure mode (what breaks, for whom) | Owner during execution |
|---|---|---|---|---|
| E1 | `ExamGuidePDF` | Created by Anthropic; **never mutated**; read-only forever | Misread → objectives lost → Manu studies a hole | The file itself (authoritative; effective July 2026) |
| E2 | `ExtractionShard` ×4 | Created by 4 sonnet agents (in flight at plan time); never mutated after write | Overlapping or gapped page ranges → silent objective loss | The extraction agents; verified by W1 |
| E3 | `ObjectiveRegistry` (`objectives.json`) | Created by W1; **frozen at G-0**; never mutated after | *The spine.* Wrong IDs → coverage matrix is meaningless → I1 is theater | W1, then frozen (IC-1) |
| E4 | `QuestionTree` (`question-tree.json`) | Created by W2 (fable); structure **frozen at CP-1**; answer slots append-only after | Shallow leaves / missing slots → the study instrument teaches nothing; late structural edits invalidate wiki anchors AND notebook plates | W2 → orchestrator after CP-1 |
| E5 | `CoverageMatrix` | Created by W3a; regenerated on any tree change | Stale → I1 asserted, not known | W3a |
| E6 | `OCReport` | Created by W3b | Missing → I3 unverified; the tree's chief claim is unbacked | W3b |
| E7 | `DocCorpusIndex` | Created by W4; append-only (fetch log) | Wrong/unofficial URLs → wiki teaches folklore | W4 |
| E8 | `WikiPage` ×N | Created by W5a–e in **disjoint per-domain directories**; folded (not rewritten) by later GROW passes | Uncited or drifted claim → Manu memorizes a stale API | Owning domain agent; then W6 |
| E9 | `SymmetryLedger` | Created by W6 | Bogus "symmetry" → false confidence in a non-invariant | W6 |
| E10 | `FieldNotebookVolume` (single-file HTML) | Assembled by W9m from W9a shell + W9b payload | Decorative plates → volume looks like a book, teaches like a poster | W9m; reviewed W10 |
| E11 | `ProjectState` + `MANIFEST.json` | Created by W11; updated every pulse | Wrong → future warm-start sessions restart cold, or worse, resume from a false state | W11 / orchestrator |
| E12 | `MetaMvpSpec` | Created by W12; **build deferred by user decision** | Over-specified → invites premature build; under-specified → useless later | W12 |
| E13 | `ApprovalRecord` (`approvals/CP-N.md`) | Created **only** by Manu's recorded decision; never by an agent | Forged/assumed → the whole consent structure is fiction | Manu (I9, IC-7) |
| E14 | `ReviewVerdict` ×5 | Created by opus gate agents; immutable | PASS without evidence = *gate theater*; orchestrator treats it as FAIL | Each gate agent |
| E15 | `NotebookLMCourse` (12h) | **Does not exist yet.** Arrives later | If the wiki isn't GROW-shaped, folding it in forces a rewrite | Absent; see U8 |

### 2.2 Relationships (each: what breaks if inverted or stale?)

| R | Relationship | Inverted? | Stale? |
|---|---|---|---|
| R1 | `ObjectiveRegistry` **constrains** `QuestionTree` | Inverting means writing questions first and back-claiming objectives — that is exactly the coverage-illusion failure. **Not symmetric ⇒ understood.** | Stale registry → tree covers a superseded blueprint. Drift check D1. |
| R2 | `QuestionTree` **constrains** `WikiPage` organization | Inverting (wiki shapes tree) reintroduces a cycle: the wiki would re-derive the exam structure from docs rather than from the guide. Forbidden. | — |
| R3 | `WikiPage` **fills** `QuestionTree` answer slots | This *is* the inverse direction of R2 and is the cycle risk. Resolved by **IC-4**: after CP-1 the wiki may write into slots by `node_id`, append-only; it may not add, remove, or reorder nodes. | Slot filled from a stale fetch → drift check D2 (14-day fetch age). |
| R4 | `QuestionTree` + `WikiPage` **feed** `FieldNotebookVolume` | Inverting means designing plates first and finding content to fill them — decoration. | — |
| R5 | `MANIFEST` **describes** every artifact | Inverting = artifacts described by memory, not by hash. | Stale manifest → warm-start resumes from fiction. Drift check D3. |
| R6 | `ApprovalRecord` **gates** every root work unit | Cannot invert: an agent may never mint approval. | — |

### 2.3 Second-order relations (relationships between relationships)

- **S1 — Weight × Coverage.** The `DOMAIN_SET.weight_pct` relation changes *how* R1 applies: coverage alone is satisfiable by one thin leaf per objective, which would give the 15% domain and the 27% domain equal depth. Two units each honoring coverage jointly violate study value. ⇒ Invariant **I11**, checked at the fan-in G-1a, not inside any single unit.
- **S2 — Fable cap × Review loop.** **I8** (≤2 rounds) constrains the *shape* of gate G-1: a normal review loop issues findings iteratively; here round 2 is the last round, so G-1a and G-1b findings must be **merged into one revision packet** by W3m before it is spent. ⇒ **IC-8**.
- **S3 — Context hygiene × Gate design.** **I6** forbids the orchestrator from eyeballing outputs, so every `done` must be either a runnable script or a delegation to a named reviewer agent. There is no third option, and "orchestrator skims it" is not a gate. ⇒ every `<done/>` below is typed accordingly.
- **S4 — Guide authority date × Live docs.** The guide is authoritative as of **July 2026**; the doc corpus is live and may describe post-guide behavior. A wiki claim can be simultaneously *true of the product* and *wrong for the exam*. ⇒ `SymmetryLedger` must partition invariants into **corpus-conserved** and **guide-baseline-conserved**, and W5 pages record `fetched_at` so the partition is recomputable later.
- **S5 — Tree freeze × Downstream anchors.** Freezing E4 at CP-1 is what makes LS-1 (five parallel wiki agents) and LS-2 (two parallel notebook agents) parallel-safe at all: they share a *frozen* reference, not mutable state. Unfreezing the tree after CP-1 is a **replan trigger**, not an edit.

### 2.4 Stakeholders

| Stakeholder | In the room? | Bears on half-failure | Consent status |
|---|---|---|---|
| **Manu** — candidate, human-of-record, pays the tokens | Yes | Studies a corpus with silent holes; pays for a half-built volume; $125 exam fee + 12-month validity window at stake | Consents per checkpoint; CP-0 gates the first spawn |
| **Future warm-start sessions** (Manu + agents, weeks later) | No | Resume from a wrong `PROJECT-STATE` and compound the error | Represented by W11's done-criteria |
| **Anthropic Certification Program** | No | Reputational/integrity harm if artifacts pose as real exam items | Represented by **I12**; MERCURIO lens owns it |
| **Other candidates**, if Manu shares the volume | No | Inherit any uncited or drifted claim | Represented by I5's fallibility stamp being *visible in the rendered volume*, not just in source |
| **The doc corpus authors** (docs.claude.com) | No | Misquotation attributed to them | Represented by IC-3 citation contract |

### 2.5 Capability inventory

**VERIFIED (I read the file/ran the command during this planning session):**
- `/root/.claude/skills/meta-planning/` — SKILL.md + `meta-meta-planning-prompt.md`, `domain-mapping.md`, `execution-handoff.md`, `audit-protocol.md`. Read in full.
- `EXAM_GUIDE` pages 1–6: 5 weighted domains, 6 scenarios, item model, and the *Detailed Objectives by Domain* structure (Task Statement → *Knowledge of:* bullets → *Skills in:* bullets). Domain 1 shows task statements 1.1, 1.2, 1.3 within pages 5–6.
- Skills present on disk at `/root/.claude/skills/`: `operadic-interview`, `meta-operad`, `meta-prompting`, `noether-wiki`, `meta-notebook`, `meta-mvp`, `meta-planning`, `category-master`, `noether-harness`.
- `field-notebook-craft` SKILL.md — **found at `/root/work/ccaf/skills-attached/field-notebook-craft/SKILL.md` (325 lines), NOT at the `/home/claude/...` path given in the brief.** Requires ≥~20 concepts for Atlas density; defines Corpus/Tokens/Tier/Atlas/Spread/Plate/Notebook/State objects and the `enact` functor (every plate demonstrates its concept) and the single-mutator `bind` pattern.
- Directory state at plan time: `/home/claude/work/ccaf/` contains only `extraction/` (empty). `/root/work/ccaf/` contains `extraction/` (empty), `notebook/`, `plan/`, `question-tree/`, `skills-attached/`, `wiki/`. `/home/claude` is **not** a symlink to `/root`. ⇒ **U1**.

**SOURCED (asserted by the invoking brief; not probed by me):** Agent tool with fable/opus/sonnet/haiku; Workflow tool for deterministic fan-out; WebSearch/WebFetch (present in this session's deferred-tool list); `device_stage_files`/`device_commit_files` for the CETI delivery target (grant pending); four sonnet extraction agents currently in flight.

### 2.6 Knowns ledger (Facts with provenance)

| Fact | Provenance |
|---|---|
| Exam: 60 items, MC + multiple-response, 4 scenarios drawn from a bank of 6, 120 min, scaled 720/1000 to pass, $125, 12-month validity, per-domain percent-correct on the score report | **verified** — guide p.2 |
| Blueprint: D1 Agentic Architecture & Orchestration 27%; D2 Tool Design & MCP Integration 18%; D3 Claude Code Configuration & Workflows 20%; D4 Prompt Engineering & Structured Output 20%; D5 Context Management & Reliability 15% | **verified** — guide p.3 |
| Six scenarios: Customer Support Resolution Agent; Code Generation with Claude Code; Multi-Agent Research System; Developer Productivity with Claude; Claude Code for CI; Structured Data Extraction — each tagged with primary domains | **verified** — guide pp.3–4 |
| Objectives are structured Domain → Task Statement → *Knowledge of* / *Skills in* bullets; items are written against these objectives | **verified** — guide p.5 |
| Guide is v1.0, effective July 2026, "subject to change without notice" | **verified** — guide p.1 |
| The tri-audit tiers, the five parallel-safety criteria, the ExecutorPrompt template, and the fresh-agent-probe rationale | **verified** — meta-planning references, read in full |

### 2.7 Unknowns ledger

Full ledger with spikes/falsifiers lives in `gap-report.md` §2 (U1–U9). Summary of the ones that change the graph:
- **U1** (workspace root divergence) → **Spike, 2 min, W0.** Changes where every artifact lands.
- **U2** (extraction shard schema + page partition) → **Spike, inside W1.** Changes whether a re-extraction unit must be added.
- **U3** (total objective count, est. 100–160) → **Assumption + falsifier.** Changes tree fan-out and the fable round budget.
- **U4** (fable "2 rounds" semantics) → **Assumption + falsifier.** Changes whether W2 shards into 2 fable agents.
- **U6** (device grant) → **Assumption + fallback.** Changes Pulse 4's delivery unit only.

### 2.8 Closure check (the domain map's gate)

Run against §3: every work-unit input and output below is expressible in E1–E15. ✔ Passed. Artifacts introduced during unit design that forced a return to the map: `ReviewVerdict` (E14, added — gates produce a typed artifact, not a mood) and `ApprovalRecord` (E13, added — approval must be an artifact to be an input). No unmapped artifact remains.

---

## 3. WORK BREAKDOWN

**Reading convention:** for each unit, `done` is stated **before** any implementation guidance, per the generator's step 6. Context packets render `input_artifacts` from `<inputs>` and `done_check` from `<done>`; `meta_plan_ref` = this document for all units.

**Global watchlist entries (domain-derived; every packet inherits these):**
`gate-theater` (a PASS with no evidence artifact) · `coverage-illusion` (a leaf that names an objective without testing it) · `citation-laundering` (a URL that does not contain the claim it backs) · `context-dumping` (returning bulk text to the orchestrator instead of a manifest) · `tree-padding` (a child node that restates its parent) · `plate-decoration` (an instrument that does not enact its concept) · `speculative-generality` (abstractions with one consumer).

---

### PULSE 1 — Extraction merge → operadic tree → opus gate

#### W0 — Workspace & shard reconnaissance
- **model:** haiku · **root unit** (input: `ApprovalRecord CP-0`)
- **intent:** Resolve U1/U2 mechanically before anything writes.
- **inputs:** `ApprovalRecord CP-0` (E13); the two candidate roots `/home/claude/work/ccaf/`, `/root/work/ccaf/`.
- **outputs:** `plan/PATHS.json` = `{canonical_root, extraction_shards:[{path,bytes,claimed_pages}], skills_attached_path, dirs_present[], divergence: bool}`.
- **done (MachineCheck):** `PATHS.json` parses; `canonical_root` is an existing writable dir; every shard file listed exists and is non-empty; `claimed_pages` union is reported (not required complete — that is W1's finding).
- **failure_semantics:** idempotent ✔ · retry: 2× · rollback: delete file · blast_radius: none (read-only recon).
- **context packet (budget ≈ 4k):** domain slice = §2.5 verified directory state + U1/U2. Exclusions: the exam guide, all skills — *this unit does no content work.* Escalation: if both roots contain non-empty, **differing** shard sets → HALT (touches every downstream location contract).
- **guidance:** `ls`/`stat` only. Do not read shard contents beyond the first 40 lines needed to identify claimed page ranges.

#### W1 — Objective registry merge  ← **the live fresh-agent probe** (see gap-report §Verification Path)
- **model:** sonnet
- **intent:** Fuse the 4 extraction shards into the single frozen spine, `objectives.json`.
- **inputs:** `PATHS.json`; `ExtractionShard` ×4 (E2); the blueprint table (5 domains + weights) supplied **inline in the packet** so the unit never opens the PDF.
- **outputs:** `plan/objectives.json` (**IC-1**); `plan/objectives.md` (human-readable); `plan/extraction-gaps.md`.
- **done (MachineCheck — script `plan/check_objectives.py`, written by this unit):**
  1. Every `objective_id` matches `D{1-5}.T{n}.{K|S}{m}` and is unique.
  2. All 5 domains present; `domain_weight_pct` values are exactly 27/18/20/20/15 and sum to 100.
  3. Every task statement has ≥1 `kind:knowledge` **and** ≥1 `kind:skill` objective.
  4. `source_page` present on every objective; the union of source pages covers 5–39 with **zero gaps**, or every gap is enumerated in `extraction-gaps.md` with the page range and why.
  5. Total objective count is reported (falsifies/confirms U3).
- **failure_semantics:** idempotent ✔ (re-derivable from shards) · retry: 1× · rollback: regenerate · **blast_radius: Manu** — a dropped objective silently propagates through the tree, the wiki, and the volume, and is only discovered at the exam.
- **context packet (budget ≈ 60k):** domain slice = E2, E3, R1, I1, IC-1, U2, U3. Exclusions: the PDF (shards are the interface), the tree meta-prompt, all downstream units — *you produce the spine, you do not use it.* Escalation: shards disagree on a task statement's text or a page is claimed by nobody → **do not interpolate**; record in `extraction-gaps.md`, continue, and set `status: done` with a flag. Shards missing entirely → HALT.
- **guidance:** dedup by normalized bullet text within a task statement; keep both variants and flag when two shards give materially different text. Preserve the guide's own wording — this registry is quoted downstream.

#### W1R — Registry review (independent opus)
- **model:** opus (must not be the W1 agent) · satisfies **I7**
- **intent:** Verify the spine against the source, not against the merge.
- **inputs:** `objectives.json`, `extraction-gaps.md`, `EXAM_GUIDE` (this unit **may** read the PDF — the orchestrator may not).
- **outputs:** `plan/verdicts/G-0.md` = `ReviewVerdict{verdict, evidence, findings[], missing_objectives[]}`.
- **done (HumanCheck-free MachineCheck + rubric):** verdict file exists AND contains, as evidence: the task-statement count per domain read directly from the guide vs. the count in the registry; a spot-verification of ≥2 randomly chosen task statements' full bullet lists, quoted; an explicit statement on whether pages 5–39 are fully represented. **A `PASS` with no such evidence is recorded by the orchestrator as `FAIL` (anti-pattern: gate-theater).**
- **failure_semantics:** idempotent ✔ · blast_radius: Manu.
- **packet (≈ 90k):** exclusions: the tree meta-prompt, all Pulse 2–4 material.
- **Gate G-0.** On PASS the orchestrator **freezes** `objectives.json` (IC-1). Any later edit = replan trigger.

#### W2p — Compose the tree meta-prompt
- **model:** opus · runs **in parallel with W0/W1** (root unit; input: `ApprovalRecord CP-0`)
- **intent:** Build the composed meta-prompt (meta-prompting × operadic-interview × meta-operad) that the single fable agent will receive. Because fable gets ≤2 rounds (**I8**), a weak prompt is unrecoverable — this unit exists precisely to protect that budget.
- **inputs:** `ApprovalRecord CP-0`; the three skills at `/root/.claude/skills/{meta-prompting,operadic-interview,meta-operad}/`; invariants I1–I4, I11; IC-2.
- **outputs:** `plan/tree-metaprompt.md`.
- **done (MachineCheck, checklist form — all must be literally present in the file):** root question verbatim ("In order to NAIL the exam at 100%, what questions must I be able to answer in ANY scenario?"); the depth-4 type/colour assignment (root → domain → topic → sub-topic → leaf); the **IC-2 JSON schema inlined**; the rule that every node is a full askable question with an answer slot (I2); the per-node `composition_rule` requirement (I4); the OC composed-vs-collapsed check definition and how a violation is *localized* (I3); the weight-proportionality target (I11); the objective-tagging requirement on sub-topic and leaf nodes (I1); the two-round protocol and the output-size discipline; **zero pre-solved content** (no example CCAF questions — it is a scaffold, not a worked example).
- **failure_semantics:** idempotent ✔ · retry: 1× · blast_radius: Manu + the fable round budget.
- **packet (≈ 70k):** domain slice = §0 meta-prompt-consumption table, I1–I4/I11, IC-2, `DOMAIN_SET` weights. Exclusions: `objectives.json` (not yet frozen; and the prompt must be objective-agnostic — it is a scaffold for the category).
- **Review of W2p (I7 satisfied structurally, not by a second opus):** the fable agent's **round-1 SolutionSketch is the legibility probe for this packet.** If round 1 fails to restate the schema, the OC-check form, and the composition rule, that is a finding against W2p; the orchestrator repairs the prompt and the round does not count against I8 (the sketch is gated *before* build, per the SOLUTION stage). Recorded as an explicit deviation in `gap-report.md`.

#### W2 — DEPTH-4 typed operadic question tree
- **model:** **fable**, ≤2 rounds (**I8**)
- **intent:** Emit the tree.
- **inputs:** `tree-metaprompt.md`; frozen `objectives.json`; `DOMAIN_SET` weights; `SCENARIO_SET` (6 scenarios, so leaves can be scenario-portable — "in ANY scenario").
- **outputs:** `question-tree/question-tree.json` (**IC-2**); `question-tree/question-tree.md`.
- **done (MachineCheck `question-tree/check_tree.py` + gates G-1a/G-1b):**
  1. JSON validates against IC-2; tree is exactly depth 4 below the root on every path.
  2. Every node has a non-empty `question` ending in `?` and an `answer_slot` object (I2).
  3. Every internal node has a non-empty `composition_rule` referencing **exactly** its own children's `node_id`s (I4).
  4. Level 1 = exactly the 5 domains, with weights carried.
  5. Every leaf carries ≥1 `objective_id` drawn from `objectives.json` (referential integrity: no unknown IDs).
  6. Coverage and OC are judged at G-1a/G-1b, not here.
- **failure_semantics:** **not idempotent** (a second run yields a different tree) · retry: the ≤2-round protocol *is* the retry policy · rollback: revert to round-1 tree, which is retained as `question-tree.r1.json` · blast_radius: Manu + every downstream unit (the tree is the anchor for the wiki and the volume).
- **packet (≈ 120k):** domain slice = the composed meta-prompt **verbatim** as constitution, plus objectives, weights, scenarios. Exclusions: the wiki plan, the notebook spec, the audit protocol — *shape the tree, do not plan its use.* Escalation: if the full tree cannot fit one response, emit **domains 1–3 in round 1 and 4–5 in round 2 with an explicit continuation marker** rather than truncating silently; if even that fails, HALT (fires the U4 replan: shard into two fable agents by domain).
- **Round 2 rule (IC-8):** round 2 is spent only on a **single consolidated revision packet** merged by W3m from G-1a + G-1b findings. It is never spent on a partial nudge.

#### W3a — Coverage & proportionality audit  ‖  W3b — Clarity & OC audit  *(lane-set LS-3)*
- **models:** opus ×2, independent, blinded to each other's findings until W3m.
- **W3a intent:** Prove or refute **I1** and **I11** mechanically.
  - **outputs:** `plan/coverage-matrix.json` (**IC-6**: `objective_id → [leaf_node_id]`, `uncovered[]`, per-domain leaf counts vs weight), `plan/verdicts/G-1a.md`.
  - **done:** matrix generated by a script the unit writes (so it is re-runnable after any tree edit); `uncovered` is empty **or** every entry is listed in the verdict with the reason; per-domain leaf counts reported against weights with the I11 ±40% judgment; **plus** a semantic sample: ≥10% of leaves (min 15), judged one by one against the question *"would answering this leaf actually demonstrate its tagged objective?"* — each judgment quoted. This sample is the defense against `coverage-illusion`; a structural-only pass is a FAIL.
- **W3b intent:** Prove or refute **I2, I3, I4**.
  - **outputs:** `plan/oc-report.md` (E6), `plan/verdicts/G-1b.md`.
  - **done:** every node's askability judged by script (I2) with the failures listed; ≥1 OC check per level-1 domain **and** ≥1 per level-2 topic in the two heaviest domains (D1 27%, D3/D4 20%) — each check states the composed answer, the collapsed answer, the verdict, and, on disagreement, the **single node** where it originates (I3, localization); clarity findings quote the offending node text.
- **parallel-safety evidence (LS-3):** (a) no shared mutable state — both read the frozen tree, write disjoint files; (b) no ordering invariant — coverage and OC are independent properties; (c) independently verifiable — separate verdict files with separate rubrics; (d) fan-in = **W3m**; (e) contended resource = **token budget only** (no rate-limited API, no human attention — Manu is not consulted until CP-1).
- **failure_semantics (both):** idempotent ✔ · blast_radius: Manu (a missed hole becomes a study hole).
- **packets (≈ 130k each):** exclusions — W3a does not receive the OC rubric; W3b does not receive the coverage matrix. *Blinding is the point.*

#### W3m — Gate fan-in (orchestrator, deterministic)
- **intent:** Merge G-1a + G-1b into **one** verdict and, if needed, **one** revision packet (IC-8, protects I8).
- **inputs:** `verdicts/G-1a.md`, `verdicts/G-1b.md` (verdicts and finding lists only — **not** the tree; I6).
- **outputs:** `plan/verdicts/G-1.md`; on FAIL, `plan/revision-packet-r2.md`.
- **done (MachineCheck):** G-1.md states PASS or FAIL; on FAIL exactly one revision packet exists and it is ≤2 pages, ordered by severity, and contains no new requirements beyond I1–I4/I11.
- **Gate G-1 → CHECKPOINT CP-1 (Manu).** On PASS the tree structure is **frozen** (IC-4 takes effect: answer slots become append-only).

---

### PULSE 2 — noether-wiki extraction → symmetry ledger → opus gate

#### W4 — Doc corpus map & fetch plan
- **model:** opus · **intent:** resolve U7; decide *what official pages are authoritative for each domain* before any bulk fetching burns budget.
- **inputs:** frozen `objectives.json`; level-1/level-2 nodes of the tree (topic names only — not the full tree; I6-style hygiene applied to the executor too); `DOC_CORPUS` roots.
- **outputs:** `wiki/doc-corpus-index.json` (E7): per domain, ≤12 candidate URLs, each with `{url, title, why_authoritative, objective_ids_served[], discovered_at}`; plus `wiki/FETCH-POLICY.md` (rate discipline, the ≤12-per-agent cap, and the S4 guide-baseline note).
- **done (MachineCheck):** every URL's host ∈ {docs.claude.com, anthropic.com} (**I5**: official only); every one of the 5 domains has ≥4 URLs; every level-2 topic maps to ≥1 URL, and unmapped topics are listed explicitly; total URLs ≤ 60.
- **failure_semantics:** idempotent ✔ · blast_radius: Manu + the five downstream lane agents (a bad index poisons all five in parallel — this is why W4 is opus and sequential).
- **packet (≈ 60k):** exclusions: full tree, notebook spec. Escalation: an exam topic with **no** official doc page → record it as an `orphan_topic` (a genuine finding about docs-vs-guide drift, S4), do not substitute a third-party source.

#### W5a … W5e — Per-domain wiki extraction *(lane-set **LS-1**, 5 sonnet agents)*
- **model:** sonnet ×5, one per exam domain.
- **intent:** Fetch this domain's official pages and write noether-wiki pages under conservation-law discipline.
- **inputs:** `doc-corpus-index.json` **filtered to this domain**; this domain's objectives; this domain's level-2 topic list; `IC-3`.
- **outputs:** `wiki/domain-{N}/*.md` (**IC-3** frontmatter: `page_id`, `domain_id`, `objective_ids[]`, `sources:[{url, fetched_at, official:true}]`, `fallibility_stamp`), plus `wiki/domain-{N}/INDEX.md` and `wiki/domain-{N}/claims.jsonl` (one line per claim: `{claim_id, text, url, fetched_at, objective_ids[], confidence}`).
- **done (MachineCheck `wiki/check_wiki.py`):** every page has complete IC-3 frontmatter; **every claim line carries a URL and a `fetched_at`** (I5); the fallibility stamp is present verbatim on every page *and* is rendered, not just filed; every objective assigned to this domain appears in ≥1 page's `objective_ids`, or is listed in that domain's `UNCOVERED.md`; ≤12 fetches performed (log included).
- **failure_semantics:** idempotent ✔ (re-fetch reproduces, modulo doc drift, which is the point of `fetched_at`) · retry: 2× per URL then record `unreachable` · rollback: delete the domain dir · blast_radius: Manu, and the doc authors (misquotation).
- **parallel-safety evidence (LS-1):** (a) **no shared mutable state** — each agent owns `wiki/domain-{N}/` exclusively, and no agent writes to `wiki/` root; (b) no ordering invariant — domains are independent by construction of the blueprint; (c) independently verifiable — `check_wiki.py` runs per-domain; (d) fan-in = **W6**, a real unit with a real contract, not a concatenation; (e) **contended finite resources, named: (i) WebFetch/WebSearch rate limits — capped at ≤12 fetches per agent, 60 total; (ii) the session token budget — ~60k per agent; (iii) *not* Manu's attention (no human check inside the lane).**
- **packets (≈ 60k each):** domain slice = this domain only. Exclusions: the other four domains' objectives and URLs, the full question tree, the notebook spec — *an agent that can see all five domains will drift into cross-domain synthesis, which is W6's job.* Escalation: a fetched page contradicts the exam guide's framing → **do not resolve it**; record both, flag `guide_vs_docs_conflict`, and let W6/W7 adjudicate (S4).
- **IC-4 note:** these agents **may** write `answer_slot` content keyed by `node_id` into `wiki/domain-{N}/slot-fills.jsonl`; they **may not** touch `question-tree.json`. The orchestrator applies slot fills after G-2, append-only.

#### W6 — Symmetry ledger & wiki fan-in
- **model:** opus
- **intent:** Find the **lines of symmetry** — invariants conserved across the doc corpus — and assemble the wiki root.
- **inputs:** the five `claims.jsonl` and five `INDEX.md` files (**not** the raw fetched pages — bulk stays out of this unit too).
- **outputs:** `wiki/symmetry-ledger.md` (E9); `wiki/INDEX.md`; `wiki/link-integrity.md`; `wiki/conflicts.md`.
- **done (rubric + MachineCheck):** every ledger entry states (i) the conserved quantity, (ii) **the transformation it is conserved under** (e.g., "holds whether the loop runs in Agent SDK or Claude Code"), (iii) ≥2 supporting claim_ids drawn from **≥2 different domains**, (iv) a named counterexample-watch (what observation would break it), and (v) its partition: `corpus-conserved` vs `guide-baseline-conserved` (**S4**). Entries failing any of (i)–(v) are deleted, not weakened. Link integrity: every `wiki/INDEX.md` link resolves to an existing file. Every `guide_vs_docs_conflict` flagged by LS-1 appears in `conflicts.md` with a recommendation.
- **failure_semantics:** idempotent ✔ · blast_radius: Manu (a false "invariant" is worse than no invariant — it is memorized).
- **packet (≈ 90k):** exclusions: raw fetched HTML, the notebook spec.

#### W7 — Wiki review gate (independent opus) → **Gate G-2**
- **model:** opus (not the W6 agent) · **I7**
- **intent:** Provenance audit + tree-anchor audit.
- **inputs:** `wiki/**` indexes and `claims.jsonl`; `symmetry-ledger.md`; the tree's level-2 topic list; `coverage-matrix.json`.
- **outputs:** `plan/verdicts/G-2.md`.
- **done (evidence-bearing verdict):** (1) a **sampled citation-laundering check** — ≥15 claims re-fetched or re-read at their cited URL and confirmed to actually contain the claim, each quoted; (2) every page carries the fallibility stamp; (3) **every level-2 topic in the tree has ≥1 wiki anchor**, exceptions enumerated; (4) `conflicts.md` reviewed with a stated posture on each; (5) no unofficial host appears anywhere. PASS without the ≥15 quoted samples = FAIL.
- **CHECKPOINT CP-2 (Manu).**

---

### PULSE 3 — Field notebook volume → opus gate

#### W8 — Notebook corpus spec
- **model:** opus
- **intent:** Map the tree + wiki into the field-notebook-craft `Corpus` type and decide the volume's architecture *before* any HTML exists.
- **inputs:** `question-tree.json` (structure + level-2 topics); `wiki/INDEX.md`, `symmetry-ledger.md`; `field-notebook-craft/SKILL.md` (at the path resolved by W0).
- **outputs:** `notebook/notebook-spec.md`.
- **done (checklist MachineCheck):** names the `Tier` mapping (tiers = the 5 exam domains, sized by weight); the `Atlas` embedding rule; a **plate list of ≥20** (one per level-2 topic — satisfying the skill's stated density floor) each with its `enact` claim in one sentence ("this plate's instrument makes the reader *do* X"); the `State` schema and the **single-mutator** `render()` contract; the 5-actor palette + type scale; where leaf questions surface (self-quiz instrument) and where wiki citations + the fallibility stamp surface **in the rendered page**; and the **IC-5 assembly contract** verbatim.
- **failure_semantics:** idempotent ✔ · blast_radius: Manu + both build agents (a vague spec makes LS-2 unsafe).
- **packet (≈ 100k):** exclusions: full wiki prose, full leaf text (counts and titles suffice at spec stage).

#### W9a — Shell  ‖  W9b — Plate payload *(lane-set **LS-2**, 2 sonnet agents)*
- **W9a outputs:** `notebook/shell.html` — tokens, frontispiece, Atlas, ToC, colophon, router, single-mutator harness, and the two literal markers `<!--PLATES_DATA-->` and `<!--PLATES_RENDER-->`.
- **W9b outputs:** `notebook/plates.data.js` (`const PLATES = [...]`, one entry per plate, carrying its questions, wiki citations, and stamp) and `notebook/plates.render.js` (exports `renderPlate(plate, state, mount)`).
- **done (each, MachineCheck):** file parses (node --check for JS; a DOM parse for HTML); **zero external network references** (`grep -E 'https?://' ` returns only citation *text*, never a `src`/`href` fetch); W9a contains both markers exactly once; W9b's `PLATES.length` ≥ 20 and every entry's `topic_id` exists in the tree.
- **parallel-safety evidence (LS-2):** (a) **no shared mutable state — by IC-5 the two agents own disjoint files and neither writes the other's**; (b) no ordering invariant — both depend only on the frozen spec; (c) independently verifiable — separate parse/scan checks; (d) fan-in = **W9m**, which performs the marker substitution per IC-5; (e) contended resource = token budget only.
- **failure_semantics:** idempotent ✔ · rollback: delete and rebuild the one file · blast_radius: Manu.
- **packets (≈ 80k each):** W9a gets tokens/Atlas/state spec and *no* plate content; W9b gets plate content and *no* shell concerns. Exclusions are the mechanism that makes the lane safe.

#### W9m — Assembly fan-in
- **model:** sonnet · **outputs:** `notebook/ccaf-field-notebook.html` (single file).
- **done (MachineCheck):** markers substituted, no marker remains; file is self-contained (no external `src`/`href`/`@import`); opens as valid HTML; file size recorded; every plate reachable from the Atlas and the ToC (static link scan).

#### W10 — Notebook review gate (independent opus) → **Gate G-3**
- **done (evidence-bearing verdict `plan/verdicts/G-3.md`):** the **enact test** applied plate by plate — for each of ≥8 sampled plates, state what the reader *does* and what concept that action demonstrates; plates that merely display text are named as `plate-decoration` findings. Plus: single-file/offline confirmed; every domain represented with weight-proportional plate counts; the fallibility stamp visible in the rendered volume; every interactive element functional (no placeholder handlers — static scan for empty listeners); coverage re-checked (`coverage-matrix.json` re-run against the tree).
- **CHECKPOINT CP-3 (Manu).**

---

### PULSE 4 — Persistence layer → delivery

#### W11 — Persistence layer  ‖  W12 — meta-mvp spec *(lane-set **LS-4**)*
- **W11 (sonnet) outputs:** `PROJECT-STATE.md`; `MANIFEST.json` (`{path, sha256, bytes, produced_by_unit, purpose, status}` per artifact); `question-tree/SCHEMA.md`; refreshed `wiki/INDEX.md`.
  - **done (MachineCheck):** every file under the canonical root appears in MANIFEST with a matching sha256; `PROJECT-STATE.md` contains, as named sections — *what exists*, *where it lives*, *what is frozen and why*, *open unknowns (U-ledger carried forward)*, *the exact next action for a cold session*, *how to re-run every check script*, and *the deferred items (meta-mvp build, NotebookLM enrichment)*. A cold-start reader must need **nothing else**.
- **W12 (opus) outputs:** `plan/meta-mvp-spec.md` — the tutor + exam-writer **spec only, build deferred by user decision.**
  - **done:** names the data contracts it would consume (IC-2 tree, IC-6 matrix, IC-3 wiki), the tutor loop, the exam-writer's item-generation rules **including I12** (derived from public objectives; never posed as real items), and an explicit `BUILD: DEFERRED` banner with the trigger condition for un-deferring.
- **parallel-safety (LS-4):** disjoint outputs; no ordering invariant; separate checks; fan-in W13; contended resource = tokens only. *(W12 must not be listed in MANIFEST before it exists — W13 regenerates the manifest hash after both land; this is the fan-in's job, not W11's.)*

#### W13 — Final review & delivery gate (opus) → **Gate G-4**
- **inputs:** `MANIFEST.json`, all five verdict files, `coverage-matrix.json`, `PROJECT-STATE.md`, `PATHS.json`.
- **outputs:** `plan/verdicts/G-4.md`; `DELIVERY-README.md`; `delivery/` staging list.
- **done (evidence-bearing):** end-to-end re-run of `check_objectives.py`, `check_tree.py`, `check_wiki.py`, and the coverage matrix, with exit codes quoted; MANIFEST hash-verified against disk; **I12 compliance statement** (no artifact poses as a real exam item; no leaked-item source appears anywhere in the corpus); every gate G-0…G-3 recorded PASS with evidence; U-ledger carried into PROJECT-STATE.
- **failure_semantics:** **the delivery commit is the only externally-visible action.** idempotent under the mtime guard · rollback: the container copy remains authoritative; nothing on the device is deleted · blast_radius: Manu's device files if a same-named file is overwritten ⇒ **`force=false`, `expectedMtimeMs` set on every commit; a mtime-drift rejection is escalated, never forced.**
- **CHECKPOINT CP-4 (Manu):** approves the device write. If the CETI/CERTIFICATIONS/CCAF grant is still pending (**U6**), the fallback fires: deliver via `SendUserFile` + retain the container bundle, and `PROJECT-STATE.md` records delivery as `PENDING_GRANT`. **The pipeline is complete either way** — delivery mode is not a success criterion.

---

## 4. DEPENDENCY GRAPH

```mermaid
graph TD
  CP0["CP-0 ApprovalRecord (Manu)<br/>input to EVERY root unit"]:::human
  CP0 --> W0["W0 path+shard recon (haiku)"]
  CP0 --> W2p["W2p compose tree meta-prompt (opus)"]

  W0 --> W1["W1 objective registry merge (sonnet)<br/>◆ LIVE PROBE"]
  W1 --> W1R["W1R registry review (opus)"]
  W1R --> G0{{"G-0 freeze objectives.json"}}

  G0 --> W2["W2 DEPTH-4 operadic tree (FABLE, ≤2 rounds)"]
  W2p --> W2

  W2 --> W3a["W3a coverage+proportionality (opus)"]
  W2 --> W3b["W3b clarity+OC (opus)"]
  W3a --> W3m["W3m gate fan-in (orchestrator)"]
  W3b --> W3m
  W3m -. "FAIL: ONE consolidated packet (IC-8)" .-> W2
  W3m --> G1{{"G-1"}} --> CP1["CP-1 Manu · tree frozen"]:::human

  CP1 --> W4["W4 doc corpus map (opus)"]
  W4 --> W5a["W5a D1 wiki"] & W5b["W5b D2 wiki"] & W5c["W5c D3 wiki"] & W5d["W5d D4 wiki"] & W5e["W5e D5 wiki"]
  W5a & W5b & W5c & W5d & W5e --> W6["W6 symmetry ledger + fan-in (opus)"]
  W6 --> W7["W7 wiki review (opus)"] --> G2{{"G-2"}} --> CP2["CP-2 Manu"]:::human

  CP2 --> W8["W8 notebook corpus spec (opus)"]
  W8 --> W9a["W9a shell (sonnet)"] & W9b["W9b plate payload (sonnet)"]
  W9a & W9b --> W9m["W9m assembly (sonnet)"]
  W9m --> W10["W10 notebook review (opus)"] --> G3{{"G-3"}} --> CP3["CP-3 Manu"]:::human

  CP3 --> W11["W11 persistence layer (sonnet)"] & W12["W12 meta-mvp SPEC only (opus)"]
  W11 & W12 --> W13["W13 final review + delivery (opus)"] --> G4{{"G-4"}} --> CP4["CP-4 Manu · device write"]:::human

  classDef human fill:#f6e3c5,stroke:#a8763e,stroke-width:2px;
```

### Sequences (each with the invariant forcing the order)

| Chain | Forcing invariant |
|---|---|
| W1 → W1R → G-0 → W2 | **I1/R1**: the tree may only be built against a *verified* registry; building first makes coverage back-claimed. |
| W2 → W3m → CP-1 → W4 | **S5**: parallel wiki agents require a *frozen* tree; freezing requires a human's sign-off on the spine. |
| W4 → LS-1 | **U7/I5**: fetching before the corpus is mapped burns the rate-limit budget on the wrong pages, ×5 in parallel. |
| LS-1 → W6 → W7 | **I7 + S4**: symmetry can only be found across completed domains; the review must audit the assembled corpus. |
| CP-2 → W8 → LS-2 | **IC-5**: the two build agents are only parallel-safe against a frozen assembly contract. |
| W9m → W10 → CP-3 | **I7**: nothing opus-or-lower ships unreviewed. |
| LS-4 → W13 → CP-4 | **I9**: the only external write is last and human-gated. |

### Parallel lane-sets (all five criteria, with evidence — see per-unit entries)

| Lane-set | Units | Fan-in | Named contended resource |
|---|---|---|---|
| **LS-1** | W5a–W5e (5) | W6 (real unit, real contract) | WebFetch/WebSearch rate limit (≤12/agent, ≤60 total); token budget |
| **LS-2** | W9a, W9b | W9m (marker substitution per IC-5) | token budget |
| **LS-3** | W3a, W3b | W3m (verdict merge; produces the *single* revision packet) | token budget |
| **LS-4** | W11, W12 | W13 (regenerates MANIFEST hashes after both land) | token budget |
| *(pre-lane)* | W0/W1 chain ‖ W2p | W2 | token budget |

**Critical path:** `CP-0 → W0 → W1 → W1R → W2 → W3a/W3b → CP-1 → W4 → LS-1 → W6 → W7 → CP-2 → W8 → LS-2 → W9m → W10 → CP-3 → LS-4 → W13 → CP-4`. The four human checkpoints are on it by design (**I10**) — the plan's latency is dominated by Manu's response time, which is the intended trade.

---

## 5. INTERFACE CONTRACTS

> **Change policy for all: an edit to any contract below is a REPLAN TRIGGER, not an edit.**

| ID | Parties | Shape / guarantees |
|---|---|---|
| **IC-1 OBJECTIVE_REGISTRY** | W1, W1R, W3a, W4, W8, W13 | `objectives.json`: `[{objective_id:"D{1-5}.T{n}.{K\|S}{m}", domain_id, domain_name, domain_weight_pct, task_statement_id, task_statement_text, kind:"knowledge"\|"skill", text, source_page}]`. Guarantees: IDs unique + stable; text quotes the guide; **frozen at G-0**. |
| **IC-2 QUESTION_TREE** | W2p, W2, W3a, W3b, W8, W11, W12 | node = `{node_id, depth:0..4, type:"root"\|"domain"\|"topic"\|"subtopic"\|"leaf", question:str(ends "?"), answer_slot:{status:"empty"\|"filled", answer, evidence_refs[], confidence}, composition_rule:str, children:[], objective_ids:[] (subtopic+leaf), oc:{sampled:bool, verdict}}`. Guarantees: depth exactly 4; I2/I4 hold at every node; `objective_ids` are referentially valid. **Structure frozen at CP-1.** |
| **IC-3 WIKI_PAGE** | W5a–e, W6, W7, W8 | frontmatter `{page_id, domain_id, objective_ids[], sources:[{url, fetched_at, official:true}], fallibility_stamp}`; body claims each with an inline citation; sibling `claims.jsonl`. Stamp text: *"FIRST PASS — FALLIBLE. Extracted from live official docs on {date}; docs may lag shipped behavior and may postdate the July 2026 exam baseline. Unverified against product behavior. Enrichment pending (NotebookLM course)."* |
| **IC-4 ANSWER_SLOT_FILL** | W5a–e, W6 → tree | Wiki writes `slot-fills.jsonl` keyed by `node_id`; the **orchestrator** applies them append-only after G-2. Wiki agents may **never** add, remove, or reorder nodes. |
| **IC-5 NOTEBOOK_ASSEMBLY** | W9a, W9b, W9m | `shell.html` carries `<!--PLATES_DATA-->` and `<!--PLATES_RENDER-->` exactly once each; W9b emits `plates.data.js` (`const PLATES=[…]`) and `plates.render.js` (`renderPlate(plate,state,mount)`); W9m substitutes. Result: one file, zero external refs. |
| **IC-6 COVERAGE_MATRIX** | W3a, W7, W10, W13 | `{matrix:{objective_id:[leaf_node_id]}, uncovered:[], per_domain:{domain_id:{leaf_count, weight_pct}}}` + the generating script (re-runnable after any tree change). |
| **IC-7 APPROVAL_RECORD** | Manu → **every root unit (W0, W2p)** | `approvals/CP-{n}.md`: `{checkpoint_id, recorded_by:"Manu", date, verdict, scope}`. `recorded_by` must be a named human — **never an agent**. No approval ⇒ no first spawn (fails closed). |
| **IC-8 REVISION_PACKET** | W3m → W2 | Exactly one packet, ≤2 pages, severity-ordered, no requirements beyond I1–I4/I11. Protects **I8**. |

---

## 6. EXECUTOR PROMPT TEMPLATE (embedded — this meta-plan alone suffices to spawn agents)

```xml
<executor_prompt unit="[WorkUnit.id]">
<role>
You are the executor for ONE work unit of the CCAF exam-mastery pipeline. Your job is exactly
[WorkUnit.intent]. Position in the graph: you consume [upstream unit ids]; you are consumed by
[downstream unit ids]; your lane and fan-in, if parallel: [lane-set id / fan-in unit id].
You build only what your packet specifies. Your output is UNVERIFIED until your done-check
passes — plans assert; gates know.
</role>

<constitution>
CATEGORY: BLUEPRINT → TREE → WIKI → VOLUME → PERSIST. Turn a weighted, blueprinted certification
exam guide into a depth-4 typed operadic question tree with total objective coverage, a
provenance-stamped wiki of the vendor's live official docs, an interactive editorial study volume,
and a warm-start persistence layer.

INSTANCE: Claude Certified Architect – Foundations (CCAR-F). 60 items, MC + multiple-response,
4 of 6 scenarios per sitting, 120 min, pass at scaled 720/1000. Blueprint: D1 Agentic Architecture
& Orchestration 27% · D2 Tool Design & MCP Integration 18% · D3 Claude Code Configuration &
Workflows 20% · D4 Prompt Engineering & Structured Output 20% · D5 Context Management &
Reliability 15%. Objectives are Domain → Task Statement → "Knowledge of" / "Skills in" bullets.
Guide v1.0, effective July 2026.

INVARIANTS YOU MUST PRESERVE (violating one is an escalation, not a judgment call):
 I1  every objective maps to >=1 depth-4 leaf question
 I2  every node at every depth is a FULL ASKABLE QUESTION with its own answer slot
 I3  operadic consistency: composed answer == collapsed answer, violations LOCALIZED to a node
 I4  every internal node states its upward composition rule over exactly its own children
 I5  every wiki claim cites an official URL with fetch date and carries the fallibility stamp
 I6  the orchestrator never reads bulk output — return manifests, counts, and verdicts, not dumps
 I7  anything opus-or-lower produced is reviewed by a different opus agent
 I8  fable agents get <=2 response rounds; revisions arrive as ONE consolidated packet
 I9  all outputs are files; the only external write is the human-gated Pulse-4 device commit
 I11 leaf density per domain tracks blueprint weight (coverage necessary, proportionality targeted)
 I12 all questions derive from the PUBLIC exam guide's objectives; no artifact poses as a real
     exam item; no leaked item bank is sought, ingested, or cited

STAKEHOLDERS: Manu (candidate, human-of-record, pays the tokens) · future warm-start sessions ·
the Anthropic Certification Program (not in the room — I12 is theirs) · other candidates if the
volume is shared · the doc authors you cite.

KAIZEN: one pulse = one cycle. Report what your gate caught, where reality diverged from this
plan, and the smallest plan change that would prevent recurrence. These become edit-script entries.

[If your unit's category was defined by a meta-prompt (W2, W3a, W3b): the composed tree
 meta-prompt is included VERBATIM below and is the contract your output is judged against.]
</constitution>

<packet>
<domain_slice>[this unit's slice of §2 — entities, relationships, and invariants it touches]</domain_slice>
<inputs>[Artifacts with absolute paths and schemas]</inputs>
<interface_contracts>[the IC-n entries this unit must honor — FROZEN; see escalation]</interface_contracts>
<done_check>[the runnable MachineCheck command and/or the named reviewer + rubric]</done_check>
<watchlist>[global entries: gate-theater · coverage-illusion · citation-laundering ·
            context-dumping · tree-padding · plate-decoration · speculative-generality
            + this unit's specific entries]</watchlist>
<budget>[ceiling ~Nk. Inclusion rule: include what changes THIS agent's decisions.
         Exclusion note: what was deliberately withheld from you, and why.]</budget>
</packet>

<escalation_rule>
Ambiguity touching an INTERFACE CONTRACT, a DOMAIN INVARIANT, or anything IRREVERSIBLE:
HALT and emit blocked-status with your specific question. Reversibility unknown or contested
counts as irreversible. Otherwise: take the smallest reversible assumption and record it in
<flags>. When local instructions run out entirely, the licensed move is STOP-AND-ESCALATE, not
reconstruct-intent-and-proceed; reconstruction from the constitution is permitted only for
reversible, in-packet-scope decisions. Never fabricate an exam objective, a citation, or an
approval.
</escalation_rule>

<output_contract>
<solution_sketch>FIRST deliverable, BEFORE building: approach; key decisions each traced to a
   named invariant/contract/entity; alternatives rejected with reasons. Also restate, from this
   prompt alone: your job, your inputs, your done-check, and your neighbors. The orchestrator
   gates this before you proceed.</solution_sketch>
<outputs>each declared Artifact, with done-check EVIDENCE attached (exit codes, counts, quotes).
   A "done" without evidence is recorded as failed.</outputs>
<flags>assumptions taken; watchlist conflicts encountered (flag them — do not silently obey or
   ignore); candidate edit-script entries.</flags>
<unknowns_encountered>anything belonging in the unknowns ledger.</unknowns_encountered>
<status>done | blocked{question} | failed{what the gate caught}</status>
</output_contract>
</executor_prompt>
```

---

## 7. ROLES

| Role | Held by |
|---|---|
| **Meta-planner** | This opus planning agent. Produced this L2 document + `gap-report.md`. Does not execute. |
| **Planner** | The fable orchestrator, instantiating the L1 pulse plan in §8 (already instantiated here; re-planning on a replan trigger is its job). |
| **Orchestrator** | The fable-tier session orchestrator. Spawns executors by rendering §6; gates each `solution_sketch` before build; runs machine checks; merges fan-ins (W3m, W6, W9m, W13); applies IC-4 slot fills; appends flags and retros to `<audit_record>`; fires replan triggers; escalates stop-the-line triggers to Manu. **Bound by I6 — reads manifests, verdicts, counts, and exit codes only.** |
| **Executors** | W0 (haiku) · W1, W5a–e, W9a, W9b, W9m, W11 (sonnet) · W1R, W2p, W3a, W3b, W4, W6, W7, W8, W10, W12, W13 (opus) · W2 (fable, ≤2 rounds). |
| **Auditors** | Generation-time: this agent, Tier 2 (three sequential lenses, §11). Execution-time: the independent opus gate agents W1R, W3a/W3b, W7, W10, W13 — one per lane-set boundary. |
| **Human-of-record** | **Manu** — named, reachable, present in session. Owns CP-0…CP-4 and every stop-the-line response. A halt is indefinite until Manu responds; an unanswered escalation is never license to resume. |

---

## 8. INSTANTIATED L1 PLAN — the four pulses

| Pulse | Units | Agents | Ends at | The one question the checkpoint asks |
|---|---|---|---|---|
| **P1 — Spine & Tree** | W0, W1, W1R, W2p, W2, W3a, W3b, W3m | 1 haiku, 1 sonnet, 4 opus, 1 fable = **7** | **CP-1** | *Is this the tree you want to be examined by?* (Structure freezes here; later structural change is a replan, not an edit.) |
| **P2 — Wiki & Symmetry** | W4, W5a–e, W6, W7 | 5 sonnet, 3 opus = **8** | **CP-2** | *Do you accept the docs-drift posture — first-pass-fallible, official-URL-only, NotebookLM enrichment later?* |
| **P3 — Volume** | W8, W9a, W9b, W9m, W10 | 3 sonnet, 2 opus = **5** | **CP-3** | *Does the volume teach when you touch it, or only when you read it?* |
| **P4 — Persistence & Delivery** | W11, W12, W13 | 1 sonnet, 2 opus = **3** | **CP-4** | *Approve the device write to CETI/CERTIFICATIONS/CCAF (the only external action) — and is the grant live?* |

**Total: 23 agent-spawns across 17 work units** (fable round 2 reuses the same agent). Ceiling 25 with the U2 re-extraction contingency.

**Pulse entry rule (I10):** a pulse does not start until the prior checkpoint's `ApprovalRecord` exists on disk. Pulse 1 does not start until `approvals/CP-0.md` exists.

---

## 9. KAIZEN LOOP (cycle = one pulse)

**Edit-script format** (appended to §11 `audit_record`, the single history):
```
EDIT SCRIPT — [lens | pulse] pass [n] — [date]
VERDICT: pass | fail (n findings)
1. [slot/unit affected] — [finding] → [concrete change]
DEFERRED: [findings acknowledged but deliberately not acted on, with reason]
```

**Retro questions (every pulse, answered by the orchestrator from executor flags — not from reading outputs):**
1. What did the gates actually catch that the plan did not anticipate?
2. Where did reality diverge from the domain map (§2)?
3. What is the *smallest* change to this meta-plan that would have prevented it?

**Drift checks (run at every pulse boundary):**
- **D1** — `coverage-matrix.json` regenerated and still 100% after *any* tree or registry touch.
- **D2** — no `fetched_at` older than 14 days at the time the wiki is reviewed; older ⇒ re-fetch flag in `conflicts.md`.
- **D3** — every `MANIFEST.json` sha256 matches disk; `PROJECT-STATE.md` claims nothing the manifest cannot show.
- **D4** — the unknowns ledger has **not grown** across pulses (growth is a stop-the-line trigger).

**Replan triggers (→ planner):** a spike kills an assumption (U1–U9); any gate fails twice; the critical path shifts; an interface contract (IC-1…IC-8) needs changing; the fable agent cannot emit the tree within its round budget (U4 ⇒ shard by domain); `extraction-gaps.md` shows uncovered guide pages (⇒ insert a re-extraction unit).

**Stop-the-line triggers (→ HALT all lanes, escalate to Manu):** two replans with no forward progress; the blast radius of any unit is reclassified upward; the unknowns ledger grows across two consecutive pulses (D4); an irreversible or externally-visible action reaches an uncertain gate (specifically: the CP-4 device commit with an mtime-drift rejection); any agent proposes ingesting non-official or leaked exam material (**I12**); any agent proposes minting an approval record.

**Fireable, not only revisable:** with `approvals/CP-0.md` present and `PATHS.json` resolved, Pulse 1 can be spawned as written, from this document alone.

---

## 10. LIMITS AND ASSUMPTIONS OF THIS META-PLAN

| Assumption | Falsifier |
|---|---|
| The extraction shards will collectively cover guide pages 5–39 with a recoverable structure. | W1's `extraction-gaps.md` shows unclaimed pages ⇒ insert a re-extraction unit (replan, already triggered). |
| A single fable agent can emit a ~250–400-node depth-4 tree within 2 rounds. | Round 1 truncates or omits domains ⇒ shard into two fable agents by domain (U4 replan). |
| Structural OC is script-checkable; semantic OC needs opus judgment. | `check_tree.py` passes a tree that W3b judges incoherent ⇒ the script's rule set is under-specified; strengthen before trusting it as a gate. |
| Five parallel wiki agents will not exhaust the WebFetch rate limit at ≤12 fetches each. | Any agent reports throttling ⇒ serialize LS-1 into two waves (this costs latency, not correctness). |
| Freezing the tree at CP-1 is what makes LS-1/LS-2 safe. | If CP-1 approval is given tentatively and the tree changes in Pulse 2 or 3, the lane-safety argument collapses — hence CP-1 is the checkpoint where Manu's attention matters most. |
| The generation-time audit was Tier 2 (sequential lenses, one agent), deviating from the protocol's Tier-3 letter. | See `gap-report.md` §3. Manu may overrule and demand a Tier-3 re-audit before Pulse 1. |
| **The binding spawned fresh-agent probe was NOT run at plan time** (skipped by instruction). Its substitute is W1 executed as a live probe. | W1's SolutionSketch fails to restate its job/inputs/done-check/neighbors from the packet alone ⇒ that is a finding against the *planner* (this document), and every remaining packet is repaired before Pulse 1 continues. |

**When a direct plan would have been the better instrument:** if the goal were only "extract the objectives and make flashcards," this machinery is disproportionate. It earns its cost because of the OC-checked tree, the parallel wiki lane, the four human checkpoints, and the persistence requirement — four things a to-do list cannot carry.

---

## 11. AUDIT RECORD

```
EDIT SCRIPT — OPUS (technical depth) pass 1 — 2026-08-01
VERDICT: fail (5 findings)
1. LS-2 (W9a/W9b) — two agents were both writing the single output HTML: shared mutable state,
   criterion (a) violated → introduced IC-5 (disjoint files + marker substitution) and a real
   fan-in unit W9m. Lane is now safe by contract, not by hope.
2. LS-1 criterion (e) — "contended resource" was unnamed → named explicitly: WebFetch/WebSearch
   rate limit (≤12/agent, ≤60 total) and per-agent token ceiling; noted Manu's attention is NOT
   contended inside the lane.
3. W2p — an opus-produced artifact with no opus reviewer (I7 hole) → resolved structurally: the
   fable round-1 SolutionSketch is the legibility probe, gated before build so it costs no I8
   round. Deviation disclosed in §10 and the gap report.
4. Gates G-0…G-4 — "opus reviews it" is not a done-check the orchestrator can verify under I6
   → every verdict now requires named EVIDENCE (quoted samples, counts, exit codes), and a PASS
   without evidence is recorded as FAIL.
5. W11/W12 — W11 was to generate MANIFEST while W12 was still writing a file that belongs in it
   → hash regeneration moved to the W13 fan-in.

EDIT SCRIPT — FABLE (coherence, simplicity, story) pass 1 — 2026-08-01
VERDICT: fail (3 findings)
1. Two-minute retelling failed at Pulse 2 — the wiki lane read as "five agents do wiki things"
   → each W5 unit now has a one-sentence motivation and an explicit exclusion note explaining
   why it cannot see the other four domains (that exclusion IS the lane's safety argument).
2. Speculative generality — an earlier draft had a separate "scenario-mapping" unit producing an
   artifact nobody consumed → removed; the 6 scenarios enter as an input to W2 instead (the tree's
   root question already demands scenario-portability). One fewer agent.
3. Packet legibility (read cold as the fresh agent) — W3a and W3b could not tell they were blinded
   from each other → the blinding and its purpose are now stated in both packets' exclusion notes.

EDIT SCRIPT — MERCURIO (truth, ethics, impact) pass 1 — 2026-08-01
VERDICT: fail (4 findings)
1. Unsourced claim — the field-notebook-craft path from the brief did not exist on disk. Verified
   the real path (/root/work/ccaf/skills-attached/...) and moved the whole path question to the
   unknowns ledger as U1 with a 2-minute spike (W0). Nothing downstream now assumes a path.
2. Stakeholder not in the room — the Anthropic Certification Program was absent from the map.
   Added, with invariant I12 (public-objective derivation only; no artifact poses as a real exam
   item; no leaked item bank) enforced at W12's spec and W13's final gate.
3. Blast radius stated in prose ("bad") rather than as named parties → every unit's blast_radius
   now names Manu and/or the specific downstream units and the doc authors.
4. Irreversibility boundary — the device commit was implicit → made explicit as the ONLY external
   action, force=false, mtime-guarded, human-gated at CP-4, with a stated fallback that does not
   count as failure. Also added: agents may never mint an ApprovalRecord (IC-7, stop-the-line).

EDIT SCRIPT — OPUS re-pass on changed slots — 2026-08-01
VERDICT: pass (0 findings). IC-5, IC-8, the evidence requirement, and the W13 hash regeneration
re-read clean; graph re-verified acyclic; four lane-sets each carry all five criteria with named
resources and named fan-ins; critical path unchanged.

FIXPOINT: reached after 4 passes (budget 6). No thrash. DEFERRED, with reasons:
 - The binding spawned fresh-agent probe (skipped by instruction; substitute = W1 live probe, §10).
 - Tier-3 blinded-subagent generation-time audit (proportionality deviation, gap-report §3;
   Manu may overrule).
 - Sibling-task probe run mentally only (AWS SAA / CKA / GCP PCA), not written out.
 - The meta-mvp tutor + exam-writer BUILD (deferred by the user's own decision; W12 specs it).
```
