# CCAF Exam-Prep Project (Claude Certified Architect – Foundations)

**Owner / human-of-record:** Manu (manutej@gmail.com) — present in session; approves all checkpoints.
**Delivery target (device):** `CETI/CERTIFICATIONS/CCAF/` on manutejs-macbook-pro-local (grant active; VM mount path `mnt/CETI/...` via device_bash).
**Cloud work root:** `/home/claude/work/ccaf/`

## What this project is
Prepare Manu to score 100% on the CCAF exam (60 items, 120 min, 720/1000 pass, 5 domains: D1 Agentic Architecture & Orchestration 27%, D2 Tool Design & MCP Integration 18%, D3 Claude Code Configuration & Workflows 20%, D4 Prompt Engineering & Structured Output 20%, D5 Context Management & Reliability 15%; guide v1.0, effective July 2026). Two fronts:
1. **Operadic question tree** (depth 4: Domain → Topic → Sub-topic → Leaf) from the official exam guide, via a composed /meta-prompting × /operadic-interview × /meta-operad meta-prompt. Root question: "In order to NAIL the exam at 100%, what questions must I be able to answer in ANY scenario?" Later feeds sample-question generation, scenario building, tutor + exam-writer.
2. **Noether-wiki** of the LATEST official Anthropic docs mapped to exam domains, with lines of SYMMETRY (conserved invariants), fallibility-stamped (docs may lag builds); then a finalized **field-notebook** volume (field-notebook-craft + meta-notebook). A NotebookLM 12-hour course arrives later via MCP for enrichment.

## Operating rules (Manu's constitution — do not violate)
- Hub-spoke: the orchestrator (fable) does NOT read PDFs or bulk agent outputs directly; many small well-directed agents over few overloaded ones.
- Model tiers: sonnet = reading/extraction; opus = review of clarity/quality of anything produced; fable agents = the operadic meta-prompt work, MAX 2 response rounds each.
- Pulse rounds: small verified batches; user check-in at each checkpoint (CP-1 tree, CP-2 wiki, CP-3 notebook, CP-4 delivery).
- Every reviewer verdict must carry quoted evidence; PASS without evidence = FAIL.
- Wiki claims cite official URLs + fetch timestamps + fallibility stamp.
- Keep HANDOFF.md, planning/STATUS.md, planning/DECISIONS.md current at every checkpoint — this file system must warm-start a fresh session.

## Layout
```
CLAUDE.md            ← this file (load first)
HANDOFF.md           ← current state + next action (load second)
planning/            ← META-PLAN.md (L2 plan, canonical), gap-report.md, DECISIONS.md, STATUS.md
extraction/          ← 4 PDF shards, registry.json + registry.md (CANONICAL exam-guide source), W1-solution-sketch.md
question-tree/       ← tree.json, domain-{1..5}.md, coverage-matrix.md, README.md (Pulse 1 output)
wiki/                ← noether-wiki nodes + symmetry ledger (Pulse 2 output)
notebook/            ← field-notebook HTML volume (Pulse 3 output)
persistence/         ← PROJECT-STATE.md, tutor/exam-writer meta-mvp spec (Pulse 4 output)
skills-attached/     ← field-notebook-craft/SKILL.md (user-supplied)
```

## Source of truth chain
Official PDF (uploads) → extraction/part-*.md → **extraction/registry.json** (canonical; schema decided in DECISIONS.md D-3) → question-tree/tree.json → wiki → notebook. Downstream never re-reads upstream's upstream.

## Key inputs
- Exam guide PDF: `/root/.claude/uploads/540ac69e-5ba7-568a-9b29-72ba41d2452d/3f852585-ccafexamguideofficial.pdf` (39 pp)
- Skills: meta-planning, meta-prompting, operadic-interview, meta-operad, noether-wiki, meta-notebook (in /root/.claude/skills/), field-notebook-craft (attached, in skills-attached/)
