# CCAF Exam Guide — Extraction Part 4 (pages 31–39)

## 1. Page ledger
- Page 31: Tail end of "Scenario" sample-question block — end of Question 8 rationale ("Correct Answer: A...") and full Question 9 (synthesis agent / verify_fact tool scenario) with answer options A–D and rationale. Start of new scenario header "Scenario: Claude Code for Continuous Integration" and Question 10 (claude -p flag) options A only visible (continues to next page). [OVERLAP PAGE — shared with neighboring agent]
- Page 32: Completion of Question 10 (options B–D, correct answer A, rationale on -p/--print flag); Question 11 (Message Batches API cost-savings scenario) full Q+options+correct answer+rationale; Question 12 (14-file PR review scenario) question text and options A–B (continues to next page).
- Page 33: Completion of Question 12 (options C–D, correct answer A, rationale); Section "10. How the Exam Is Scored" — criterion-referenced assessment, passing standard (scaled 100–1,000, cut score 720), result reporting; Section "11. Registration and Scheduling" begins (steps 1–2 of registration through Anthropic Partner Academy and Pearson VUE).
- Page 34: Continuation of Section 11 registration/scheduling steps 3–6 (checkout, Pearson VUE account, choosing date/proctoring/test center, cancel/reschedule 24-hour policy); Section "12. Exam Policies" begins — Identification, Accommodations, Retake policy, No-show and late arrival.
- Page 35: Section "13. Exam-Day Experience and Rules of Conduct" (proctoring rules, prohibited items, consequences of misconduct); Section "14. Confidentiality and Non-Disclosure Agreement"; Section "15. Credential Maintenance and Recertification" begins (12-month validity, renewal process).
- Page 36: Continuation/end of Section 15 (recertification if content changes significantly, rules of conduct reference); Section "16. Candidate Support, Appeals, and Privacy" (Support, Appeals and complaints, Privacy); Section "17. Appendix" begins with "Technologies and Concepts" list (Claude Agent SDK, Model Context Protocol bullet items begin).
- Page 37: Continuation of "Technologies and Concepts" list (Claude Code, Claude Code CLI, Claude API, Message Batches API, JSON Schema, Pydantic, Built-in tools, Few-shot prompting, Prompt chaining, Context window management, Session management, Confidence scoring); "In-Scope Topics" subsection begins (Agentic loop implementation, Multi-agent orchestration, Subagent context management, Tool interface design).
- Page 38: Continuation of "In-Scope Topics" (MCP tool and resource design, MCP server configuration, Error handling and propagation, Escalation decision-making, CLAUDE.md configuration, Custom commands and skills, Plan mode vs direct execution, Iterative refinement, Structured output via tool_use, Few-shot prompting, Batch processing, Context window optimization, Human review workflows, Information provenance); "Out-of-Scope Topics" subsection begins (Fine-tuning, API auth/billing, language/framework implementation details, deploying/hosting MCP servers).
- Page 39: Continuation/end of "Out-of-Scope Topics" list (internal architecture/training/model weights, Constitutional AI/RLHF/safety training, embedding models/vector DB, computer use, vision/image analysis, streaming API/SSE, rate limiting/quotas/pricing, OAuth/API key rotation/auth protocol details, cloud provider configs, performance benchmarking, prompt caching implementation details, token counting/tokenization); Section "18. Document Control" — version table (1.0 July 2026, 0.2 June 2026, 0.1 February 2026). This is the final page of the document (page 39 of 39).

## 2. Exam metadata (verbatim where possible)
- Document header throughout range: "Claude Certification Program" / running header "Exam guide"
- Exam name (from Section 10): "The Claude Certified Architect – Foundations exam is a criterion-referenced assessment"
- Passing standard: "The score is reported on a scaled range of 100–1,000, and the cut score is 720."
- Scoring model: "Scaled scoring models help equate scores across multiple exam forms that might have slightly different difficulty levels."
- Result reporting: "Your result is reported as a pass or fail status with a scaled score from 100 to 1,000. Your score report also shows the percentage of items you answered correctly within each content domain. Section-level percentages are provided to help you understand your performance and are not used to determine your pass or fail result, which is based on your total scaled score."
- Registration/scheduling channel: "Registration and scheduling are handled through the Anthropic Partner Academy and Pearson VUE"
- Delivery: "The exam is delivered by Pearson VUE." Options: "online proctoring or a Pearson test center."
- Cancellation policy: "You may cancel or reschedule up to 24 hours before your appointment. Changes made within 24 hours forfeit the exam fee."
- ID requirement: "you must present a valid, unexpired, government-issued photo identification. The name on your ID must match the name on your registration exactly."
- Accommodations contact: pearsonvue.com/us/en/test-takers/accommodations
- Retake policy (verbatim): "Candidates who do not pass may retake the exam after a required waiting period. Waiting periods increase with each failed attempt: 14 days after the first, 30 days after the second, and 90 days after the third. You may take an exam up to four times within a rolling twelve-month period. Limits apply per exam, so not passing one exam does not prevent you from registering for a different one. The exam fee applies to each attempt."
- No-show policy: "Candidates who fail to appear for a scheduled exam, or who arrive after the permitted late-arrival window, forfeit the exam fee and must re-register."
- Credential validity: "The Claude Certified Architect – Foundations credential is valid for 12 months from the date it is awarded."
- Renewal: "To renew on time, you review what has changed since you certified and complete a free, non-proctored assessment on the Anthropic Partner Academy. There is no fee for on-time renewal. If your credential lapses, you must retake the full exam at the full fee to regain certified status." "If exam content changes significantly, Anthropic may require holders to retake the full exam to recertify rather than complete the renewal assessment."
- Support email: certifications-support@anthropic.com
- Pearson VUE support: pearsonvue.com/us/en/anthropic.html
- Appeals window: "You may appeal a decision within 14 days of the date you are notified of it, or, for a concern about your exam result, within 14 days of your exam date." "The standard-setting outcome and the content of individual exam items are not subject to appeal."
- Document Control table (verbatim):
  | Version | Summary of change | Date |
  |---|---|---|
  | 1.0 | Formatting and layout updates | July 2026 |
  | 0.2 | Draft revision | June 2026 |
  | 0.1 | Initial draft | February 2026 |

## 3. Domains & weightings (VERBATIM)
NONE IN RANGE. (No domain/weighting table appears in pages 31–39; this range covers the tail of the sample-question scenarios, scoring, registration/policy sections, and the Appendix. Domain names are implied by scenario headers on page 31 — "Scenario: Claude Code for Continuous Integration" — but no explicit weighting percentages appear.)

## 4. Objectives / skills measured (VERBATIM numbering and wording)
No numbered "objectives/skills measured" list appears directly in this range (that content precedes page 31). However, the Appendix (Section 17) enumerates "In-Scope Topics" which function as tested objectives. Verbatim, as bulleted (no numbering in source):

### In-Scope Topics ("The following topics are explicitly tested on the exam:")
- Agentic loop implementation: control flow based on stop_reason, tool result handling, loop termination conditions
- Multi-agent orchestration: coordinator-subagent patterns, task decomposition, parallel subagent execution, iterative refinement loops
- Subagent context management: explicit context passing, structured state persistence, crash recovery using manifests
- Tool interface design: writing effective tool descriptions, splitting vs consolidating tools, tool naming to reduce ambiguity
- MCP tool and resource design: resources for content catalogs, tools for actions, description quality for adoption
- MCP server configuration: project vs user scope, environment variable expansion, multi-server simultaneous access
- Error handling and propagation: structured error responses, transient vs business vs permission errors, local recovery before escalation
- Escalation decision-making: explicit criteria, honoring customer preferences, policy gap identification
- CLAUDE.md configuration: hierarchy (user/project/directory), @import patterns, .claude/rules/ with glob patterns
- Custom commands and skills: project vs user scope, context: fork, allowed-tools, argument-hint frontmatter
- Plan mode vs direct execution: complexity assessment, architectural decisions, single-file changes
- Iterative refinement: input/output examples, test-driven iteration, interview pattern, sequential vs parallel issue resolution
- Structured output via tool_use: schema design, tool_choice configuration, nullable fields to prevent hallucination
- Few-shot prompting: ambiguous scenario targeting, format consistency, false positive reduction
- Batch processing: Message Batches API appropriateness, latency tolerance assessment, failure handling by custom_id
- Context window optimization: trimming verbose tool outputs, structured fact extraction, position-aware input ordering
- Human review workflows: confidence calibration, stratified sampling, accuracy segmentation by document type and field
- Information provenance: claim-source mappings, temporal data handling, conflict annotation, coverage gap reporting

### Out-of-Scope Topics ("The following related topics will not appear on the exam:")
- Fine-tuning Claude models or training custom models
- Claude API authentication, billing, or account management
- Detailed implementation of specific programming languages or frameworks (beyond what's needed for tool and schema configuration)
- Deploying or hosting MCP servers (infrastructure, networking, container orchestration)
- Claude's internal architecture, training process, or model weights
- Constitutional AI, RLHF, or safety training methodologies
- Embedding models or vector database implementation details
- Computer use (browser automation, desktop interaction)
- Vision/image analysis capabilities
- Streaming API implementation or server-sent events
- Rate limiting, quotas, or API pricing calculations
- OAuth, API key rotation, or authentication protocol details
- Specific cloud provider configurations (AWS, GCP, Azure)
- Performance benchmarking or model comparison metrics
- Prompt caching implementation details (beyond knowing it exists)
- Token counting algorithms or tokenization specifics

## 5. Key concepts & terminology
- **Message Batches API** — asynchronous batch processing API; offers 50% cost savings vs real-time calls; processing time up to 24 hours with no guaranteed latency SLA; correlated via custom_id fields; unsuitable for blocking workflows, ideal for overnight/non-blocking jobs. No multi-turn tool calling support.
- **claude -p / --print flag** — documented way to run Claude Code in non-interactive mode for CI/CD pipelines; processes prompt, outputs to stdout, exits without waiting for input.
- **--output-format json / --json-schema** — CLI options for structured CI output from Claude Code CLI.
- **verify_fact tool (scoped tool)** — example of applying least-privilege tool design: giving an agent a narrow tool for the common case (simple fact lookups) while delegating complex cases elsewhere.
- **Coordinator-subagent pattern** — architecture where a coordinator agent delegates to synthesis/web-search subagents; round trips add latency overhead.
- **Focused review passes** — pattern of splitting a large single-pass review (e.g., 14-file PR) into per-file passes plus a separate cross-file/integration pass to avoid attention dilution and inconsistent review quality.
- **Criterion-referenced assessment** — exam scoring model where candidates are measured against a fixed performance standard (blueprint), not ranked against peers.
- **Scaled score (100–1,000), cut score 720** — CCAF passing standard, set via a formal standard-setting study with subject matter experts judging minimally-qualified-candidate performance.
- **Anthropic Partner Academy** — platform used for exam registration, exam guide download, and free non-proctored renewal assessments.
- **Pearson VUE** — third-party test delivery/proctoring provider; handles scheduling, online proctoring or test-center delivery, accommodations requests, and general candidate support.
- **Retake waiting periods** — 14 days (1st fail), 30 days (2nd fail), 90 days (3rd fail); max 4 attempts per exam in a rolling 12-month period.
- **Credential validity period** — 12 months; renewable via free non-proctored assessment; full retake required if lapsed or if content changes significantly.
- **Confidentiality and Non-Disclosure Agreement (NDA)** — required acceptance before exam start; covers exam content, answer options, scenarios as confidential/proprietary Anthropic property; declining ends session with no refund.
- **Claude Agent SDK** — appendix concept: agent definitions, agentic loops, stop_reason handling, hooks (PostToolUse, tool call interception), subagent spawning via Task tool, allowedTools configuration.
- **Model Context Protocol (MCP)** — MCP servers, MCP tools, MCP resources, isError flag, tool descriptions, tool distribution, .mcp.json configuration, environment variable expansion.
- **Claude Code** — CLAUDE.md configuration hierarchy (user/project/directory), .claude/rules/ with YAML frontmatter path-scoping, .claude/commands/ for slash commands, .claude/skills/ with SKILL.md frontmatter (context: fork, allowed-tools, argument-hint), plan mode, direct execution, /memory command, /compact, --resume, fork_session, Explore subagent.
- **Claude Code CLI** — -p/--print flag for non-interactive mode, --output-format json, --json-schema for structured CI output.
- **Claude API** — tool_use with JSON schemas, tool_choice options ("auto", "any", forced tool selection), stop_reason values ("tool_use", "end_turn"), max_tokens, system prompts.
- **JSON Schema** — required vs optional fields, enum types, nullable fields, "other" + detail string patterns, strict mode for syntax error elimination.
- **Pydantic** — schema validation, semantic validation errors, validation-retry loops.
- **Built-in tools** — Read, Write, Edit, Bash, Grep, Glob — their purposes and selection criteria.
- **Few-shot prompting** — targeted examples for ambiguous scenarios, format demonstration, generalization to novel patterns; false positive reduction.
- **Prompt chaining** — sequential task decomposition into focused passes.
- **Context window management** — token budgets, progressive summarization, lost-in-the-middle effects, context extraction, scratchpad files; also "position-aware input ordering," trimming verbose tool outputs, structured fact extraction.
- **Session management** — session resumption, fork_session, named sessions, session context isolation.
- **Confidence scoring** — field-level confidence, calibration with labeled validation sets, stratified sampling for error rate measurement.
- **@import patterns** — CLAUDE.md configuration mechanism referenced in In-Scope Topics.
- **.claude/rules/ with glob patterns** — path-scoped rule configuration.
- **Task tool** — mechanism for subagent spawning (mentioned under Claude Agent SDK).
- **custom_id** — field used to correlate Message Batches API requests/responses.

## 6. Sample questions / item examples

**Question 9** (continuation of a multi-question scenario; scenario title not shown on this page — appears to be part of a research/multi-agent scenario preceding page 31): During testing, you observe that the synthesis agent frequently needs to verify specific claims while combining findings. Currently, when verification is needed, the synthesis agent returns control to the coordinator, which invokes the web search agent, then re-invokes synthesis with results. This adds 2-3 round trips per task and increases latency by 40%. Your evaluation shows that 85% of these verifications are simple fact-checks (dates, names, statistics) while 15% require deeper investigation. What's the most effective approach to reduce overhead while maintaining system reliability?
A. Give the synthesis agent a scoped verify_fact tool for simple lookups, while complex verifications continue delegating to the web search agent through the coordinator.
B. Have the synthesis agent accumulate all verification needs and return them as a batch to the coordinator at the end of its pass, which then sends them all to the web search agent at once.
C. Give the synthesis agent access to all web search tools so it can handle any verification need directly without round-trips through the coordinator.
D. Have the web search agent proactively cache extra context around each source during initial research, anticipating what the synthesis agent might need to verify.
Correct Answer: A. Option A applies the principle of least privilege by giving the synthesis agent only what it needs for the 85% common case (simple fact verification) while preserving the existing coordination pattern for complex cases. Option B's batching approach creates blocking dependencies since synthesis steps may depend on earlier verified facts. Option C over-provisions the synthesis agent, violating separation of concerns. Option D relies on speculative caching that cannot reliably predict what the synthesis agent will need to verify.

*(Note: the rationale for the preceding Question 8, visible at the very top of page 31 as a continuation, reads: "...Structured error context gives the coordinator the information it needs to make intelligent recovery decisions—whether to retry with a modified query, try an alternative approach, or proceed with partial results. Option B's generic status hides valuable context from the coordinator, preventing informed decisions. Option C suppresses the error by marking failure as success, which prevents any recovery and risks incomplete research outputs. Option D terminates the entire workflow unnecessarily when recovery strategies could succeed." Question 8's own stem/options A/B are NOT in range — only options C, D and the correct-answer rationale for Question 8 appear on page 31.)*

**Scenario: Claude Code for Continuous Integration**

**Question 10:** Your pipeline script runs claude "Analyze this pull request for security issues" but the job hangs indefinitely. Logs indicate Claude Code is waiting for interactive input. What's the correct approach to run Claude Code in an automated pipeline?
A. Add the -p flag: claude -p "Analyze this pull request for security issues"
B. Set the environment variable CLAUDE_HEADLESS=true before running the command
C. Redirect stdin from /dev/null: claude "Analyze this pull request for security issues" < /dev/null
D. Add the --batch flag: claude --batch "Analyze this pull request for security issues"
Correct Answer: A. The -p (or --print) flag is the documented way to run Claude Code in non-interactive mode. It processes the prompt, outputs the result to stdout, and exits without waiting for user input—exactly what CI/CD pipelines require. The other options reference non-existent features (CLAUDE_HEADLESS environment variable, --batch flag) or use Unix workarounds that don't properly address Claude Code's command syntax.

**Question 11:** Your team wants to reduce API costs for automated analysis. Currently, real-time Claude calls power two workflows: (1) a blocking pre-merge check that must complete before developers can merge, and (2) a technical debt report generated overnight for review the next morning. Your manager proposes switching both to the Message Batches API for its 50% cost savings. How should you evaluate this proposal?
A. Use batch processing for the technical debt reports only; keep real-time calls for pre-merge checks.
B. Switch both workflows to batch processing with status polling to check for completion.
C. Keep real-time calls for both workflows to avoid batch result ordering issues.
D. Switch both to batch processing with a timeout fallback to real-time if batches take too long.
Correct Answer: A. The Message Batches API offers 50% cost savings but has processing times up to 24 hours with no guaranteed latency SLA. This makes it unsuitable for blocking pre-merge checks where developers wait for results, but ideal for overnight batch jobs like technical debt reports. Option B is wrong because relying on "often faster" completion isn't acceptable for blocking workflows. Option C reflects a misconception—batch results can be correlated using custom_id fields. Option D adds unnecessary complexity when the simpler solution is matching each API to its appropriate use case.

**Question 12:** A pull request modifies 14 files across the stock tracking module. Your single-pass review analyzing all files together produces inconsistent results: detailed feedback for some files but superficial comments for others, obvious bugs missed, and contradictory feedback—flagging a pattern as problematic in one file while approving identical code elsewhere in the same PR. How should you restructure the review?
A. Split into focused passes: analyze each file individually for local issues, then run a separate integration-focused pass examining cross-file data flow.
B. Require developers to split large PRs into smaller submissions of 3-4 files before the automated review runs.
C. Switch to a higher-tier model with a larger context window to give all 14 files adequate attention in one pass.
D. Run three independent review passes on the full PR and only flag issues that appear in at least two of the three runs.
Correct Answer: A. Splitting reviews into focused passes directly addresses the root cause: attention dilution when processing many files at once. File-by-file analysis ensures consistent depth, while a separate integration pass catches cross-file issues. Option B shifts burden to developers without improving the system. Option C misunderstands that larger context windows don't solve attention quality issues. Option D would actually suppress detection of real bugs by requiring consensus on issues that may only be caught intermittently.

No other sample/example questions appear in pages 31–39 (Question 12 is the last item example; pages 33–39 contain no further exam-style questions).

## 7. Recommended preparation / references
NONE IN RANGE as a dedicated "recommended preparation" section. Related pointers found in this range:
- "Download the Exam Guide and review the Certification Terms and Conditions and the Certification Exam Policy before registering" (Section 11, step 2).
- Appendix Section 17 "Technologies and Concepts" and "In-Scope Topics" / "Out-of-Scope Topics" lists effectively serve as a study-scope reference (fully captured in Sections 4 and 5 above).
- Renewal preparation: "you review what has changed since you certified and complete a free, non-proctored assessment on the Anthropic Partner Academy" (Section 15).

## 8. Anomalies & notes
- Page 31 is the designated overlap page (shared with the neighboring agent covering the preceding range); it was extracted per instructions despite the overlap. Only the tail of Question 8's rationale (options C/D text and correct-answer explanation) and all of Question 9 are visible on this page, plus the start of Question 10 (stem + option A only) — options B–D of Question 10 fall on page 32.
- The scenario title associated with Questions 8–9 (about a coordinator/synthesis/web-search multi-agent research system) is not shown within this range — it must appear on an earlier page (outside this agent's assigned range) and should be cross-checked against the preceding part's extraction.
- Section numbering runs sequentially through this range: 10 (How the Exam Is Scored), 11 (Registration and Scheduling), 12 (Exam Policies), 13 (Exam-Day Experience and Rules of Conduct), 14 (Confidentiality and Non-Disclosure Agreement), 15 (Credential Maintenance and Recertification), 16 (Candidate Support, Appeals, and Privacy), 17 (Appendix), 18 (Document Control). No section numbers were skipped or duplicated within range.
- No domain-weighting table (e.g., percentage breakdown by content domain) appears anywhere in pages 31–39; if such a table exists it must be earlier in the document (pages 1–30), outside this agent's range.
- The Appendix "Technologies and Concepts" and "In-Scope Topics"/"Out-of-Scope Topics" lists are presented as flat bullet lists with no numbering in the source PDF — hierarchy shown in Section 4 above (bold lead term + colon + sub-items) mirrors the source formatting exactly.
- Document Control table confirms this is version 1.0, dated July 2026, consistent with the stated currentDate context (2026-08-01) — the guide appears current/final as of the extraction date.
- Page 39 is the final page of the 39-page PDF; nothing follows the Document Control table.
