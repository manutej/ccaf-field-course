# W1 Solution Sketch — Objective Registry Merge (live fresh-agent probe)

**Note on sequencing:** this sketch was written to restate the packet in my own words as required, but I want to be transparent: I read the four shard files and the META-PLAN's W1 section in the same tool-call batch as my initial reconnaissance, before drafting this sketch. I did not build any output artifact before drafting it, so the gating intent (sketch-before-build) is preserved, but I did not literally sketch before opening the input files. Flagging this so it isn't misrepresented as a clean blind restatement.

## (a) My job
I am W1 in the CCAF exam-mastery pipeline: the objective registry merge unit, and — per the plan's explicit design — the **live fresh-agent probe** that tests whether the plan's context packets are self-sufficient for a cold agent. My job is to fuse four page-range extraction shards of the official CCAF (Claude Certified Architect – Foundations) exam guide into one canonical, machine-readable registry of everything the exam guide defines: exam metadata, the 5 weighted domains, all task statements with their "Knowledge of" / "Skills in" bullets, the 6 scenarios, the 12 sample questions (with answers/rationales), the in-scope/out-of-scope appendix lists, "how to prepare" guidance, and preparation exercises. This registry becomes the frozen spine that a later fable agent uses to build a depth-4 typed question tree, and that an opus reviewer later audits for completeness against the source guide.

## (b) My inputs
- Four extraction shards, each covering a page range of the 39-page guide, with intentional overlap pages at the shard boundaries:
  - `/home/claude/work/ccaf/extraction/part-1-pages-01-11.md`
  - `/home/claude/work/ccaf/extraction/part-2-pages-11-21.md`
  - `/home/claude/work/ccaf/extraction/part-3-pages-21-31.md`
  - `/home/claude/work/ccaf/extraction/part-4-pages-31-39.md`
- A list of known seams to resolve by cross-referencing shards: Task Statement 2.5 truncated at page 11 (completed in part 2); Task 5.4 truncated at page 21 (completed in part 3); sample Question 10 truncated at page 31 (completed in part 4); page-21 trailing bullets likely belonging to 5.2/5.3 (in fact, verified to be the tail of 5.2's Skills-in list, already fully captured elsewhere — not a new objective).
- Optionally, the plan document at `/home/claude/work/ccaf/plan/META-PLAN.md` (§W1) and `gap-report.md` for context on why I'm the probe and what "done" means at the meta-plan level.

## (c) My done-criteria
Before finishing I must verify:
1. All 5 domains present with weights summing to exactly 100 (27+18+20+20+15).
2. Task statements 1.1–1.7, 2.1–2.5, 3.1–3.6, 4.1–4.6, 5.1–5.6 (30 total) all present, each with non-empty `knowledge_of` AND `skills_in`.
3. All 12 sample questions complete with a correct-answer letter and a rationale.
4. Seams resolved with no duplicated bullets (i.e., overlap-page content merged once, not doubled).
5. `registry.json` parses (`python3 -c "import json; json.load(open(...))"`).
6. Produce both `registry.json` (machine-canonical) and `registry.md` (human-readable, with a completeness ledger at the top).

I verified all six mechanically (see final report) rather than asserting them.

## (d) My downstream neighbors
- **Upstream:** none besides the raw shard files and (implicitly) `W0`'s path reconnaissance — I did not require `PATHS.json` since my own prompt gave me absolute paths directly.
- **Downstream, per the packet:**
  - A **fable agent** that will build a depth-4 typed operadic question tree from this registry — it needs every objective bullet intact and quotable, because (per the meta-plan) every leaf question must map to ≥1 objective, and the registry is the thing being covered.
  - An **opus reviewer** who will audit my registry against the source guide for completeness (spot-checking task-statement counts per domain, quoting bullet lists, and confirming pages 5–39 are represented) — this is `W1R` in the meta-plan, an independent opus gate (I7: reviewed by an opus agent that did not produce it).

## Findings against the packet (not against me)

1. **Schema mismatch between this task's literal output contract and the META-PLAN's IC-1.** This prompt specifies output files `registry.json` / `registry.md` with a nested schema (`domains[].task_statements[]` keyed by dotted id like `"1.1"`). The META-PLAN's own IC-1 interface contract (§5) specifies `objectives.json` / `objectives.md` with a flat, one-row-per-bullet schema keyed by `objective_id` in the format `D{1-5}.T{n}.{K|S}{m}`. These are genuinely different shapes — not just filenames. I followed the schema given verbatim in my own work-unit prompt (the more specific, directly-addressed instruction), per the escalation rule's spirit of not fabricating structure beyond what's given, but this is a real discrepancy the orchestrator/W1R should reconcile: if downstream units (W2, W3a, W4, W8, W13) were built expecting IC-1's shape, my output will need a translation step, or IC-1 itself needs correcting to match what was actually rendered into my prompt. I flag this rather than silently picking one and hiding the conflict.

2. **Scenario narrative bodies are not recoverable from the shards.** The packet implies "the 6 exam scenarios" should appear in the registry, and part-1's own page ledger claims scenario "full text" exists on pages 3–4 — but no shard actually transcribed that narrative body text anywhere in its structured sections; only scenario titles and primary-domain mappings survive. I did not fabricate scenario narratives. If the depth-4 tree or the wiki need scenario body text (e.g., to ground "in ANY scenario" leaf questions), that content does not exist in this registry and would require a re-extraction pass reading the source PDF directly at pages 3–4 — a gap the packet did not warn me about.

3. **The seam list given in the prompt was accurate for 3 of 4 items but described the 4th imprecisely.** "Page-21 trailing bullets likely belonging to 5.2/5.3" — on inspection, these bullets are exactly the last four Skills-in bullets of Task 5.2, already captured in full in part-2. Treating them as a new/uncertain seam risked double-counting them as a separate unlabeled objective; I resolved this by recognizing the duplication and not re-adding them. A packet that had said "these are a known duplicate of 5.2, verify and drop" would have saved a verification step.

4. **Domain 5's section-opening/overview page was never captured by any shard** (only task-statement numbering and "Domains reinforced" lines confirm its existence and name). This is a minor completeness gap in the underlying shards, not something I could repair without the source PDF — flagged in `anomalies`, not silently patched.

None of these blocked completion — all done-criteria were met — but items 1 and 2 are the ones I'd escalate to the orchestrator before this registry gets treated as unconditionally frozen input to the fable tree-building unit.
