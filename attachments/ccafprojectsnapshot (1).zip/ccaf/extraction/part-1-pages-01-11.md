# CCAF Exam Guide — Extraction Part 1 (pages 1–11)

## 1. Page ledger
- Page 1: Cover/header ("Claude Certification Program" / "Exam guide"); Title "Claude Certified Architect – Foundations", subtitle "Exam Guide"; version line ("Version 1.0 · Effective July 2026 · Exam code: CCAR-F · This guide is subject to change without notice."); Section 1 "About This Certification" (3 paragraphs); Section 2 "Intended Audience" begins (intro sentence + first 4 bullets of candidate hands-on experience list).
- Page 2: Section 2 "Intended Audience" continues — 3 more bullets, then a closing paragraph on candidate experience level (6+ months). Section 3 "Exam Details at a Glance" — full details table (Credential, Exam code, Number of items, Item format, Exam structure, Time limit, Delivery, Passing score, Exam fee, Validity period, Result reporting).
- Page 3: Section 4 "Exam Content Outline (Blueprint)" — intro paragraph + full domain weighting table (5 domains + total). Section 5 "Exam Scenarios" begins — intro paragraph, Scenario 1 (Customer Support Resolution Agent, full text + primary domains), Scenario 2 title only ("Code Generation with Claude Code").
- Page 4: Scenario 2 body (Code Generation with Claude Code) + primary domains; Scenario 3 (Multi-Agent Research System) full text + primary domains; Scenario 4 (Developer Productivity with Claude) full text + primary domains; Scenario 5 (Claude Code for Continuous Integration) full text + primary domains; Scenario 6 (Structured Data Extraction) full text + primary domains.
- Page 5: Section 6 "Detailed Objectives by Domain" intro. "Domain 1: Agentic Architecture & Orchestration" header. Task Statement 1.1 (Design and implement agentic loops for autonomous task execution) — full Knowledge of (3 bullets) and Skills in (3 bullets). Task Statement 1.2 (Orchestrate multi-agent systems with coordinator-subagent patterns) title + Knowledge of (3 bullets) begins.
- Page 6: Task Statement 1.2 continues — 1 more Knowledge of bullet (risks of overly narrow task decomposition), then Skills in (4 bullets). Task Statement 1.3 (Configure subagent invocation, context passing, and spawning) — full Knowledge of (4 bullets) and Skills in (4 bullets, last one starting).
- Page 7: Task Statement 1.4 (Implement multi-step workflows with enforcement and handoff patterns) — full Knowledge of (3 bullets) and Skills in (3 bullets). Task Statement 1.5 (Apply Agent SDK hooks for tool call interception and data normalization) — full Knowledge of (3 bullets) and Skills in (3 bullets).
- Page 8: Task Statement 1.6 (Design task decomposition strategies for complex workflows) — full Knowledge of (3 bullets) and Skills in (3 bullets). Task Statement 1.7 (Manage session state, resumption, and forking) — full Knowledge of (4 bullets) and Skills in (3 bullets, last one starting).
- Page 9: Task Statement 1.7 concludes (1 more Skills in bullet: informing a resumed session about specific file changes). "Domain 2: Tool Design & MCP Integration" header. Task Statement 2.1 (Design effective tool interfaces with clear descriptions and boundaries) — full Knowledge of (4 bullets) and Skills in (4 bullets). Task Statement 2.2 (Implement structured error responses for MCP tools) — Knowledge of begins (2 bullets shown).
- Page 10: Task Statement 2.2 continues — 2 more Knowledge of bullets, then Skills in (4 bullets, full). Task Statement 2.3 (Distribute tools appropriately across agents and configure tool choice) — full Knowledge of (4 bullets) and Skills in (3 bullets, last one starting).
- Page 11: Task Statement 2.3 concludes (2 more Skills in bullets: tool_choice forced selection; tool_choice "any"). Task Statement 2.4 (Integrate MCP servers into Claude Code and agent workflows) — full Knowledge of (4 bullets) and Skills in (5 bullets). Task Statement 2.5 (Select and apply built-in tools (Read, Write, Edit, Bash, Grep, Glob) effectively) — Knowledge of begins (3 bullets shown, section cut off at page range boundary — continues on page 12, out of range).

## 2. Exam metadata (verbatim where possible)
- Credential/Exam name: "Claude Certified Architect – Foundations"
- Document title: "Exam Guide"
- Version line (verbatim): "Version 1.0 · Effective July 2026 · Exam code: CCAR-F · This guide is subject to change without notice."
- Exam code: CCAR-F
- Number of items: 60
- Item format: "Multiple-choice and multiple-response items; each item states how many responses to select"
- Exam structure: "4 scenarios drawn from a bank of 6"
- Time limit: 120 minutes
- Delivery: "Proctored: online proctored and/or test center, per program policy"
- Passing score: "Scaled score of 720 on a scale of 100–1,000"
- Exam fee: "$125 USD"
- Validity period: "12 months from the date the credential is awarded"
- Result reporting: "Pass/fail with scaled score (100–1,000), plus percent-correct by domain on the score report"
- Prerequisites: none explicitly stated in this range (no "Prerequisites" field appears in the Exam Details at a Glance table; only "typical" experience level is described under Intended Audience)
- Audience (verbatim, Section 2 intro): "The ideal candidate for this certification is a solution architect who designs and implements production applications with Claude. This candidate has hands-on experience with:"
  - "Building agentic applications using the Claude Agent SDK, including multi-agent orchestration, subagent delegation, tool integration, and lifecycle hooks"
  - "Configuring and customizing Claude Code for team workflows using CLAUDE.md files, Agent Skills, MCP server integrations, and plan mode"
  - "Designing Model Context Protocol (MCP) tool and resource interfaces for backend system integration"
  - "Engineering prompts that produce reliable structured output, leveraging JSON schemas, few-shot examples, and extraction patterns"
  - "Managing context windows effectively across long documents, multi-turn conversations, and multi-agent handoffs"
  - "Integrating Claude into CI/CD pipelines for automated code review, test generation, and pull request feedback"
  - "Making sound escalation and reliability decisions, including error handling, human-in-the-loop workflows, and self-evaluation patterns"
- Experience level (verbatim): "The candidate typically has 6+ months of practical experience building with Claude APIs, Agent SDK, Claude Code, and MCP, understanding both the capabilities and limitations of large language models in production environments."
- About/purpose (verbatim, Section 1, paragraph 1): "The Claude Certified Architect – Foundations certification validates that practitioners can make informed decisions about tradeoffs when implementing real-world solutions with Claude. This exam tests foundational knowledge across Claude Code, the Claude Agent SDK, the Claude API, and Model Context Protocol (MCP), the core technologies used to build production-grade applications with Claude."
- (verbatim, paragraph 2): "Questions on this exam are grounded in realistic scenarios drawn from actual customer use cases, including building agentic systems for customer support, designing multi-agent research pipelines, integrating Claude Code into CI/CD workflows, building developer productivity tools, and extracting structured data from unstructured documents. Candidates must demonstrate not only conceptual knowledge but practical judgment about architecture, configuration, and tradeoffs in production deployments."
- (verbatim, paragraph 3): "This guide is the authoritative reference for candidates preparing to sit the exam. It describes the exam content, lists the domains and task statements tested, provides sample questions, and recommends preparation strategies. Read it in full before scheduling your exam."
- Cost: $125 USD (see above)

## 3. Domains & weightings (VERBATIM)
From Section 4, "Exam Content Outline (Blueprint)":
Intro (verbatim): "The exam blueprint defines the content domains measured and the approximate weight of each domain on the exam. Weights reflect the relative importance of each domain to competent performance as determined through the job task analysis. The percentages indicate the approximate proportion of scored items drawn from each domain."

| Domain | Content Domain | Weight |
|---|---|---|
| 1 | Agentic Architecture & Orchestration | 27% |
| 2 | Tool Design & MCP Integration | 18% |
| 3 | Claude Code Configuration & Workflows | 20% |
| 4 | Prompt Engineering & Structured Output | 20% |
| 5 | Context Management & Reliability | 15% |
| Total | | 100% |

(Note: Domains 3, 4, 5 are named/weighted here but their detailed objectives fall outside this extraction's page range — pages 1–11 only cover Domain 1 fully and Domain 2 partially, through Task Statement 2.5's Knowledge of intro.)

## 4. Objectives / skills measured (VERBATIM numbering and wording)

Section 6 intro (verbatim): "Each domain below lists the task statements tested, with the knowledge and skills measured against each. Exam items are written against these objectives."

### Domain 1: Agentic Architecture & Orchestration

**Task Statement 1.1: Design and implement agentic loops for autonomous task execution**

Knowledge of:
- The agentic loop lifecycle: sending requests to Claude, inspecting stop_reason ("tool_use" vs "end_turn"), executing requested tools, and returning results for the next iteration
- How tool results are appended to conversation history so the model can reason about the next action
- The distinction between model-driven decision-making (Claude reasons about which tool to call next based on context) and pre-configured decision trees or tool sequences

Skills in:
- Implementing agentic loop control flow that continues when stop_reason is "tool_use" and terminates when stop_reason is "end_turn"
- Adding tool results to conversation context between iterations so the model can incorporate new information into its reasoning
- Avoiding anti-patterns such as parsing natural language signals to determine loop termination, setting arbitrary iteration caps as the primary stopping mechanism, or checking for assistant text content as a completion indicator

**Task Statement 1.2: Orchestrate multi-agent systems with coordinator-subagent patterns**

Knowledge of:
- Hub-and-spoke architecture where a coordinator agent manages all inter-subagent communication, error handling, and information routing
- How subagents operate with isolated context—they do not inherit the coordinator's conversation history automatically
- The role of the coordinator in task decomposition, delegation, result aggregation, and deciding which subagents to invoke based on query complexity
- Risks of overly narrow task decomposition by the coordinator, leading to incomplete coverage of broad research topics

Skills in:
- Designing coordinator agents that analyze query requirements and dynamically select which subagents to invoke rather than always routing through the full pipeline
- Partitioning research scope across subagents to minimize duplication (e.g., assigning distinct subtopics or source types to each agent)
- Implementing iterative refinement loops where the coordinator evaluates synthesis output for gaps, re-delegates to search and analysis subagents with targeted queries, and re-invokes synthesis until coverage is sufficient
- Routing all subagent communication through the coordinator for observability, consistent error handling, and controlled information flow

**Task Statement 1.3: Configure subagent invocation, context passing, and spawning**

Knowledge of:
- The Task tool as the mechanism for spawning subagents, and the requirement that allowedTools must include "Task" for a coordinator to invoke subagents
- That subagent context must be explicitly provided in the prompt—subagents do not automatically inherit parent context or share memory between invocations
- The AgentDefinition configuration including descriptions, system prompts, and tool restrictions for each subagent type
- Fork-based session management for exploring divergent approaches from a shared analysis baseline

Skills in:
- Including complete findings from prior agents directly in the subagent's prompt (e.g., passing web search results and document analysis outputs to the synthesis subagent)
- Using structured data formats to separate content from metadata (source URLs, document names, page numbers) when passing context between agents to preserve attribution
- Spawning parallel subagents by emitting multiple Task tool calls in a single coordinator response rather than across separate turns
- Designing coordinator prompts that specify research goals and quality criteria rather than step-by-step procedural instructions, to enable subagent adaptability

**Task Statement 1.4: Implement multi-step workflows with enforcement and handoff patterns**

Knowledge of:
- The difference between programmatic enforcement (hooks, prerequisite gates) and prompt-based guidance for workflow ordering
- When deterministic compliance is required (e.g., identity verification before financial operations), prompt instructions alone have a non-zero failure rate
- Structured handoff protocols for mid-process escalation that include customer details, root cause analysis, and recommended actions

Skills in:
- Implementing programmatic prerequisites that block downstream tool calls until prerequisite steps have completed (e.g., blocking process_refund until get_customer has returned a verified customer ID)
- Decomposing multi-concern customer requests into distinct items, then investigating each in parallel using shared context before synthesizing a unified resolution
- Compiling structured handoff summaries (customer ID, root cause, refund amount, recommended action) when escalating to human agents who lack access to the conversation transcript

**Task Statement 1.5: Apply Agent SDK hooks for tool call interception and data normalization**

Knowledge of:
- Hook patterns (e.g., PostToolUse) that intercept tool results for transformation before the model processes them
- Hook patterns that intercept outgoing tool calls to enforce compliance rules (e.g., blocking refunds above a threshold)
- The distinction between using hooks for deterministic guarantees versus relying on prompt instructions for probabilistic compliance

Skills in:
- Implementing PostToolUse hooks to normalize heterogeneous data formats (Unix timestamps, ISO 8601, numeric status codes) from different MCP tools before the agent processes them
- Implementing tool call interception hooks that block policy-violating actions (e.g., refunds exceeding $500) and redirect to alternative workflows (e.g., human escalation)
- Choosing hooks over prompt-based enforcement when business rules require guaranteed compliance

**Task Statement 1.6: Design task decomposition strategies for complex workflows**

Knowledge of:
- When to use fixed sequential pipelines (prompt chaining) versus dynamic adaptive decomposition based on intermediate findings
- Prompt chaining patterns that break reviews into sequential steps (e.g., analyze each file individually, then run a cross-file integration pass)
- The value of adaptive investigation plans that generate subtasks based on what is discovered at each step

Skills in:
- Selecting task decomposition patterns appropriate to the workflow: prompt chaining for predictable multi-aspect reviews, dynamic decomposition for open-ended investigation tasks
- Splitting large code reviews into per-file local analysis passes plus a separate cross-file integration pass to avoid attention dilution
- Decomposing open-ended tasks (e.g., "add comprehensive tests to a legacy codebase") by first mapping structure, identifying high-impact areas, then creating a prioritized plan that adapts as dependencies are discovered

**Task Statement 1.7: Manage session state, resumption, and forking**

Knowledge of:
- Named session resumption using --resume <session-name> to continue a specific prior conversation
- fork_session for creating independent branches from a shared analysis baseline to explore divergent approaches
- The importance of informing the agent about changes to previously analyzed files when resuming sessions after code modifications
- Why starting a new session with a structured summary is more reliable than resuming with stale tool results

Skills in:
- Using --resume with session names to continue named investigation sessions across work sessions
- Using fork_session to create parallel exploration branches (e.g., comparing two testing strategies or refactoring approaches from a shared codebase analysis)
- Choosing between session resumption (when prior context is mostly valid) and starting fresh with injected summaries (when prior tool results are stale)
- Informing a resumed session about specific file changes for targeted re-analysis rather than requiring full re-exploration

### Domain 2: Tool Design & MCP Integration

**Task Statement 2.1: Design effective tool interfaces with clear descriptions and boundaries**

Knowledge of:
- Tool descriptions as the primary mechanism LLMs use for tool selection; minimal descriptions lead to unreliable selection among similar tools
- The importance of including input formats, example queries, edge cases, and boundary explanations in tool descriptions
- How ambiguous or overlapping tool descriptions cause misrouting (e.g., analyze_content vs analyze_document with near-identical descriptions)
- The impact of system prompt wording on tool selection: keyword-sensitive instructions can create unintended tool associations

Skills in:
- Writing tool descriptions that clearly differentiate each tool's purpose, expected inputs, outputs, and when to use it versus similar alternatives
- Renaming tools and updating descriptions to eliminate functional overlap (e.g., renaming analyze_content to extract_web_results with a web-specific description)
- Splitting generic tools into purpose-specific tools with defined input/output contracts (e.g., splitting a generic analyze_document into extract_data_points, summarize_content, and verify_claim_against_source)
- Reviewing system prompts for keyword-sensitive instructions that might override well-written tool descriptions

**Task Statement 2.2: Implement structured error responses for MCP tools**

Knowledge of:
- The MCP isError flag pattern for communicating tool failures back to the agent
- The distinction between transient errors (timeouts, service unavailability), validation errors (invalid input), business errors (policy violations), and permission errors
- Why uniform error responses (generic "Operation failed") prevent the agent from making appropriate recovery decisions
- The difference between retryable and non-retryable errors, and how returning structured metadata prevents wasted retry attempts

Skills in:
- Returning structured error metadata including errorCategory (transient/validation/permission), isRetryable boolean, and human-readable descriptions
- Including retryable: false flags and customer-friendly explanations for business rule violations so the agent can communicate appropriately
- Implementing local error recovery within subagents for transient failures, propagating to the coordinator only errors that cannot be resolved locally along with partial results and what was attempted
- Distinguishing between access failures (needing retry decisions) and valid empty results (representing successful queries with no matches)

**Task Statement 2.3: Distribute tools appropriately across agents and configure tool choice**

Knowledge of:
- The principle that giving an agent access to too many tools (e.g., 18 instead of 4-5) degrades tool selection reliability by increasing decision complexity
- Why agents with tools outside their specialization tend to misuse them (e.g., a synthesis agent attempting web searches)
- Scoped tool access: giving agents only the tools needed for their role, with limited cross-role tools for specific high-frequency needs
- tool_choice configuration options: "auto", "any", and forced tool selection ({"type": "tool", "name": "..."})

Skills in:
- Restricting each subagent's tool set to those relevant to its role, preventing cross-specialization misuse
- Replacing generic tools with constrained alternatives (e.g., replacing fetch_url with load_document that validates document URLs)
- Providing scoped cross-role tools for high-frequency needs (e.g., a verify_fact tool for the synthesis agent) while routing complex cases through the coordinator
- Using tool_choice forced selection to ensure a specific tool is called first (e.g., forcing extract_metadata before enrichment tools), then processing subsequent steps in follow-up turns
- Setting tool_choice: "any" to guarantee the model calls a tool rather than returning conversational text

**Task Statement 2.4: Integrate MCP servers into Claude Code and agent workflows**

Knowledge of:
- MCP server scoping: project-level (.mcp.json) for shared team tooling vs user-level (~/.claude.json) for personal/experimental servers
- Environment variable expansion in .mcp.json (e.g., ${GITHUB_TOKEN}) for credential management without committing secrets
- That tools from all configured MCP servers are discovered at connection time and available simultaneously to the agent
- MCP resources as a mechanism for exposing content catalogs (e.g., issue summaries, documentation hierarchies, database schemas) to reduce exploratory tool calls

Skills in:
- Configuring shared MCP servers in project-scoped .mcp.json with environment variable expansion for authentication tokens
- Configuring personal/experimental MCP servers in user-scoped ~/.claude.json
- Enhancing MCP tool descriptions to explain capabilities and outputs in detail, preventing the agent from preferring built-in tools (like Grep) over more capable MCP tools
- Choosing existing community MCP servers over custom implementations for standard integrations (e.g., Jira), reserving custom servers for team-specific workflows
- Exposing content catalogs as MCP resources to give agents visibility into available data without requiring exploratory tool calls

**Task Statement 2.5: Select and apply built-in tools (Read, Write, Edit, Bash, Grep, Glob) effectively**

Knowledge of (partial — continues beyond page 11 / this range):
- Grep for content search (searching file contents for patterns like function names, error messages, or import statements)
- Glob for file path pattern matching (finding files by name or extension patterns)
- Read/Write for full file operations; Edit for targeted modifications using unique text matching
- [Remainder of Task Statement 2.5 and any subsequent task statements fall outside pages 1–11; not extracted here — out of range]

## 5. Key concepts & terminology
- **Claude Agent SDK** — SDK for building agentic applications with Claude; covers orchestration, subagent delegation, tool integration, lifecycle hooks.
- **Claude Code** — Anthropic's coding agent/CLI; configured via CLAUDE.md, slash commands, Agent Skills, MCP integrations, plan mode.
- **Claude API** — underlying API tested as a core technology alongside Agent SDK, Claude Code, MCP.
- **Model Context Protocol (MCP)** — protocol for exposing tools/resources to Claude for backend system integration.
- **CLAUDE.md** — configuration file for customizing Claude Code team workflows.
- **Agent Skills** — reusable skill packages configurable within Claude Code.
- **Plan mode** — a Claude Code execution mode contrasted with direct execution.
- **Agentic loop** — the cycle of request → stop_reason inspection → tool execution → result return → next iteration.
- **stop_reason ("tool_use" / "end_turn")** — API field indicating whether Claude wants to call a tool or has finished its turn; used to control loop continuation/termination.
- **Coordinator-subagent (hub-and-spoke) pattern** — architecture where one coordinator manages all subagent communication, error handling, routing.
- **Subagent isolated context** — subagents don't automatically inherit the coordinator's conversation history; context must be explicitly passed.
- **Task tool** — mechanism for spawning subagents; requires "Task" in allowedTools.
- **AgentDefinition** — configuration object specifying descriptions, system prompts, and tool restrictions per subagent type.
- **fork_session** — mechanism for creating independent session branches from a shared baseline to explore divergent approaches.
- **--resume <session-name>** — CLI flag for resuming a named prior session.
- **Hooks (Agent SDK)** — interception points in the agentic loop; e.g., PostToolUse hook for transforming/normalizing tool results, and hooks for blocking policy-violating tool calls.
- **PostToolUse hook** — specific hook pattern for intercepting/normalizing tool results after execution (e.g., timestamp normalization).
- **Programmatic enforcement vs prompt-based guidance** — deterministic gating (hooks, prerequisite checks) vs relying on natural-language instructions (probabilistic, non-zero failure rate).
- **Prompt chaining** — fixed sequential task decomposition pattern (e.g., per-file analysis then cross-file integration pass).
- **Dynamic/adaptive task decomposition** — subtasks generated based on intermediate findings, for open-ended investigations.
- **MCP isError flag** — pattern for flagging tool call failures back to the calling agent.
- **Error categories** — transient (timeouts, service unavailability), validation (invalid input), business/policy errors, permission errors.
- **errorCategory / isRetryable metadata** — structured error response fields recommended for MCP tool responses.
- **tool_choice** — API parameter controlling tool selection behavior: "auto", "any", or forced selection via {"type": "tool", "name": "..."}.
- **Scoped tool access** — restricting each agent/subagent to only the tools relevant to its role to reduce misuse and selection errors.
- **.mcp.json** — project-level MCP server configuration file for shared team tooling.
- **~/.claude.json** — user-level MCP server configuration file for personal/experimental servers.
- **Environment variable expansion (e.g., ${GITHUB_TOKEN})** — mechanism in .mcp.json for credential management without committing secrets.
- **MCP resources** — mechanism (distinct from tools) for exposing content catalogs (issue summaries, documentation hierarchies, database schemas) to reduce exploratory tool calls.
- **Built-in tools: Read, Write, Edit, Bash, Grep, Glob** — Claude Code's native tool set; Grep for content search, Glob for filename pattern matching, Read/Write for full-file ops, Edit for targeted unique-text-match modifications.
- **CI/CD integration** — using Claude Code for automated code review, test generation, and pull request feedback.
- **JSON schemas / structured output / few-shot examples / extraction patterns** — named under Domain 4 audience skills (Prompt Engineering & Structured Output), not detailed further in this page range.
- **Human-in-the-loop workflows, self-evaluation patterns, error handling/escalation** — named under Domain 5 audience skills (Context Management & Reliability), not detailed further in this range.
- **get_customer, lookup_order, process_refund, escalate_to_human** — example custom MCP tool names used in Scenario 1 (Customer Support Resolution Agent).
- **analyze_content / analyze_document / extract_web_results / extract_data_points / summarize_content / verify_claim_against_source** — example tool names used to illustrate tool-description ambiguity/splitting in Task 2.1.
- **fetch_url / load_document** — example of replacing a generic tool with a constrained, validating alternative (Task 2.3).
- **verify_fact** — example scoped cross-role tool for a synthesis agent (Task 2.3).
- **extract_metadata** — example of forced tool_choice usage (Task 2.3).

## 6. Sample questions / item examples
NONE IN RANGE — no worked sample questions, answer options, or rationales appear on pages 1–11. (Note: Section 1 states the guide "provides sample questions," implying they appear later in the document, likely outside this page range.)

## 7. Recommended preparation / references
NONE IN RANGE — no links, courses, or external resource recommendations appear on pages 1–11. (Note: Section 1 mentions the guide "recommends preparation strategies," implying such content appears later in the document, outside this range.)

## 8. Anomalies & notes
- The guide's effective date ("Effective July 2026") is in the future relative to a document dated/retrieved in 2026; combined with "Version 1.0," this reads as a newly issued/upcoming exam guide — worth flagging to downstream agents in case dates matter for currency questions.
- The Exam Details table has no explicit "Prerequisites" row; only narrative "Intended Audience" / experience-level text substitutes for a formal prerequisites field. Downstream agents building a prerequisites-specific question branch should note this gap rather than assume a stated prerequisite.
- Domain weights sum correctly to 100% (27+18+20+20+15=100), no arithmetic inconsistency.
- Six exam scenarios are defined (bank of 6), but the exam only presents 4 per sitting, randomly selected — this "4 of 6" structure is an important nuance for exam-structure questions.
- Task Statement 2.5's Knowledge of list is truncated at the end of page 11 (cut off mid-list, before Skills in section); its continuation and any further task statements (2.6+, if any) plus Domains 3, 4, 5 fall entirely outside this extraction's page range (1–11) and must be captured by the downstream/next-range agent — flagging so nothing is assumed complete for Domain 2.
- No inconsistencies, typos, or version-conflict language observed within pages 1–11 beyond the future-dated effective date noted above.
- Scenario-to-domain mappings (Section 5) list only 2-3 "primary domains" per scenario out of the 5 total domains — e.g., Scenario 1 maps to Domains 1, 2, 5 but not 3 or 4; this pattern should be preserved verbatim per scenario for downstream mapping/question-tree work:
  - Scenario 1 (Customer Support Resolution Agent): Agentic Architecture & Orchestration, Tool Design & MCP Integration, Context Management & Reliability
  - Scenario 2 (Code Generation with Claude Code): Claude Code Configuration & Workflows, Context Management & Reliability
  - Scenario 3 (Multi-Agent Research System): Agentic Architecture & Orchestration, Tool Design & MCP Integration, Context Management & Reliability
  - Scenario 4 (Developer Productivity with Claude): Tool Design & MCP Integration, Claude Code Configuration & Workflows, Agentic Architecture & Orchestration
  - Scenario 5 (Claude Code for Continuous Integration): Claude Code Configuration & Workflows, Prompt Engineering & Structured Output
  - Scenario 6 (Structured Data Extraction): Prompt Engineering & Structured Output, Context Management & Reliability
