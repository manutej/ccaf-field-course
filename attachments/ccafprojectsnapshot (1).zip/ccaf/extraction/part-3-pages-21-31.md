# CCAF Exam Guide — Extraction Part 3 (pages 21–31)

## 1. Page ledger

- Page 21 → Tail end of a bulleted list (unlabeled parent objective, likely Task Statement 5.2 escalation-related skills — heading not visible in range, only trailing bullets); full Task Statement 5.3 "Implement error propagation strategies across multi-agent systems" (Knowledge of + Skills in); start of Task Statement 5.4 "Manage context effectively in large codebase exploration" (Knowledge of, first 2 bullets). [NOTE: page 21 is the overlap page with the prior agent's range.]
- Page 22 → Continuation of Task Statement 5.4 (remaining Knowledge of bullets + full Skills in); full Task Statement 5.5 "Design human review workflows and confidence calibration" (Knowledge of + Skills in, first 4 bullets).
- Page 23 → Full Task Statement 5.6 "Preserve information provenance and handle uncertainty in multi-source synthesis" (Knowledge of + Skills in); start of Section "7. How to Prepare" (intro line + first 2 bullets).
- Page 24 → Continuation of Section 7 "How to Prepare" (remaining bullets); start of Section "8. Preparation Exercises" (intro line); Exercise 1 "Build a Multi-Tool Agent with Escalation Logic" — Objective + Steps (first 3 bullets).
- Page 25 → Continuation/end of Exercise 1 Steps + "Domains reinforced" line; full Exercise 2 "Configure Claude Code for a Team Development Workflow" (Objective + Steps + Domains reinforced); start of Exercise 3 "Build a Structured Data Extraction Pipeline" (Objective + first Step).
- Page 26 → Continuation/end of Exercise 3 Steps + "Domains reinforced"; full Exercise 4 "Design and Debug a Multi-Agent Research Pipeline" (Objective + Steps + Domains reinforced).
- Page 27 → Start of Section "9. Sample Questions" (intro line); Scenario: "Customer Support Resolution Agent"; Question 1 (full, with correct answer + rationale); Question 2 (question stem + options only, answer continues on p.28).
- Page 28 → Correct answer + rationale for Question 2; Question 3 (full, with answer + rationale); Scenario: "Code Generation with Claude Code"; Question 4 (question stem + options only, answer continues on p.29).
- Page 29 → Correct answer + rationale for Question 4; Question 5 (full, with answer + rationale); Question 6 (question stem + options only, answer continues on p.30).
- Page 30 → Correct answer + rationale for Question 6; Scenario: "Multi-Agent Research System"; Question 7 (full, with answer + rationale); Question 8 (question stem + options A/B only, continues on p.31).
- Page 31 → Options C/D + correct answer + rationale for Question 8; Question 9 (full, with answer + rationale); Scenario: "Claude Code for Continuous Integration"; Question 10 (question stem + option A only — cut off at end of range; remaining options are out of range on page 32+).

## 2. Exam metadata (verbatim where possible)

NONE IN RANGE. (No title-page metadata, exam code, duration, question count, passing score, or pricing appears on pages 21–31. Running header throughout: "Claude Certification Program" / "Exam guide".)

## 3. Domains & weightings (VERBATIM)

No formal domain/weighting table appears in this page range. However, "Domains reinforced" lines under each Preparation Exercise name domains verbatim (see Section 4 for full domain names as they appear):

- "Domains reinforced: Domain 1 (Agentic Architecture & Orchestration), Domain 2 (Tool Design & MCP Integration), Domain 5 (Context Management & Reliability)" — Exercise 1 (p.25)
- "Domains reinforced: Domain 3 (Claude Code Configuration & Workflows), Domain 2 (Tool Design & MCP Integration)" — Exercise 2 (p.25)
- "Domains reinforced: Domain 4 (Prompt Engineering & Structured Output), Domain 5 (Context Management & Reliability)" — Exercise 3 (p.26)
- "Domains reinforced: Domain 1 (Agentic Architecture & Orchestration), Domain 2 (Tool Design & MCP Integration), Domain 5 (Context Management & Reliability)" — Exercise 4 (p.26)

This confirms five domain names (verbatim as they appear here):
1. Domain 1: Agentic Architecture & Orchestration
2. Domain 2: Tool Design & MCP Integration
3. Domain 3: Claude Code Configuration & Workflows
4. Domain 4: Prompt Engineering & Structured Output
5. Domain 5: Context Management & Reliability

No percentage weightings appear anywhere in pages 21–31.

## 4. Objectives / skills measured (VERBATIM numbering and wording)

Note: Task Statements 5.3–5.6 below appear to belong to "Domain 5: Context Management & Reliability" (inferred from the "5.x" numbering and from the Domains-reinforced mappings in Section 3, but the domain header itself is not visible within pages 21–31 — it precedes page 21).

### [Unlabeled tail of a preceding objective — heading not in range] (p.21, trailing bullets before Task Statement 5.3)
- Honoring explicit customer requests for human agents immediately without first attempting investigation
- Acknowledging frustration while offering resolution when the issue is within the agent's capability, escalating only if the customer reiterates their preference
- Escalating when policy is ambiguous or silent on the customer's specific request (e.g., competitor price matching when policy only addresses own-site adjustments)
- Instructing the agent to ask for additional identifiers when tool results return multiple matches, rather than selecting based on heuristics

### Task Statement 5.3: Implement error propagation strategies across multi-agent systems

**Knowledge of:**
- Structured error context (failure type, attempted query, partial results, alternative approaches) as enabling intelligent coordinator recovery decisions
- The distinction between access failures (timeouts needing retry decisions) and valid empty results (successful queries with no matches)
- Why generic error statuses ("search unavailable") hide valuable context from the coordinator
- Why silently suppressing errors (returning empty results as success) or terminating entire workflows on single failures are both anti-patterns

**Skills in:**
- Returning structured error context including failure type, what was attempted, partial results, and potential alternatives to enable coordinator recovery
- Distinguishing access failures from valid empty results in error reporting so the coordinator can make appropriate decisions
- Having subagents implement local recovery for transient failures and only propagate errors they cannot resolve, including what was attempted and partial results
- Structuring synthesis output with coverage annotations indicating which findings are well-supported versus which topic areas have gaps due to unavailable sources

### Task Statement 5.4: Manage context effectively in large codebase exploration

**Knowledge of:**
- Context degradation in extended sessions: models start giving inconsistent answers and referencing "typical patterns" rather than specific classes discovered earlier
- The role of scratchpad files for persisting key findings across context boundaries
- Subagent delegation for isolating verbose exploration output while the main agent coordinates high-level understanding
- Structured state persistence for crash recovery: each agent exports state to a known location, and the coordinator loads a manifest on resume

**Skills in:**
- Spawning subagents to investigate specific questions (e.g., "find all test files," "trace refund flow dependencies") while the main agent preserves high-level coordination
- Having agents maintain scratchpad files recording key findings, referencing them for subsequent questions to counteract context degradation
- Summarizing key findings from one exploration phase before spawning sub-agents for the next phase, injecting summaries into initial context
- Designing crash recovery using structured agent state exports (manifests) that the coordinator loads on resume and injects into agent prompts
- Using /compact to reduce context usage during extended exploration sessions when context fills with verbose discovery output

### Task Statement 5.5: Design human review workflows and confidence calibration

**Knowledge of:**
- The risk that aggregate accuracy metrics (e.g., 97% overall) may mask poor performance on specific document types or fields
- Stratified random sampling for measuring error rates in high-confidence extractions and detecting novel error patterns
- Field-level confidence scores calibrated using labeled validation sets for routing review attention
- The importance of validating accuracy by document type and field segment before automating high-confidence extractions

**Skills in:**
- Implementing stratified random sampling of high-confidence extractions for ongoing error rate measurement and novel pattern detection
- Analyzing accuracy by document type and field to verify consistent performance across all segments before reducing human review
- Having models output field-level confidence scores, then calibrating review thresholds using labeled validation sets
- Routing extractions with low model confidence or ambiguous/contradictory source documents to human review, prioritizing limited reviewer capacity

### Task Statement 5.6: Preserve information provenance and handle uncertainty in multi-source synthesis

**Knowledge of:**
- How source attribution is lost during summarization steps when findings are compressed without preserving claim-source mappings
- The importance of structured claim-source mappings that the synthesis agent must preserve and merge when combining findings
- How to handle conflicting statistics from credible sources: annotating conflicts with source attribution rather than arbitrarily selecting one value
- Temporal data: requiring publication/collection dates in structured outputs to prevent temporal differences from being misinterpreted as contradictions

**Skills in:**
- Requiring subagents to output structured claim-source mappings (source URLs, document names, relevant excerpts) that downstream agents preserve through synthesis
- Structuring reports with explicit sections distinguishing well-established findings from contested ones, preserving original source characterizations and methodological context
- Completing document analysis with conflicting values included and explicitly annotated, letting the coordinator decide how to reconcile before passing to synthesis
- Requiring subagents to include publication or data collection dates in structured outputs to enable correct temporal interpretation
- Rendering different content types appropriately in synthesis outputs — financial data as tables, news as prose, technical findings as structured lists — rather than converting everything to a uniform format

(This is the final task statement under Domain 5 as it appears in-range; page 23 transitions directly into Section 7 "How to Prepare" with no further numbered task statements before the end of page 31.)

## 5. Key concepts & terminology

- **Structured error context** — a returned payload (failure type, attempted query, partial results, alternative approaches) that lets a coordinator agent make informed recovery decisions (Task 5.3).
- **Access failures vs. valid empty results** — distinction between a timeout/failure needing retry vs. a successful query that legitimately found no matches (Task 5.3).
- **Anti-pattern: silent error suppression** — returning empty results as "success," hiding real failures (Task 5.3).
- **Anti-pattern: whole-workflow termination on single failure** — over-aggressive failure handling that kills the entire multi-agent workflow (Task 5.3).
- **Context degradation** — long-session phenomenon where models give inconsistent answers or hallucinate "typical patterns" instead of recalling specifics discovered earlier (Task 5.4).
- **Scratchpad files** — persistent files used by agents to record key findings across context boundaries/session limits (Task 5.4).
- **Subagent delegation for context isolation** — spawning subagents to absorb verbose exploration output so the main/coordinator agent's context stays high-level (Task 5.4).
- **Structured state persistence / manifest** — each agent exports state to a known location; coordinator loads a manifest on resume, enabling crash recovery (Task 5.4).
- **/compact** — Claude Code command to reduce/compress context usage during long sessions (Task 5.4, also Section 7).
- **Stratified random sampling** — sampling technique applied to high-confidence extractions to measure error rates and detect novel error patterns (Task 5.5).
- **Field-level confidence scores** — per-field model-output confidence values calibrated against labeled validation sets to route review attention (Task 5.5).
- **Aggregate accuracy metric risk** — a single overall accuracy number (e.g., 97%) can mask poor performance on specific document types/fields (Task 5.5).
- **Human review routing** — routing low-confidence or ambiguous/contradictory extractions to human reviewers, prioritizing limited capacity (Task 5.5).
- **Claim-source mapping** — structured linkage of a claim to its source (URL, document name, excerpt) preserved through synthesis to maintain provenance (Task 5.6).
- **Conflicting statistics annotation** — instead of arbitrarily picking one value from conflicting credible sources, annotate the conflict with source attribution (Task 5.6).
- **Temporal metadata (publication/collection dates)** — required in structured outputs to prevent temporal differences being misread as contradictions (Task 5.6).
- **Content-type-appropriate rendering** — financial data as tables, news as prose, technical findings as structured lists in synthesis output, rather than uniform formatting (Task 5.6).
- **Claude Agent SDK** — mentioned in "How to Prepare": build an agent implementing a complete agentic loop with tool calling, error handling, session management; practice spawning subagents and passing context (Section 7).
- **Agentic loop** — core pattern: tool calling + error handling + session management (Section 7, Exercise 1).
- **CLAUDE.md** — Claude Code configuration file; "configuration hierarchy" mentioned; project-level vs. path-specific rules (Section 7, Exercise 2).
- **.claude/rules/** — directory for path-specific rule files using YAML frontmatter with glob patterns (e.g., `paths: ["src/api/**/*"]`) to conditionally apply conventions (Section 7, Exercise 2, Sample Q6).
- **Custom skills / SKILL.md** — custom skills built with frontmatter options like `context: fork` and `allowed-tools`, stored in `.claude/skills/` (Section 7, Exercise 2, Sample Q6 option C).
- **MCP server integration** — configuring at least one MCP server; `.mcp.json` with environment variable expansion for credentials; personal experimental MCP server in `~/.claude.json` (Section 7, Exercise 2).
- **MCP tool descriptions** — writing tool descriptions that clearly differentiate similar tools to avoid selection confusion; central theme of Sample Questions 1 & 2 (Section 7, Exercise 1, Sample Qs).
- **Structured error responses (tools)** — error categories (transient/validation/permission) and `isRetryable` boolean plus human-readable descriptions (Section 7, Exercise 1).
- **tool_use with JSON schemas** — structured data extraction using tool_use, JSON schema design with optional/nullable fields (Section 7, Exercise 3).
- **Validation-retry loop** — on schema/Pydantic validation failure, send follow-up request including document, failed extraction, and specific validation error; distinguish resolvable (format mismatch) vs. unresolvable (info absent from source) errors (Section 7, Exercise 3).
- **Message Batches API** — batch processing API for submitting e.g. 100 documents, handling failures by `custom_id`, resubmitting failed documents, calculating processing time relative to SLA constraints (Section 7, Exercise 3).
- **Few-shot examples** — used for ambiguous scenarios / demonstrating extraction from varied document formats (Section 7, Exercise 3).
- **Multi-pass review architectures** — design pattern for large code reviews (Section 7).
- **Escalation and human-in-the-loop patterns** — when to escalate (policy gaps, customer requests, inability to progress) vs. resolve autonomously (Section 7).
- **stop_reason ("tool_use" / "end_turn")** — agentic loop control value the loop checks to decide whether to continue tool execution or present the final response (Exercise 1).
- **Programmatic hook** — intercepts tool calls to enforce a business rule (e.g., blocking operations above a threshold amount), redirecting to escalation workflow (Exercise 1).
- **Multi-concern messages** — test messages involving multiple issues that the agent must decompose, handle each, and synthesize a unified response (Exercise 1).
- **Plan mode vs. direct execution** — Claude Code modes tested on tasks of varying complexity (single-file bug fix, multi-file library migration, new feature with multiple valid approaches) (Exercise 2, Sample Q5).
- **Task tool / allowedTools** — coordinator's `allowedTools` must include "Task" to delegate to subagents; subagents receive research findings directly in prompt rather than relying on automatic context inheritance (Exercise 4).
- **Parallel subagent execution** — coordinator emits multiple Task tool calls in a single response; measuring latency improvement vs. sequential execution (Exercise 4).
- **Provenance-preserving structured output** — each finding includes claim, evidence excerpt, source URL/document name, publication date (Exercise 4).
- **claude -p flag** — non-interactive/print mode flag for running Claude Code in automated pipelines (e.g., CI), referenced in Sample Question 10: `claude -p "Analyze this pull request for security issues"`.
- **.claude/commands/** — directory for project-scoped custom slash commands (e.g., `/review`), version-controlled and shared across developers who clone/pull the repo (Sample Question 4).
- **~/.claude/commands/** — personal (per-developer, not version-controlled) custom slash commands directory (Sample Question 4, distractor).
- **routing classifier / routing layer** — appears as a distractor option in Sample Qs 1 and 2 for tool selection reliability (deemed over-engineered/addresses wrong problem).
- **verify_fact tool (scoped tool / least privilege)** — principle of giving an agent only the minimal tool needed for the common case (85% simple fact-checks) while preserving existing coordination pattern for complex cases (Sample Question 9).

## 6. Sample questions / item examples

Section header (p.27): "9. Sample Questions — The following sample questions illustrate the format and difficulty level of the exam. These are drawn from the practice test and include explanations to aid learning."

**Scenario: Customer Support Resolution Agent**

**Question 1:** "Production data shows that in 12% of cases, your agent skips get_customer entirely and calls lookup_order using only the customer's stated name, occasionally leading to misidentified accounts and incorrect refunds. What change would most effectively address this reliability issue?"
- A. Add a programmatic prerequisite that blocks lookup_order and process_refund calls until get_customer has returned a verified customer ID.
- B. Enhance the system prompt to state that customer verification via get_customer is mandatory before any order operations.
- C. Add few-shot examples showing the agent always calling get_customer first, even when customers volunteer order details.
- D. Implement a routing classifier that analyzes each request and enables only the subset of tools appropriate for that request type.

Correct Answer: A. "When a specific tool sequence is required for critical business logic (like verifying customer identity before processing refunds), programmatic enforcement provides deterministic guarantees that prompt-based approaches cannot. Options B and C rely on probabilistic LLM compliance, which is insufficient when errors have financial consequences. Option D addresses tool availability rather than tool ordering, which is not the actual problem."

**Question 2:** "Production logs show the agent frequently calls get_customer when users ask about orders (e.g., "check my order #12345"), instead of calling lookup_order. Both tools have minimal descriptions ("Retrieves customer information" / "Retrieves order details") and accept similar identifier formats. What's the most effective first step to improve tool selection reliability?"
- A. Add few-shot examples to the system prompt demonstrating correct tool selection patterns, with 5-8 examples showing order-related queries routing to lookup_order.
- B. Expand each tool's description to include input formats it handles, example queries, edge cases, and boundaries explaining when to use it versus similar tools.
- C. Implement a routing layer that parses user input before each turn and pre-selects the appropriate tool based on detected keywords and identifier patterns.
- D. Consolidate both tools into a single lookup_entity tool that accepts any identifier and internally determines which backend to query.

Correct Answer: B. "Tool descriptions are the primary mechanism LLMs use for tool selection. When descriptions are minimal, models lack the context to differentiate between similar tools. Option B directly addresses this root cause with a low-effort, high-leverage fix. Few-shot examples (A) add token overhead without fixing the underlying issue. A routing layer (C) is over-engineered and bypasses the LLM's natural language understanding. Consolidating tools (D) is a valid architectural choice but requires more effort than a "first step" warrants when the immediate problem is inadequate descriptions."

**Question 3:** "Your agent achieves 55% first-contact resolution, well below the 80% target. Logs show it escalates straightforward cases (standard damage replacements with photo evidence) while attempting to autonomously handle complex situations requiring policy exceptions. What's the most effective way to improve escalation calibration?"
- A. Add explicit escalation criteria to your system prompt with few-shot examples demonstrating when to escalate versus resolve autonomously.
- B. Have the agent self-report a confidence score (1-10) before each response and automatically route requests to humans when confidence falls below a threshold.
- C. Deploy a separate classifier model trained on historical tickets to predict which requests need escalation before the main agent begins processing.
- D. Implement sentiment analysis to detect customer frustration levels and automatically escalate when negative sentiment exceeds a threshold.

Correct Answer: A. "Adding explicit escalation criteria with few-shot examples directly addresses the root cause: unclear decision boundaries. This is the proportionate first response before adding infrastructure. Option B fails because LLM self-reported confidence is poorly calibrated—the agent is already incorrectly confident on hard cases. Option C is over-engineered, requiring labeled data and ML infrastructure when prompt optimization hasn't been tried. Option D solves a different problem entirely; sentiment doesn't correlate with case complexity, which is the actual issue."

**Scenario: Code Generation with Claude Code**

**Question 4:** "You want to create a custom /review slash command that runs your team's standard code review checklist. This command should be available to every developer when they clone or pull the repository. Where should you create this command file?"
- A. In the .claude/commands/ directory in the project repository
- B. In ~/.claude/commands/ in each developer's home directory
- C. In the CLAUDE.md file at the project root
- D. In a .claude/config.json file with a commands array

Correct Answer: A. "Project-scoped custom slash commands should be stored in the .claude/commands/ directory within the repository. These commands are version-controlled and automatically available to all developers when they clone or pull the repo. Option B (~/.claude/commands/) is for personal commands that aren't shared via version control. Option C (CLAUDE.md) is for project instructions and context, not command definitions. Option D describes a configuration mechanism that doesn't exist in Claude Code."

**Question 5:** "You've been assigned to restructure the team's monolithic application into microservices. This will involve changes across dozens of files and requires decisions about service boundaries and module dependencies. Which approach should you take?"
- A. Enter plan mode to explore the codebase, understand dependencies, and design an implementation approach before making changes.
- B. Start with direct execution and make changes incrementally, letting the implementation reveal the natural service boundaries.
- C. Use direct execution with comprehensive upfront instructions detailing exactly how each service should be structured.
- D. Begin in direct execution mode and only switch to plan mode if you encounter unexpected complexity during implementation.

Correct Answer: A. "Plan mode is designed for complex tasks involving large-scale changes, multiple valid approaches, and architectural decisions—exactly what monolith-to-microservices restructuring requires. It enables safe codebase exploration and design before committing to changes. Option B risks costly rework when dependencies are discovered late. Option C assumes you already know the right structure without exploring the code. Option D ignores that the complexity is already stated in the requirements, not something that might emerge later."

**Question 6:** "Your codebase has distinct areas with different coding conventions: React components use functional style with hooks, API handlers use async/await with specific error handling, and database models follow a repository pattern. Test files are spread throughout the codebase alongside the code they test (e.g., Button.test.tsx next to Button.tsx), and you want all tests to follow the same conventions regardless of location. What's the most maintainable way to ensure Claude automatically applies the correct conventions when generating code?"
- A. Create rule files in .claude/rules/ with YAML frontmatter specifying glob patterns to conditionally apply conventions based on file paths
- B. Consolidate all conventions in the root CLAUDE.md file under headers for each area, relying on Claude to infer which section applies
- C. Create skills in .claude/skills/ for each code type that include the relevant conventions in their SKILL.md files
- D. Place a separate CLAUDE.md file in each subdirectory containing that area's specific conventions

Correct Answer: A. "Option A is correct because .claude/rules/ with glob patterns (e.g., **/*.test.tsx) allows conventions to be automatically applied based on file paths regardless of directory location, essential for test files spread throughout the codebase. Option B relies on inference rather than explicit matching, making it unreliable. Option C requires manual skill invocation or relies on Claude choosing to load them, contradicting the need for deterministic "automatic" application based on file paths. Option D can't easily handle files spread across many directories since CLAUDE.md files are directory-bound."

**Scenario: Multi-Agent Research System**

**Question 7:** "After running the system on the topic "impact of AI on creative industries," you observe that each subagent completes successfully: the web search agent finds relevant articles, the document analysis agent summarizes papers correctly, and the synthesis agent produces coherent output. However, the final reports cover only visual arts, completely missing music, writing, and film production. When you examine the coordinator's logs, you see it decomposed the topic into three subtasks: "AI in digital art creation," "AI in graphic design," and "AI in photography." What is the most likely root cause?"
- A. The synthesis agent lacks instructions for identifying coverage gaps in the findings it receives from other agents.
- B. The coordinator agent's task decomposition is too narrow, resulting in subagent assignments that don't cover all relevant domains of the topic.
- C. The web search agent's queries are not comprehensive enough and need to be expanded to cover more creative industry sectors.
- D. The document analysis agent is filtering out sources related to non-visual creative industries due to overly restrictive relevance criteria.

Correct Answer: B. "The coordinator's logs reveal the root cause directly: it decomposed "creative industries" into only visual arts subtasks (digital art, graphic design, photography), completely omitting music, writing, and film. The subagents executed their assigned tasks correctly—the problem is what they were assigned. Options A, C, and D incorrectly blame downstream agents that are working correctly within their assigned scope."

**Question 8:** "The web search subagent times out while researching a complex topic. You need to design how this failure information flows back to the coordinator agent. Which error propagation approach best enables intelligent recovery?"
- A. Return structured error context to the coordinator including the failure type, the attempted query, any partial results, and potential alternative approaches.
- B. Implement automatic retry logic with exponential backoff within the subagent, returning a generic "search unavailable" status only after all retries are exhausted.
- C. Catch the timeout within the subagent and return an empty result set marked as successful.
- D. Propagate the timeout exception directly to a top-level handler that terminates the entire research workflow.

Correct Answer: A. "Structured error context gives the coordinator the information it needs to make intelligent recovery decisions—whether to retry with a modified query, try an alternative approach, or proceed with partial results. Option B's generic status hides valuable context from the coordinator, preventing informed decisions. Option C suppresses the error by marking failure as success, which prevents any recovery and risks incomplete research outputs. Option D terminates the entire workflow unnecessarily when recovery strategies could succeed."

**Question 9:** "During testing, you observe that the synthesis agent frequently needs to verify specific claims while combining findings. Currently, when verification is needed, the synthesis agent returns control to the coordinator, which invokes the web search agent, then re-invokes synthesis with results. This adds 2-3 round trips per task and increases latency by 40%. Your evaluation shows that 85% of these verifications are simple fact-checks (dates, names, statistics) while 15% require deeper investigation. What's the most effective approach to reduce overhead while maintaining system reliability?"
- A. Give the synthesis agent a scoped verify_fact tool for simple lookups, while complex verifications continue delegating to the web search agent through the coordinator.
- B. Have the synthesis agent accumulate all verification needs and return them as a batch to the coordinator at the end of its pass, which then sends them all to the web search agent at once.
- C. Give the synthesis agent access to all web search tools so it can handle any verification need directly without round-trips through the coordinator.
- D. Have the web search agent proactively cache extra context around each source during initial research, anticipating what the synthesis agent might need to verify.

Correct Answer: A. "Option A applies the principle of least privilege by giving the synthesis agent only what it needs for the 85% common case (simple fact verification) while preserving the existing coordination pattern for complex cases. Option B's batching approach creates blocking dependencies since synthesis steps may depend on earlier verified facts. Option C over-provisions the synthesis agent, violating separation of concerns. Option D relies on speculative caching that cannot reliably predict what the synthesis agent will need to verify."

**Scenario: Claude Code for Continuous Integration**

**Question 10:** "Your pipeline script runs claude "Analyze this pull request for security issues" but the job hangs indefinitely. Logs indicate Claude Code is waiting for interactive input. What's the correct approach to run Claude Code in an automated pipeline?"
- A. Add the -p flag: claude -p "Analyze this pull request for security issues"
- [Options B, C, D and the correct-answer rationale are NOT visible within pages 21–31 — cut off at end of range; likely continues on page 32.]

## 7. Recommended preparation / references

**Section 7. "How to Prepare"** (intro line, p.23): "To prepare for this certification exam:"

- "Build an agent with the Claude Agent SDK: implement a complete agentic loop with tool calling, error handling, and session management. Practice spawning subagents and passing context between them."
- "Configure Claude Code for a real project: set up CLAUDE.md with a configuration hierarchy, create path-specific rules in .claude/rules/, build custom skills with frontmatter options (context: fork, allowed-tools), and integrate at least one MCP server."
- "Design and test MCP tools: write tool descriptions that clearly differentiate similar tools. Implement structured error responses with error categories and retryable flags. Test tool selection reliability with ambiguous requests."
- "Build a structured data extraction pipeline: use tool_use with JSON schemas, implement validation-retry loops, design schemas with optional/nullable fields, and practice batch processing with the Message Batches API."
- "Practice prompt engineering techniques: write few-shot examples for ambiguous scenarios. Define explicit review criteria to reduce false positives. Design multi-pass review architectures for large code reviews."
- "Study context management patterns: practice extracting structured facts from verbose tool outputs, implementing scratchpad files for long sessions, and designing subagent delegation to manage context limits."
- "Review escalation and human-in-the-loop patterns: understand when to escalate (policy gaps, customer requests, inability to progress) versus resolve autonomously. Practice designing human review workflows with confidence-based routing."

**Section 8. "Preparation Exercises"** (intro line, p.24): "Complete these hands-on exercises to build practical familiarity with the topics covered on the exam. Each exercise is designed to reinforce knowledge across one or more exam domains."

- **Exercise 1: Build a Multi-Tool Agent with Escalation Logic**
  Objective: "Practice designing an agentic loop with tool integration, structured error handling, and escalation patterns."
  Steps:
  - "Define 3-4 MCP tools with detailed descriptions that clearly differentiate each tool's purpose, expected inputs, and boundary conditions. Include at least two tools with similar functionality that require careful description to avoid selection confusion."
  - "Implement an agentic loop that checks stop_reason to determine whether to continue tool execution or present the final response. Handle both "tool_use" and "end_turn" stop reasons correctly."
  - "Add structured error responses to your tools: include errorCategory (transient/validation/permission), isRetryable boolean, and human-readable descriptions. Test that the agent handles each error type appropriately (retrying transient errors, explaining business errors to the user)."
  - "Implement a programmatic hook that intercepts tool calls to enforce a business rule (e.g., blocking operations above a threshold amount), redirecting to an escalation workflow when triggered."
  - "Test with multi-concern messages (e.g., requests involving multiple issues) and verify the agent decomposes the request, handles each concern, and synthesizes a unified response."
  Domains reinforced: Domain 1 (Agentic Architecture & Orchestration), Domain 2 (Tool Design & MCP Integration), Domain 5 (Context Management & Reliability)

- **Exercise 2: Configure Claude Code for a Team Development Workflow**
  Objective: "Practice configuring CLAUDE.md hierarchies, custom slash commands, path-specific rules, and MCP server integration for a multi-developer project."
  Steps:
  - "Create a project-level CLAUDE.md with universal coding standards and testing conventions. Verify that instructions placed at the project level are consistently applied across all team members."
  - "Create .claude/rules/ files with YAML frontmatter glob patterns for different code areas (e.g., paths: ["src/api/**/*"] for API conventions, paths: ["**/*.test.*"] for testing conventions). Test that rules load only when editing matching files."
  - "Create a project-scoped skill in .claude/skills/ with context: fork and allowed-tools restrictions. Verify the skill runs in isolation without polluting the main conversation context."
  - "Configure an MCP server in .mcp.json with environment variable expansion for credentials. Add a personal experimental MCP server in ~/.claude.json and verify both are available simultaneously."
  - "Test plan mode versus direct execution on tasks of varying complexity: a single-file bug fix, a multi-file library migration, and a new feature with multiple valid implementation approaches. Observe when plan mode provides value."
  Domains reinforced: Domain 3 (Claude Code Configuration & Workflows), Domain 2 (Tool Design & MCP Integration)

- **Exercise 3: Build a Structured Data Extraction Pipeline**
  Objective: "Practice designing JSON schemas, using tool_use for structured output, implementing validation-retry loops, and designing batch processing strategies."
  Steps:
  - "Define an extraction tool with a JSON schema containing required and optional fields, an enum with an "other" + detail string pattern, and nullable fields for information that may not exist in source documents. Process documents where some fields are absent and verify the model returns null rather than fabricating values."
  - "Implement a validation-retry loop: when Pydantic or JSON schema validation fails, send a follow-up request including the document, the failed extraction, and the specific validation error. Track which errors are resolvable via retry (format mismatches) versus which are not (information absent from source)."
  - "Add few-shot examples demonstrating extraction from documents with varied formats (e.g., inline citations vs bibliographies, narrative descriptions vs structured tables) and verify improved handling of structural variety."
  - "Design a batch processing strategy: submit a batch of 100 documents using the Message Batches API, handle failures by custom_id, resubmit failed documents with modifications (e.g., chunking oversized documents), and calculate total processing time relative to SLA constraints."
  - "Implement a human review routing strategy: have the model output field-level confidence scores, route low-confidence extractions to human review, and analyze accuracy by document type and field to verify consistent performance."
  Domains reinforced: Domain 4 (Prompt Engineering & Structured Output), Domain 5 (Context Management & Reliability)

- **Exercise 4: Design and Debug a Multi-Agent Research Pipeline**
  Objective: "Practice orchestrating subagents, managing context passing, implementing error propagation, and handling synthesis with provenance tracking."
  Steps:
  - "Build a coordinator agent that delegates to at least two subagents (e.g., web search and document analysis). Ensure the coordinator's allowedTools includes "Task" and that each subagent receives its research findings directly in its prompt rather than relying on automatic context inheritance."
  - "Implement parallel subagent execution by having the coordinator emit multiple Task tool calls in a single response. Measure the latency improvement compared to sequential execution."
  - "Design structured output for subagents that separates content from metadata: each finding should include a claim, evidence excerpt, source URL/document name, and publication date. Verify that the synthesis subagent preserves source attribution when combining findings."
  - "Implement error propagation: simulate a subagent timeout and verify the coordinator receives structured error context (failure type, attempted query, partial results). Test that the coordinator can proceed with partial results and annotate the final output with coverage gaps."
  - "Test with conflicting source data (e.g., two credible sources with different statistics) and verify the synthesis output preserves both values with source attribution rather than arbitrarily selecting one, and structures the report to distinguish well-established from contested findings."
  Domains reinforced: Domain 1 (Agentic Architecture & Orchestration), Domain 2 (Tool Design & MCP Integration), Domain 5 (Context Management & Reliability)

## 8. Anomalies & notes

- Page 21 begins mid-list (four bullet points) with no visible parent heading in range — these bullets clearly belong to a Task Statement immediately preceding Task Statement 5.3 (very likely Task Statement 5.2, on escalation/customer-request handling), but its heading and "Knowledge of" section are out of range (handled by the prior/overlapping agent). Flagged rather than fabricated a heading.
- The domain header/name for Task Statements 5.3–5.6 (i.e., "Domain 5: Context Management & Reliability") is never explicitly printed within pages 21–31 as a section title — it is only inferable from (a) the "5.x" task numbering and (b) the "Domains reinforced" lines in Section 8, which repeatedly cite "Domain 5 (Context Management & Reliability)" alongside these topics.
- No explicit "Domain 5" section-opening page (with an overview paragraph, as domain sections typically have) appears in range — pages 21-23 pick up mid-domain and then move straight into Section 7 "How to Prepare," suggesting Task Statement 5.6 is the last task statement of the entire task-statement listing (i.e., Domain 5 is the final domain, and Section 7 begins immediately after).
- Question 10 (Scenario: "Claude Code for Continuous Integration") is truncated at the end of page 31 — only the stem and option A ("Add the -p flag: claude -p ...") are visible. Options B–D and the correct answer/rationale are out of range (page 32+). Flagged as incomplete rather than guessed.
- Sample Questions section states these items are "drawn from the practice test," implying a separate practice-test artifact exists outside this PDF (not otherwise described in range).
- No figures, tables, diagrams, or images appear in pages 21–31 — all content is text/bullets.
- Terms "isRetryable," "errorCategory," "custom_id," "stop_reason" appear as literal camelCase/snake_case identifiers in the source — preserved verbatim above since exam questions may test exact field/parameter names.
