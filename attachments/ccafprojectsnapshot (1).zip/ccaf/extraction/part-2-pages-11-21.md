# CCAF Exam Guide — Extraction Part 2 (pages 11–21)

## 1. Page ledger

- Page 11 (OVERLAP page, shared with neighboring agent — extracted per instructions): End of Domain 2 content — tail-end bullets of a preceding task statement's "Skills in" (tool_choice forced selection / tool_choice:"any" bullets), then full Task Statement 2.4 (Integrate MCP servers into Claude Code and agent workflows), then Task Statement 2.5 (Select and apply built-in tools) begins (Knowledge of only).
- Page 12: Task Statement 2.5 "Skills in" section (continued/concluded); Domain 3: Claude Code Configuration & Workflows (domain title); Task Statement 3.1 (Configure CLAUDE.md files) — Knowledge of and Skills in begin.
- Page 13: Task 3.1 "Skills in" concludes (/memory command bullet); Task Statement 3.2 (Create and configure custom slash commands and skills) full; Task Statement 3.3 (Apply path-specific rules) — Knowledge of begins.
- Page 14: Task 3.3 "Skills in" section; Task Statement 3.4 (Determine when to use plan mode vs direct execution) full; Task Statement 3.5 (Apply iterative refinement techniques) — Knowledge of begins.
- Page 15: Task 3.5 "Knowledge of"/"Skills in" continue and conclude; Task Statement 3.6 (Integrate Claude Code into CI/CD pipelines) — Knowledge of and Skills in begin.
- Page 16: Task 3.6 "Skills in" concludes (documenting testing standards bullet); Domain 4: Prompt Engineering & Structured Output (domain title); Task Statement 4.1 (Design prompts with explicit criteria) full; Task Statement 4.2 (Apply few-shot prompting) — Knowledge of begins.
- Page 17: Task 4.2 "Skills in" concludes; Task Statement 4.3 (Enforce structured output using tool use and JSON schemas) — Knowledge of and Skills in begin.
- Page 18: Task 4.3 "Skills in" concludes (format normalization bullet); Task Statement 4.4 (Implement validation, retry, and feedback loops) full; Task Statement 4.5 (Design efficient batch processing strategies) — Knowledge of begins.
- Page 19: Task 4.5 "Skills in" concludes; Task Statement 4.6 (Design multi-instance and multi-pass review architectures) full; Domain 5: Context Management & Reliability (domain title); Task Statement 5.1 (Manage conversation context) — Knowledge of begins.
- Page 20: Task 5.1 "Knowledge of"/"Skills in" continue and conclude; Task Statement 5.2 (Design effective escalation and ambiguity resolution patterns) — Knowledge of and Skills in begin.
- Page 21: Task 5.2 "Skills in" concludes; Task Statement 5.3 (Implement error propagation strategies across multi-agent systems) full; Task Statement 5.4 (Manage context effectively in large codebase exploration) begins — Knowledge of section is CUT OFF mid-list at page bottom (continues beyond page 21, into next agent's range).

## 2. Exam metadata (verbatim where possible)

NONE IN RANGE — pages 11–21 contain only domain/task-statement body content. Every page header reads "Claude Certification Program" (top-left, small caps) with "Exam guide" (top-right, gray). No exam-format metadata (question counts, duration, passing score, delivery method, prerequisites) appears in this page range.

## 3. Domains & weightings (VERBATIM)

No explicit "%" weighting figures appear anywhere in pages 11–21. Domain titles (verbatim, no weighting shown alongside them in this range):

- "Domain 3: Claude Code Configuration & Workflows" (page 12)
- "Domain 4: Prompt Engineering & Structured Output" (page 16)
- "Domain 5: Context Management & Reliability" (page 19)

Domain 2's title itself is NOT in range (it appears on an earlier page before page 11); only its tail-end task statements 2.4 and 2.5 appear here as a carry-over/overlap.

## 4. Objectives / skills measured (VERBATIM numbering and wording)

### [Domain 2 — title not in range] (continuation only)

**Task Statement 2.4: Integrate MCP servers into Claude Code and agent workflows**

Knowledge of:
- MCP server scoping: project-level (.mcp.json) for shared team tooling vs user-level (~/.claude.json) for personal/experimental servers
- Environment variable expansion in .mcp.json (e.g., ${GITHUB_TOKEN}) for credential management without committing secrets
- That tools from all configured MCP servers are discovered at connection time and available simultaneously to the agent
- MCP resources as a mechanism for exposing content catalogs (e.g., issue summaries, documentation hierarchies, database schemas) to reduce exploratory tool calls

Skills in:
- Configuring shared MCP servers in project-scoped .mcp.json with environment variable expansion for authentication tokens
- Configuring personal/experimental MCP servers in user-scoped ~/.claude.json
- Enhancing MCP tool descriptions to explain capabilities and outputs in detail, preventing the agent from preferring built-in tools (like Grep) over more capable MCP tools
- Choosing existing community MCP servers over custom implementations for standard integrations (e.g., Jira), reserving custom servers for team-specific workflows
- Exposing content catalogs as MCP resources to give agents visibility into available data without requiring exploratory tool calls

**Task Statement 2.5: Select and apply built-in tools (Read, Write, Edit, Bash, Grep, Glob) effectively**

Knowledge of:
- Grep for content search (searching file contents for patterns like function names, error messages, or import statements)
- Glob for file path pattern matching (finding files by name or extension patterns)
- Read/Write for full file operations; Edit for targeted modifications using unique text matching
- When Edit fails due to non-unique text matches, using Read + Write as a fallback for reliable file modifications

Skills in:
- Selecting Grep for searching code content across a codebase (e.g., finding all callers of a function, locating error messages)
- Selecting Glob for finding files matching naming patterns (e.g., **/*.test.tsx)
- Using Read to load full file contents followed by Write when Edit cannot find unique anchor text
- Building codebase understanding incrementally: starting with Grep to find entry points, then using Read to follow imports and trace flows, rather than reading all files upfront
- Tracing function usage across wrapper modules by first identifying all exported names, then searching for each name across the codebase

### Domain 3: Claude Code Configuration & Workflows

**Task Statement 3.1: Configure CLAUDE.md files with appropriate hierarchy, scoping, and modular organization**

Knowledge of:
- The CLAUDE.md configuration hierarchy: user-level (~/.claude/CLAUDE.md), project-level (.claude/CLAUDE.md or root CLAUDE.md), and directory-level (subdirectory CLAUDE.md files)
- That user-level settings apply only to that user—instructions in ~/.claude/CLAUDE.md are not shared with teammates via version control
- The @import syntax for referencing external files to keep CLAUDE.md modular (e.g., importing specific standards files relevant to each package)
- .claude/rules/ directory for organizing topic-specific rule files as an alternative to a monolithic CLAUDE.md

Skills in:
- Diagnosing configuration hierarchy issues (e.g., a new team member not receiving instructions because they're in user-level rather than project-level configuration)
- Using @import to selectively include relevant standards files in each package's CLAUDE.md based on maintainer domain knowledge
- Splitting large CLAUDE.md files into focused topic-specific files in .claude/rules/ (e.g., testing.md, api-conventions.md, deployment.md)
- Using the /memory command to verify which memory files are loaded and diagnose inconsistent behavior across sessions

**Task Statement 3.2: Create and configure custom slash commands and skills**

Knowledge of:
- Project-scoped commands in .claude/commands/ (shared via version control) vs user-scoped commands in ~/.claude/commands/ (personal)
- Skills in .claude/skills/ with SKILL.md files that support frontmatter configuration including context: fork, allowed-tools, and argument-hint
- The context: fork frontmatter option for running skills in an isolated sub-agent context, preventing skill outputs from polluting the main conversation
- Personal skill customization: creating personal variants in ~/.claude/skills/ with different names to avoid affecting teammates

Skills in:
- Creating project-scoped slash commands in .claude/commands/ for team-wide availability via version control
- Using context: fork to isolate skills that produce verbose output (e.g., codebase analysis) or exploratory context (e.g., brainstorming alternatives) from the main session
- Configuring allowed-tools in skill frontmatter to restrict tool access during skill execution (e.g., limiting to file write operations to prevent destructive actions)
- Using argument-hint frontmatter to prompt developers for required parameters when they invoke the skill without arguments
- Choosing between skills (on-demand invocation for task-specific workflows) and CLAUDE.md (always-loaded universal standards)

**Task Statement 3.3: Apply path-specific rules for conditional convention loading**

Knowledge of:
- .claude/rules/ files with YAML frontmatter paths fields containing glob patterns for conditional rule activation
- How path-scoped rules load only when editing matching files, reducing irrelevant context and token usage
- The advantage of glob-pattern rules over directory-level CLAUDE.md files for conventions that span multiple directories (e.g., test files spread throughout a codebase)

Skills in:
- Creating .claude/rules/ files with YAML frontmatter path scoping (e.g., paths: ["terraform/**/*"]) so rules load only when editing matching files
- Using glob patterns in path-specific rules to apply conventions to files by type regardless of directory location (e.g., **/*.test.tsx for all test files)
- Choosing path-specific rules over subdirectory CLAUDE.md files when conventions must apply to files spread across the codebase

**Task Statement 3.4: Determine when to use plan mode vs direct execution**

Knowledge of:
- Plan mode is designed for complex tasks involving large-scale changes, multiple valid approaches, architectural decisions, and multi-file modifications
- Direct execution is appropriate for simple, well-scoped changes (e.g., adding a single validation check to one function)
- Plan mode enables safe codebase exploration and design before committing to changes, preventing costly rework
- The Explore subagent for isolating verbose discovery output and returning summaries to preserve main conversation context

Skills in:
- Selecting plan mode for tasks with architectural implications (e.g., microservice restructuring, library migrations affecting 45+ files, choosing between integration approaches with different infrastructure requirements)
- Selecting direct execution for well-understood changes with clear scope (e.g., a single-file bug fix with a clear stack trace, adding a date validation conditional)
- Using the Explore subagent for verbose discovery phases to prevent context window exhaustion during multi-phase tasks
- Combining plan mode for investigation with direct execution for implementation (e.g., planning a library migration, then executing the planned approach)

**Task Statement 3.5: Apply iterative refinement techniques for progressive improvement**

Knowledge of:
- Concrete input/output examples as the most effective way to communicate expected transformations when prose descriptions are interpreted inconsistently
- Test-driven iteration: writing test suites first, then iterating by sharing test failures to guide progressive improvement
- The interview pattern: having Claude ask questions to surface considerations the developer may not have anticipated before implementing
- When to provide all issues in a single message (interacting problems) versus fixing them sequentially (independent problems)

Skills in:
- Providing 2-3 concrete input/output examples to clarify transformation requirements when natural language descriptions produce inconsistent results
- Writing test suites covering expected behavior, edge cases, and performance requirements before implementation, then iterating by sharing test failures
- Using the interview pattern to surface design considerations (e.g., cache invalidation strategies, failure modes) before implementing solutions in unfamiliar domains
- Providing specific test cases with example input and expected output to fix edge case handling (e.g., null values in migration scripts)
- Addressing multiple interacting issues in a single detailed message when fixes interact, versus sequential iteration for independent issues

**Task Statement 3.6: Integrate Claude Code into CI/CD pipelines**

Knowledge of:
- The -p (or --print) flag for running Claude Code in non-interactive mode in automated pipelines
- --output-format json and --json-schema CLI flags for enforcing structured output in CI contexts
- CLAUDE.md as the mechanism for providing project context (testing standards, fixture conventions, review criteria) to CI-invoked Claude Code
- Session context isolation: why the same Claude session that generated code is less effective at reviewing its own changes compared to an independent review instance

Skills in:
- Running Claude Code in CI with the -p flag to prevent interactive input hangs
- Using --output-format json with --json-schema to produce machine-parseable structured findings for automated posting as inline PR comments
- Including prior review findings in context when re-running reviews after new commits, instructing Claude to report only new or still-unaddressed issues to avoid duplicate comments
- Providing existing test files in context so test generation avoids suggesting duplicate scenarios already covered by the test suite
- Documenting testing standards, valuable test criteria, and available fixtures in CLAUDE.md to improve test generation quality and reduce low-value test output

### Domain 4: Prompt Engineering & Structured Output

**Task Statement 4.1: Design prompts with explicit criteria to improve precision and reduce false positives**

Knowledge of:
- The importance of explicit criteria over vague instructions (e.g., "flag comments only when claimed behavior contradicts actual code behavior" vs "check that comments are accurate")
- How general instructions like "be conservative" or "only report high-confidence findings" fail to improve precision compared to specific categorical criteria
- The impact of false positive rates on developer trust: high false positive categories undermine confidence in accurate categories

Skills in:
- Writing specific review criteria that define which issues to report (bugs, security) versus skip (minor style, local patterns) rather than relying on confidence-based filtering
- Temporarily disabling high false-positive categories to restore developer trust while improving prompts for those categories
- Defining explicit severity criteria with concrete code examples for each severity level to achieve consistent classification

**Task Statement 4.2: Apply few-shot prompting to improve output consistency and quality**

Knowledge of:
- Few-shot examples as the most effective technique for achieving consistently formatted, actionable output when detailed instructions alone produce inconsistent results
- The role of few-shot examples in demonstrating ambiguous-case handling (e.g., tool selection for ambiguous requests, branch-level test coverage gaps)
- How few-shot examples enable the model to generalize judgment to novel patterns rather than matching only pre-specified cases
- The effectiveness of few-shot examples for reducing hallucination in extraction tasks (e.g., handling informal measurements, varied document structures)

Skills in:
- Creating 2-4 targeted few-shot examples for ambiguous scenarios that show reasoning for why one action was chosen over plausible alternatives
- Including few-shot examples that demonstrate specific desired output format (location, issue, severity, suggested fix) to achieve consistency
- Providing few-shot examples distinguishing acceptable code patterns from genuine issues to reduce false positives while enabling generalization
- Using few-shot examples to demonstrate correct handling of varied document structures (inline citations vs bibliographies, methodology sections vs embedded details)
- Adding few-shot examples showing correct extraction from documents with varied formats to address empty/null extraction of required fields

**Task Statement 4.3: Enforce structured output using tool use and JSON schemas**

Knowledge of:
- Tool use (tool_use) with JSON schemas as the most reliable approach for guaranteed schema-compliant structured output, eliminating JSON syntax errors
- The distinction between tool_choice: "auto" (model may return text instead of calling a tool), "any" (model must call a tool but can choose which), and forced tool selection (model must call a specific named tool)
- That strict JSON schemas via tool use eliminate syntax errors but do not prevent semantic errors (e.g., line items that don't sum to total, values in wrong fields)
- Schema design considerations: required vs optional fields, enum fields with "other" + detail string patterns for extensible categories

Skills in:
- Defining extraction tools with JSON schemas as input parameters and extracting structured data from the tool_use response
- Setting tool_choice: "any" to guarantee structured output when multiple extraction schemas exist and the document type is unknown
- Forcing a specific tool with tool_choice: {"type": "tool", "name": "extract_metadata"} to ensure a particular extraction runs before enrichment steps
- Designing schema fields as optional (nullable) when source documents may not contain the information, preventing the model from fabricating values to satisfy required fields
- Adding enum values like "unclear" for ambiguous cases and "other" + detail fields for extensible categorization
- Including format normalization rules in prompts alongside strict output schemas to handle inconsistent source formatting

**Task Statement 4.4: Implement validation, retry, and feedback loops for extraction quality**

Knowledge of:
- Retry-with-error-feedback: appending specific validation errors to the prompt on retry to guide the model toward correction
- The limits of retry: retries are ineffective when the required information is simply absent from the source document (vs format or structural errors)
- Feedback loop design: tracking which code constructs trigger findings (detected_pattern field) to enable systematic analysis of dismissal patterns
- The difference between semantic validation errors (values don't sum, wrong field placement) and schema syntax errors (eliminated by tool use)

Skills in:
- Implementing follow-up requests that include the original document, the failed extraction, and specific validation errors for model self-correction
- Identifying when retries will be ineffective (e.g., information exists only in an external document not provided) versus when they will succeed (format mismatches, structural output errors)
- Adding detected_pattern fields to structured findings to enable analysis of false positive patterns when developers dismiss findings
- Designing self-correction validation flows: extracting "calculated_total" alongside "stated_total" to flag discrepancies, adding "conflict_detected" booleans for inconsistent source data

**Task Statement 4.5: Design efficient batch processing strategies**

Knowledge of:
- The Message Batches API: 50% cost savings, up to 24-hour processing window, no guaranteed latency SLA
- Batch processing is appropriate for non-blocking, latency-tolerant workloads (overnight reports, weekly audits, nightly test generation) and inappropriate for blocking workflows (pre-merge checks)
- The batch API does not support multi-turn tool calling within a single request (cannot execute tools mid-request and return results)
- custom_id fields for correlating batch request/response pairs

Skills in:
- Matching API approach to workflow latency requirements: synchronous API for blocking pre-merge checks, batch API for overnight/weekly analysis
- Calculating batch submission frequency based on SLA constraints (e.g., 4-hour windows to guarantee 30-hour SLA with 24-hour batch processing)
- Handling batch failures: resubmitting only failed documents (identified by custom_id) with appropriate modifications (e.g., chunking documents that exceeded context limits)
- Using prompt refinement on a sample set before batch-processing large volumes to maximize first-pass success rates and reduce iterative resubmission costs

**Task Statement 4.6: Design multi-instance and multi-pass review architectures**

Knowledge of:
- Self-review limitations: a model retains reasoning context from generation, making it less likely to question its own decisions in the same session
- Independent review instances (without prior reasoning context) are more effective at catching subtle issues than self-review instructions or extended thinking
- Multi-pass review: splitting large reviews into per-file local analysis passes plus cross-file integration passes to avoid attention dilution and contradictory findings

Skills in:
- Using a second independent Claude instance to review generated code without the generator's reasoning context
- Splitting large multi-file reviews into focused per-file passes for local issues plus separate integration passes for cross-file data flow analysis
- Running verification passes where the model self-reports confidence alongside each finding to enable calibrated review routing

### Domain 5: Context Management & Reliability

**Task Statement 5.1: Manage conversation context to preserve critical information across long interactions**

Knowledge of:
- Progressive summarization risks: condensing numerical values, percentages, dates, and customer-stated expectations into vague summaries
- The "lost in the middle" effect: models reliably process information at the beginning and end of long inputs but may omit findings from middle sections
- How tool results accumulate in context and consume tokens disproportionately to their relevance (e.g., 40+ fields per order lookup when only 5 are relevant)
- The importance of passing complete conversation history in subsequent API requests to maintain conversational coherence

Skills in:
- Extracting transactional facts (amounts, dates, order numbers, statuses) into a persistent "case facts" block included in each prompt, outside summarized history
- Extracting and persisting structured issue data (order IDs, amounts, statuses) into a separate context layer for multi-issue sessions
- Trimming verbose tool outputs to only relevant fields before they accumulate in context (e.g., keeping only return-relevant fields from order lookups)
- Placing key findings summaries at the beginning of aggregated inputs and organizing detailed results with explicit section headers to mitigate position effects
- Requiring subagents to include metadata (dates, source locations, methodological context) in structured outputs to support accurate downstream synthesis
- Modifying upstream agents to return structured data (key facts, citations, relevance scores) instead of verbose content and reasoning chains when downstream agents have limited context budgets

**Task Statement 5.2: Design effective escalation and ambiguity resolution patterns**

Knowledge of:
- Appropriate escalation triggers: customer requests for a human, policy exceptions/gaps (not just complex cases), and inability to make meaningful progress
- The distinction between escalating immediately when a customer explicitly demands it versus offering to resolve when the issue is straightforward
- Why sentiment-based escalation and self-reported confidence scores are unreliable proxies for actual case complexity
- How multiple customer matches require clarification (requesting additional identifiers) rather than heuristic selection

Skills in:
- Adding explicit escalation criteria with few-shot examples to the system prompt demonstrating when to escalate versus resolve autonomously
- Honoring explicit customer requests for human agents immediately without first attempting investigation
- Acknowledging frustration while offering resolution when the issue is within the agent's capability, escalating only if the customer reiterates their preference
- Escalating when policy is ambiguous or silent on the customer's specific request (e.g., competitor price matching when policy only addresses own-site adjustments)
- Instructing the agent to ask for additional identifiers when tool results return multiple matches, rather than selecting based on heuristics

**Task Statement 5.3: Implement error propagation strategies across multi-agent systems**

Knowledge of:
- Structured error context (failure type, attempted query, partial results, alternative approaches) as enabling intelligent coordinator recovery decisions
- The distinction between access failures (timeouts needing retry decisions) and valid empty results (successful queries with no matches)
- Why generic error statuses ("search unavailable") hide valuable context from the coordinator
- Why silently suppressing errors (returning empty results as success) or terminating entire workflows on single failures are both anti-patterns

Skills in:
- Returning structured error context including failure type, what was attempted, partial results, and potential alternatives to enable coordinator recovery
- Distinguishing access failures from valid empty results in error reporting so the coordinator can make appropriate decisions
- Having subagents implement local recovery for transient failures and only propagate errors they cannot resolve, including what was attempted and partial results
- Structuring synthesis output with coverage annotations indicating which findings are well-supported versus which topic areas have gaps due to unavailable sources

**Task Statement 5.4: Manage context effectively in large codebase exploration** — [CUT OFF at bottom of page 21; remainder of Knowledge of / all Skills in continues beyond page 21 into the next agent's range]

Knowledge of (partial, as captured within range):
- Context degradation in extended sessions: models start giving inconsistent answers and referencing "typical patterns" rather than specific classes discovered earlier
- The role of scratchpad files for persisting key findings across context boundaries
- [list truncated by page boundary — additional Knowledge of bullets and the entire Skills in section for 5.4 are NOT in this range]

## 5. Key concepts & terminology

- **MCP (Model Context Protocol) server** — external tool-providing server integrated into Claude Code; can be project- or user-scoped.
- **.mcp.json** — project-level config file for shared MCP servers, supports environment variable expansion (e.g., ${GITHUB_TOKEN}).
- **~/.claude.json** — user-level config file for personal/experimental MCP servers.
- **MCP resources** — mechanism for exposing content catalogs (issue summaries, documentation hierarchies, database schemas) to agents, reducing exploratory tool calls.
- **Grep** — built-in tool for content/pattern search across file contents (function names, error messages, imports).
- **Glob** — built-in tool for file path pattern matching (e.g., **/*.test.tsx).
- **Read / Write / Edit** — built-in file tools; Edit requires unique text anchors, Read+Write is the fallback when Edit's match isn't unique.
- **CLAUDE.md** — hierarchical configuration file: user-level (~/.claude/CLAUDE.md), project-level (.claude/CLAUDE.md or root), directory-level (subdirectory files).
- **@import syntax** — mechanism to modularize CLAUDE.md by referencing external standards files.
- **.claude/rules/** — directory for topic-specific rule files (e.g., testing.md, api-conventions.md, deployment.md), supports YAML frontmatter `paths` field with glob patterns for conditional loading.
- **/memory command** — verifies which memory files are loaded; used to diagnose inconsistent behavior across sessions.
- **.claude/commands/** vs **~/.claude/commands/** — project-scoped (shared via VCS) vs user-scoped (personal) slash commands.
- **.claude/skills/** and **SKILL.md** — skill definition files with frontmatter options: `context: fork`, `allowed-tools`, `argument-hint`.
- **context: fork** — frontmatter option running a skill in isolated sub-agent context to avoid polluting main conversation.
- **allowed-tools** — frontmatter restricting tool access during skill execution.
- **argument-hint** — frontmatter prompting for required parameters when a skill is invoked without arguments.
- **Plan mode** — mode for complex/architectural tasks enabling safe exploration before committing to changes.
- **Direct execution** — mode for simple, well-scoped changes.
- **Explore subagent** — isolates verbose discovery output, returns summaries to preserve main context.
- **Interview pattern** — Claude asks clarifying questions to surface unanticipated considerations before implementing.
- **Test-driven iteration** — writing tests first, iterating via shared test failures.
- **-p / --print flag** — runs Claude Code in non-interactive mode (prevents hangs in CI).
- **--output-format json / --json-schema** — CLI flags enforcing structured JSON output in CI.
- **Session context isolation** — same session that generated code is less effective reviewing its own changes vs. an independent instance.
- **Few-shot prompting** — using 2-4 targeted examples to improve consistency, reduce hallucination, and demonstrate ambiguous-case handling.
- **tool_use** — Claude's tool-calling mechanism used with JSON schemas for guaranteed schema-compliant output.
- **tool_choice** — parameter with values: "auto" (model may return text), "any" (must call a tool, any), forced/named (must call specific tool, e.g., {"type": "tool", "name": "extract_metadata"}).
- **Semantic errors vs schema syntax errors** — tool use eliminates JSON syntax errors but not semantic errors (e.g., line items not summing to total).
- **Enum + "other" + detail field pattern** — schema design for extensible categorization (e.g., "unclear", "other").
- **Retry-with-error-feedback** — appending validation errors to prompt on retry for model self-correction.
- **detected_pattern field** — tracks which code constructs trigger findings, enabling dismissal-pattern analysis.
- **calculated_total / stated_total / conflict_detected** — example fields for self-correction validation flows flagging discrepancies.
- **Message Batches API** — 50% cost savings, up to 24-hour processing window, no guaranteed latency SLA; no multi-turn tool calling mid-request.
- **custom_id** — field for correlating batch request/response pairs.
- **Multi-instance review** — using an independent Claude instance without generator's reasoning context to review code.
- **Multi-pass review** — per-file local analysis passes + cross-file integration passes to avoid attention dilution.
- **"Lost in the middle" effect** — models process beginning/end of long inputs reliably but may omit middle-section findings.
- **Case facts block** — persistent structured block of transactional facts (amounts, dates, order numbers, statuses) kept outside summarized history.
- **Escalation triggers** — explicit human requests, policy exceptions/gaps, inability to progress (not just "complexity" or sentiment/confidence scores).
- **Structured error context** — failure type, attempted query, partial results, alternatives, enabling coordinator recovery decisions.
- **Access failure vs valid empty result** — distinguishing timeouts/failures from legitimate no-match query results.
- **Scratchpad files** — used to persist key findings across context boundaries during large codebase exploration.

## 6. Sample questions / item examples

NONE IN RANGE — no example/sample exam questions, answer options, correct answers, or rationales appear anywhere in pages 11–21. Content is exclusively domain/task-statement "Knowledge of" / "Skills in" listings.

## 7. Recommended preparation / references

NONE IN RANGE — no references, reading lists, documentation links, or preparation guidance appear in pages 11–21.

## 8. Anomalies & notes

- Page 11 is a genuine content overlap with the neighboring (preceding) agent's range: it opens mid-list with two bullets that are the tail end of a "Skills in" section from a task statement whose full statement text is NOT in this range (only these two trailing bullets were visible): "Using tool_choice forced selection to ensure a specific tool is called first (e.g., forcing extract_metadata before enrichment tools), then processing subsequent steps in follow-up turns" and "Setting tool_choice: 'any' to guarantee the model calls a tool rather than returning conversational text." These almost certainly belong to a Domain 2 task statement preceding 2.4 (title/number not visible in this range).
- Domain 2's title/header text itself never appears in pages 11–21 — only its final two task statements (2.4, 2.5) are visible, confirming Domain 2 began on an earlier page (outside this agent's range).
- Task Statement 5.4 is truncated at the very bottom of page 21 — only the task title and the first two "Knowledge of" bullets are captured; the rest of its Knowledge of list and its entire Skills in list fall on page 22+ (outside this range, for the next agent to capture — page 21/22 boundary overlap should be checked by the downstream agent).
- No percentage weightings for any domain appear on any page in this range; if domain weightings exist in the exam guide, they are presented elsewhere (e.g., an earlier overview page before page 11).
- No numbered sub-objectives (e.g., "3.1.1", "3.1.2") are used — the hierarchy is strictly Domain → Task Statement (numbered X.Y) → "Knowledge of" (bulleted, unnumbered) → "Skills in" (bulleted, unnumbered).
- Every page in range carries the identical running header "Claude Certification Program" (left) and "Exam guide" (right), separated by a thin horizontal rule — treated as boilerplate, not content, and excluded from the ledger/objectives above.
