# W1R — Opus Review Gate: CCAF Canonical Objective Registry

**Reviewer:** W1R (opus), independent of W1/W1-patch
**Artifacts under review:** `/home/claude/work/ccaf/extraction/registry.json`, `/home/claude/work/ccaf/extraction/registry.md`
**Ground truth:** four extraction shards (`part-1-pages-01-11.md`, `part-2-pages-11-21.md`, `part-3-pages-21-31.md`, `part-4-pages-31-39.md`)
**PDF spot-check budget used:** 5 of 6 pages (pp. 3, 4, 19, 36, 37)
**Date:** 2026-08-01

**GATE VERDICT (revised 2026-08-01, post-remediation): PASS-WITH-MINORS**
*(original verdict: FAIL — see "Remediation Re-Verification" at the end of this document)*

Rationale in one line (as originally issued): the objective spine (5 domains / 30 task statements / 240 bullets / 12 questions / 6 scenarios / 18+16 scope bullets) is **100% verbatim-faithful and seam-clean**, but two blocks of source content were dropped **without an anomaly-ledger entry**, and the downstream contract ("tree built WITHOUT re-reading the PDF") makes them unrecoverable. Check 5 (honest anomaly ledger) fails; therefore the gate fails.

---

## CHECK 1 — Structural: **PASS**

Programmatic verification (`python3` over `registry.json`):

```
domains: 5
D1 'Agentic Architecture & Orchestration' 27 ['1.1'..'1.7']
D2 'Tool Design & MCP Integration'        18 ['2.1'..'2.5']
D3 'Claude Code Configuration & Workflows'20 ['3.1'..'3.6']
D4 'Prompt Engineering & Structured Output'20 ['4.1'..'4.6']
D5 'Context Management & Reliability'     15 ['5.1'..'5.6']
weight sum 100          K total 113   S total 127   (= 240 bullets)
sample_questions: 12 — each has stem, options {A,B,C,D}, correct ∈ {A,B}, non-empty rationale
scenarios: 6 — each has narrative (296–404 chars) + primary_domains
in_scope: 18   out_of_scope: 16
duplicate bullets across whole registry: 0
missing / extra / duplicate task_statement ids: none
```

Every task statement has **both** a non-empty `knowledge_of` and `skills_in` list (min 3 K / 3 S). Weight table verified against the PDF itself, not just the shard — **PDF p.3, Section 4 table**: `1 Agentic Architecture & Orchestration 27% | 2 Tool Design & MCP Integration 18% | 3 Claude Code Configuration & Workflows 20% | 4 Prompt Engineering & Structured Output 20% | 5 Context Management & Reliability 15% | Total 100%`. Registry `weight_pct` values 27/18/20/20/15 match exactly.

Question option/answer completeness, e.g. registry Q11 `correct: "A"` with 4 options — matches `part-4-pages-31-39.md:136-140`.

---

## CHECK 2 — Seam integrity: **PASS** (all four seams resolved, 0 dropped, 0 duplicated)

### Seam A — Task Statement 2.5 (page 11/12 boundary)

- Shard 1 (`part-1-pages-01-11.md:218`) — truncated: `"Knowledge of (partial — continues beyond page 11 / this range):"` followed by 3 bullets and `"- [Remainder of Task Statement 2.5 ... out of range]"` (line 222). **No Skills-in list at all.**
- Shard 2 (`part-2-pages-11-21.md:52-63`) — complete: 4 Knowledge bullets (adds `"When Edit fails due to non-unique text matches, using Read + Write as a fallback for reliable file modifications"`) + 5 Skills bullets.
- **Registry 2.5:** K=4, S=5. 4th K bullet present verbatim: `"When Edit fails due to non-unique text matches, using Read + Write as a fallback for reliable file modifications"`. First three K bullets appear **once each**, not twice (duplicate scan = 0). Truncation marker `[Remainder of Task Statement 2.5 …]` correctly **not** ingested as an objective.
  **Verdict: correct union, no duplication.**

### Seam B — Task Statement 5.4 (page 21/22 boundary)

- Shard 2 (`part-2-pages-11-21.md:284-289`): `"**Task Statement 5.4: Manage context effectively in large codebase exploration** — [CUT OFF at bottom of page 21…]"`, then only 2 K bullets and `"- [list truncated by page boundary — additional Knowledge of bullets and the entire Skills in section for 5.4 are NOT in this range]"`.
- Shard 3 (`part-3-pages-21-31.md:63-76`): complete — 4 K bullets, 5 S bullets.
- **Registry 5.4:** K=4 (`Context degradation…`, `The role of scratchpad files…`, `Subagent delegation for isolating verbose exploration output…`, `Structured state persistence for crash recovery…`), S=5 (ending `"Using /compact to reduce context usage during extended exploration sessions when context fills with verbose discovery output"`). Truncation marker not ingested; the 2 overlapping K bullets appear once.
  **Verdict: correct union, no duplication.**

### Seam C — Question 10 (page 31/32 boundary)

- Shard 3 (`part-3-pages-21-31.md:239-241`): stem + **option A only**, then `"- [Options B, C, D and the correct-answer rationale are NOT visible within pages 21–31 — cut off at end of range; likely continues on page 32.]"`.
- Shard 4 (`part-4-pages-31-39.md:128-133`): full stem, options A–D, `Correct Answer: A.` + rationale.
- **Registry Q10:** stem verbatim; A `"Add the -p flag: claude -p \"Analyze this pull request for security issues\""`; B `"Set the environment variable CLAUDE_HEADLESS=true before running the command"`; C `"Redirect stdin from /dev/null: …"`; D `"Add the --batch flag: …"`; `correct: A`; rationale verbatim (`"The -p (or --print) flag is the documented way…"`). Bracketed placeholder not ingested.
  **Verdict: correct.** (Same handling verified for the Q8/Q9 overlap: Q9 appears verbatim in BOTH `part-3:229-235` and `part-4:117-122`; registry contains exactly one Q9 — no duplication.)

### Seam D — page-21 trailing bullets

- Shard 3 (`part-3-pages-21-31.md:43-47`) presents them as an orphan: `"### [Unlabeled tail of a preceding objective — heading not in range] (p.21, trailing bullets before Task Statement 5.3)"` with 4 bullets beginning `"Honoring explicit customer requests for human agents immediately without first attempting investigation"`.
- Shard 2 (`part-2-pages-11-21.md:263-268`) shows these are **Skills-in bullets 2–5 of Task Statement 5.2**, under `"**Task Statement 5.2: Design effective escalation and ambiguity resolution patterns**"`, preceded by `"Adding explicit escalation criteria with few-shot examples to the system prompt…"`.
- **Registry 5.2:** S=5 — exactly `[Adding explicit escalation criteria…, Honoring explicit customer requests…, Acknowledging frustration…, Escalating when policy is ambiguous…, Instructing the agent to ask for additional identifiers…]`. No phantom "unlabeled objective" node exists anywhere in the registry; the 4 bullets appear once, attached to 5.2.
  **Verdict: correctly attributed, not double-counted, not dropped.**

---

## CHECK 3 — Fidelity sample: **PASS** (12 bullets + 3 questions, all VERBATIM)

First, the exhaustive machine check (stronger than a sample): every one of the **240** knowledge/skills bullets, **all 30** task-statement titles, **18** in-scope, **16** out-of-scope, **7** how-to-prepare bullets, and **all 12** question stems / 48 options / 12 rationales are exact whitespace-normalized substrings of the shard corpus. **0 mismatches.** Reverse direction: of the 268 objective bullets present in shard §4 sections, only **2** are absent from the registry, and both are truncation markers (`[Remainder of Task Statement 2.5 …]`, `[list truncated by page boundary …]`) — i.e. **0 real orphans**.

12 randomly sampled bullets (seed 20260801), registry line vs. shard line:

| # | Task | Kind | Registry text | Shard source |
|---|---|---|---|---|
| 1 | 1.5 | K | "Hook patterns (e.g., PostToolUse) that intercept tool results for transformation before the model processes them" | part-1:121 — identical |
| 2 | 1.6 | K | "Prompt chaining patterns that break reviews into sequential steps (e.g., analyze each file individually, then run a cross-file integration pass)" | part-1:134 — identical |
| 3 | 2.2 | K | "The distinction between transient errors (timeouts, service unavailability), validation errors (invalid input), business errors (policy violations), and permission errors" | part-1:176 — identical |
| 4 | 2.3 | S | "Replacing generic tools with constrained alternatives (e.g., replacing fetch_url with load_document that validates document URLs)" | part-1:196 — identical |
| 5 | 3.5 | S | "Writing test suites covering expected behavior, edge cases, and performance requirements before implementation, then iterating by sharing test failures" | part-2:132 — identical |
| 6 | 3.6 | K | "--output-format json and --json-schema CLI flags for enforcing structured output in CI contexts" | part-2:141 — identical |
| 7 | 4.1 | K | "The impact of false positive rates on developer trust: high false positive categories undermine confidence in accurate categories" | part-2:159 — identical |
| 8 | 4.3 | K | "Schema design considerations: required vs optional fields, enum fields with \"other\" + detail string patterns for extensible categories" | part-2:187 — identical |
| 9 | 5.6 | K | "The importance of structured claim-source mappings that the synthesis agent must preserve and merge when combining findings" | part-3:96 — identical |
| 10 | 5.5 | K | "The importance of validating accuracy by document type and field segment before automating high-confidence extractions" | part-3:84 — identical |
| 11 | 1.1 | S | "Implementing agentic loop control flow that continues when stop_reason is \"tool_use\" and terminates when stop_reason is \"end_turn\"" | part-1:74 — identical |
| 12 | 5.1 | S | "Placing key findings summaries at the beginning of aggregated inputs and organizing detailed results with explicit section headers to mitigate position effects" | part-2:251 — identical |

3 sampled questions — stem, all 4 options, and rationale each located verbatim:

- **Q3** (Customer Support Resolution Agent) — stem `part-3:177`, options A–D `part-3:178-181`, rationale `part-3:183`. Registry `correct: "A"`; shard reads `Correct Answer: A. "Adding explicit escalation criteria with few-shot examples directly addresses the root cause: unclear decision boundaries…"` — registry rationale identical (outer quotes stripped, which is correct de-quoting, not alteration).
- **Q6** (Code Generation with Claude Code) — stem `part-3:203`, options `part-3:204-207`, rationale `part-3:209`; `correct: "A"` matches `Correct Answer: A.`
- **Q11** (Claude Code for Continuous Integration) — stem `part-4:135`, options `part-4:136-139`, rationale `part-4:140`; `correct: "A"` matches.

**PDF-level corroboration (independent of shards):**
- Registry `in_scope[0]` = `"Agentic loop implementation: control flow based on stop_reason, tool result handling, loop termination conditions"` — **PDF p.37** reads exactly `"Agentic loop implementation: control flow based on stop_reason, tool result handling, loop termination conditions"`. ✔
- Registry `scenarios[S1].narrative` = `"You are building a customer support resolution agent using the Claude Agent SDK. The agent handles high-ambiguity requests like returns, billing disputes, and account issues. It has access to your backend systems through custom Model Context Protocol (MCP) tools (get_customer, lookup_order, process_refund, escalate_to_human). Your target is 80%+ first-contact resolution while knowing when to escalate."` — **PDF p.3** identical, word for word. ✔ All six narratives (S1 on p.3; S2–S6 on p.4) verified verbatim against the PDF, and all six `primary_domains` triples match the PDF's `Primary domains:` lines exactly (e.g. p.4 `"Primary domains: Tool Design & MCP Integration, Claude Code Configuration & Workflows, Agentic Architecture & Orchestration"` = registry S4 `["D2","D3","D1"]`, order preserved). **W1-patch's narrative work is clean.** ✔
- Registry 4.6 K/S bullets (K=3, S=3) match **PDF p.19** exactly, including `"Running verification passes where the model self-reports confidence alongside each finding to enable calibrated review routing"`. ✔

**registry.md ↔ registry.json consistency:** every JSON bullet, stem, rationale, narrative, and scope item is present in `registry.md`. 0 divergences.

---

## CHECK 4 — Semantic sanity: **PASS** (coherent; no contradictions)

- **Weights ↔ task-statement counts** are coherent: D1 27% / 7 tasks (largest of both), D3 20% / 6, D4 20% / 6, D5 15% / 6, D2 18% / 5 (smallest count). The one inversion (D5 15% with 6 tasks vs D2 18% with 5) is a source property, present in the PDF blueprint table itself, not an artifact of the merge.
- **Scenario → domain mappings ↔ question domain tags** are exactly consistent where questions exist:
  - S1 `[D1,D2,D5]` ← Q1 `D1` (programmatic prerequisite = Task 1.4), Q2 `D2` (tool descriptions = Task 2.1), Q3 `D5` (escalation calibration = Task 5.2). Question domain set == scenario domain set. ✔
  - S3 `[D1,D2,D5]` ← Q7 `D1` (coordinator decomposition = 1.2), Q8 `D5` (error propagation = 5.3), Q9 `D2` (scoped tool distribution = 2.3). Set-equal. ✔
  - S5 `[D3,D4]` ← Q10 `D3` (`-p` flag = 3.6), Q11 `D4` (Message Batches = 4.5), Q12 `D4` (multi-pass review = 4.6). Subset-consistent. ✔
  - S2 `[D3,D5]` ← Q4/Q5/Q6 all `D3`. Subset-consistent (D5 unexercised). ✔
  - S4, S6 have zero sample questions — **already disclosed** in the anomaly ledger as consistent with the "4 of 6 scenarios per sitting" structure. ✔
- **In-scope list ↔ domains:** all 18 in-scope bullets map cleanly onto the 5 domains with no orphans and no domain uncovered (D1: agentic loop / multi-agent orchestration / subagent context; D2: tool interface design / MCP tool+resource design / MCP server config / error handling; D3: CLAUDE.md / custom commands+skills / plan mode / iterative refinement; D4: structured output via tool_use / few-shot / batch processing; D5: escalation decision-making / context window optimization / human review workflows / information provenance).
- **Out-of-scope ↔ in-scope:** no bullet contradicts another. The one apparent tension — out-of-scope `"Rate limiting, quotas, or API pricing calculations"` vs. Q11's 50%-cost-savings reasoning and in-scope `"Batch processing: Message Batches API appropriateness, latency tolerance assessment"` — is not a contradiction: Q11 tests *qualitative* workflow/latency fit, not price computation. Recorded as a note, not a finding.
- **Metadata self-consistency:** `passing_scaled: 720` + `scale: "100-1000"` + `scoring_model` (criterion-referenced, domain percentages informational only) + `items: 60` + `duration_min: 120` + `exam_structure: "4 scenarios drawn from a bank of 6"` (matches PDF p.3 `"During the exam, 4 scenarios are presented and picked at random from the full set of the 6 scenarios below"`) + `validity_months: 12` + `document_version_history` (1.0 Jul 2026 / 0.2 Jun 2026 / 0.1 Feb 2026) — all mutually consistent, no arithmetic or date conflict.

---

## CHECK 5 — Anomaly ledger honesty: **FAIL**

Six anomalies are recorded, and the four inherited ones are honest and well-written — including two that W1-patch **resolved rather than buried**:

- Scenario-narrative gap: `"…RESOLVED by W1-patch: re-read PDF pp.3-4 directly and transcribed all 6 scenario narratives verbatim…All 6 primary_domains mappings…were independently confirmed"`. **I independently confirmed this against PDF pp.3–4 — the claim is true.** ✔
- Domain-5 overview gap: `"…RESOLVED by W1-patch: …NO domain in this guide has an overview/intro paragraph beyond its section heading — 'Domain 5: Context Management & Reliability' (Section 6) flows directly into 'Task Statement 5.1' with no intervening prose…"`. **I independently confirmed this against PDF p.19**, which shows `Domain 5: Context Management & Reliability` immediately followed by `Task Statement 5.1: Manage conversation context to preserve critical information across long interactions` and then `Knowledge of:` — zero intervening prose. The retraction of the original premise is honest and correct. ✔
- The prerequisites gap, the forward effective date, the 4-of-6 scenario asymmetry, and the IC-1 schema mismatch are all recorded truthfully.

**However, two omissions of real source content are absent from the ledger** (findings F-1 and F-2 below). Because the ledger's job is to make every gap visible to a downstream that never re-reads the PDF, silent omissions are exactly the failure mode this check exists to catch. **Check 5 fails, and with it the gate.**

---

## FINDINGS

### F-1 — MAJOR — Appendix "Technologies and Concepts" list (14 items) is entirely missing and undisclosed

**Evidence — source:** PDF **p.36**, Section 17 Appendix: `"Technologies and Concepts — The following list contains technologies and concepts that might appear on the exam:"` followed by 14 bullets running to p.37. Shard `part-4-pages-31-39.md:9-10` (page ledger) names them: `"Section '17. Appendix' begins with 'Technologies and Concepts' list (Claude Agent SDK, Model Context Protocol bullet items begin)"` … `"Continuation of 'Technologies and Concepts' list (Claude Code, Claude Code CLI, Claude API, Message Batches API, JSON Schema, Pydantic, Built-in tools, Few-shot prompting, Prompt chaining, Context window management, Session management, Confidence scoring)"`.

**Evidence — registry:** `list(registry.json.keys()) == ['exam_meta','domains','scenarios','sample_questions','in_scope','out_of_scope','how_to_prepare','preparation_exercises','anomalies']` — no key holds this list. String probes over the whole serialized registry: `"Technologies and Concepts"` → **not found**; `"Pydantic"` → **not found**. `registry.md` has sections 1–9 and none is the appendix technologies list.

**Why it matters (not merely cosmetic):** six concepts appear *only* in this list and **nowhere** in the registry's 240 bullets — probes returning NO: `max_tokens`, `strict mode`, `polling for completion`, `token budgets`, `agent definitions`, `named sessions`. A depth-4 tree built without re-reading the PDF therefore cannot generate a leaf for any of them, even though the guide says they "might appear on the exam."

**Exact fix:** add a top-level `technologies_and_concepts: []` array to `registry.json` (and a `## Appendix — Technologies and Concepts (14)` section to `registry.md`) with these 14 items, transcribed verbatim from PDF pp.36–37:
1. `Claude Agent SDK — agent definitions, agentic loops, stop_reason handling, hooks (PostToolUse, tool call interception), subagent spawning via Task tool, allowedTools configuration`
2. `Model Context Protocol (MCP) — MCP servers, MCP tools, MCP resources, isError flag, tool descriptions, tool distribution, .mcp.json configuration, environment variable expansion`
3. `Claude Code — CLAUDE.md configuration hierarchy (user/project/directory), .claude/rules/ with YAML frontmatter path-scoping, .claude/commands/ for slash commands, .claude/skills/ with SKILL.md frontmatter (context: fork, allowed-tools, argument-hint), plan mode, direct execution, /memory command, /compact, --resume, fork_session, Explore subagent`
4. `Claude Code CLI — -p / --print flag for non-interactive mode, --output-format json, --json-schema for structured CI output`
5. `Claude API — tool_use with JSON schemas, tool_choice options ("auto", "any", forced tool selection), stop_reason values ("tool_use", "end_turn"), max_tokens, system prompts`
6. `Message Batches API — 50% cost savings, up to 24-hour processing window, custom_id for request/response correlation, polling for completion, no multi-turn tool calling support`
7. `JSON Schema — required vs optional fields, enum types, nullable fields, "other" + detail string patterns, strict mode for syntax error elimination`
8. `Pydantic — schema validation, semantic validation errors, validation-retry loops`
9. `Built-in tools — Read, Write, Edit, Bash, Grep, Glob — their purposes and selection criteria`
10. `Few-shot prompting — targeted examples for ambiguous scenarios, format demonstration, generalization to novel patterns`
11. `Prompt chaining — sequential task decomposition into focused passes`
12. `Context window management — token budgets, progressive summarization, lost-in-the-middle effects, context extraction, scratchpad files`
13. `Session management — session resumption, fork_session, named sessions, session context isolation`
14. `Confidence scoring — field-level confidence, calibration with labeled validation sets, stratified sampling for error rate measurement`

Also add the list's lead-in verbatim: `"The following list contains technologies and concepts that might appear on the exam:"`. Then add an anomaly entry recording that this list was originally omitted and has been restored (with provenance: PDF pp.36–37, restored by W1R review).

---

### F-2 — MAJOR — All 20 Preparation-Exercise "Steps" are lossily paraphrased, and the paraphrase is undisclosed

**Evidence — source:** `part-3-pages-21-31.md:257-295` gives each of the 4 exercises a verbatim `Objective:` sentence **plus 5 verbatim `Steps:` bullets**, e.g. Exercise 2, step 2: `"Create .claude/rules/ files with YAML frontmatter glob patterns for different code areas (e.g., paths: [\"src/api/**/*\"] for API conventions, paths: [\"**/*.test.*\"] for testing conventions). Test that rules load only when editing matching files."`

**Evidence — registry:** `preparation_exercises[1].summary` = `"Practice configuring CLAUDE.md hierarchies, custom slash commands, path-specific rules, and MCP server integration for a multi-developer project: project-level CLAUDE.md, .claude/rules/ with YAML glob patterns, a project-scoped skill with context: fork and allowed-tools, an MCP server in .mcp.json plus a personal one in ~/.claude.json, and comparing plan mode vs direct execution across tasks of varying complexity."` Machine check: **0 of 4** exercise `summary` strings are substrings of the shard corpus — they are newly authored prose. (The leading `Objective:` clause *is* preserved verbatim up to the colon; everything after the colon is condensation.)

**Why it matters:** the registry is otherwise **100% verbatim** — this is the single undisclosed exception, so a downstream consumer will reasonably treat these summaries as quotable source text and will quote text that does not exist in the guide. Concrete detail is lost: `paths: ["src/api/**/*"]`, `paths: ["**/*.test.*"]`, `"a batch of 100 documents"`, `"at least two subagents"`, `"Measure the latency improvement compared to sequential execution"`, `"enum with an \"other\" + detail string pattern"`, `"Handle both \"tool_use\" and \"end_turn\" stop reasons correctly."`

**Exact fix:** change the schema to `preparation_exercises[]: {title, objective, steps: [...], domains_reinforced}` where `objective` is the verbatim `Objective:` sentence and `steps` is the 5 verbatim step strings, copied character-for-character from `part-3-pages-21-31.md` lines 260–264 (Ex 1), 270–274 (Ex 2), 280–284 (Ex 3), 290–294 (Ex 4). Keep `summary` only if explicitly labelled `summary_derived: true`. Mirror the change in `registry.md` §8. No PDF re-read needed — the verbatim text is already in the shard.

---

### F-3 — MINOR — `exam_meta` fields are editorial summaries with no verbatim/derived flag; `delivery` drifts in meaning

**Evidence — source:** `part-1-pages-01-11.md:25` — `- Delivery: "Proctored: online proctored and/or test center, per program policy"`.
**Evidence — registry:** `exam_meta.delivery` = `"Proctored: online proctoring or a Pearson VUE test center, per program policy; delivered by Pearson VUE"`. Machine check: this string is **not** a substring of any shard. `"and/or"` was narrowed to `"or"`, which changes the stated delivery options. `audience`, `scoring_model`, `effective_date`, and `retake_policy` are likewise synthesized (blends of pp.1–2 and pp.33–35) rather than quoted.

**Fix:** store the p.2 table value verbatim in `delivery` and move the Pearson VUE detail to a separate `delivery_notes` field; add `verbatim: false` (or a `_derived` sibling key) to `audience`, `scoring_model`, `effective_date`, `retake_policy` so downstream never quotes them as source text.

---

### F-4 — MINOR — Guide Sections 11–16 have no home in the registry and no ledger entry

**Evidence — source:** `part-4-pages-31-39.md:20-31` captures registration channel (`"Registration and scheduling are handled through the Anthropic Partner Academy and Pearson VUE"`), the 24-hour cancel/reschedule rule (`"You may cancel or reschedule up to 24 hours before your appointment. Changes made within 24 hours forfeit the exam fee."`), the ID requirement, the no-show policy, the appeals window (`"You may appeal a decision within 14 days…"`), the NDA, accommodations, support contacts, and privacy.
**Evidence — registry:** probes over the serialized registry: `"Partner Academy"` → not found; `"Confidentiality"` → not found; `"appeal"` → not found. Only `retake_policy`, `validity_months`, `scoring_model`, and a partial `delivery` survive.

**Fix:** either add an `exam_policies: {}` block carrying these verbatim strings, or — if the orchestrator judges policy content out of scope for the question tree — add an explicit anomaly entry stating the deliberate exclusion, so the omission is a decision on record rather than a silent loss.

---

### F-5 — MINOR — Section intro prose dropped without a ledger entry

**Evidence — source (all present in shards, none in registry):** Section 4 intro `"The exam blueprint defines the content domains measured… as determined through the job task analysis"` (`part-1:47`); Section 5 intro `"The exam uses scenario-based questions. Each scenario presents a realistic production context that frames a set of questions…"` (PDF p.3); Section 6 intro `"Each domain below lists the task statements tested, with the knowledge and skills measured against each. Exam items are written against these objectives."` (`part-1:62`); Section 9 intro `"…These are drawn from the practice test and include explanations to aid learning."` (`part-3:157`); Section 8 intro (`part-3:255`).
**Evidence — registry:** probes `"Each domain below lists"`, `"The exam blueprint defines"`, `"job task analysis"`, `"drawn from the practice test"` → all **not found**.

**Fix:** add a `section_intros: {}` map keyed by section number with these verbatim strings. Section 6's intro in particular (`"Exam items are written against these objectives"`) is the guide's own statement of the tree's grounding rule and is worth having verbatim.

---

### F-6 — MINOR — `sample_questions[].domains` is a derived mapping presented as data

**Evidence — source:** neither `part-3-pages-21-31.md:159-241` nor `part-4-pages-31-39.md:126-147` tags any question with a domain; the guide prints only `Scenario:` headers, stems, options, and rationales.
**Evidence — registry:** every question carries `"domains": ["D3"]` etc. I checked all 12 and the inferences are **correct** (Q1→D1/1.4, Q2→D2/2.1, Q3→D5/5.2, Q4-6→D3, Q7→D1/1.2, Q8→D5/5.3, Q9→D2/2.3, Q10→D3/3.6, Q11→D4/4.5, Q12→D4/4.6), so this is a labelling-provenance issue, not an accuracy one.

**Fix:** rename to `domains_derived` or add `"domains_source": "W1 inference; not printed in the guide"`, and record it in the anomaly ledger.

---

## FINDINGS SUMMARY

| Severity | Count | IDs |
|---|---|---|
| BLOCKER | 0 | — |
| MAJOR | 2 | F-1 (Appendix technologies list missing), F-2 (exercise steps paraphrased) |
| MINOR | 4 | F-3, F-4, F-5, F-6 |

## GATE VERDICT (as originally issued): **FAIL** — superseded, see next section

Failing check: **Check 5 (anomaly-ledger honesty)**, driven by F-1 and F-2 — two blocks of verbatim source content dropped with no ledger entry, in a pipeline whose downstream cannot re-read the PDF.

Checks 1–4 all PASS with quoted evidence; the merge quality is genuinely high (240/240 bullets verbatim, 0 duplicates, 0 orphans, all four seams correct, all six scenario narratives PDF-verified, all scenario→domain and question→domain mappings coherent). **This is a one-pass remediation, not a re-extraction:** F-1's replacement text is transcribed verbatim above from PDF pp.36–37, and F-2's replacement text already exists verbatim in `part-3-pages-21-31.md`. Apply F-1 and F-2 (and, cheaply, F-3–F-6), re-run the completeness ledger, and the registry should clear this gate as PASS.

---

# Remediation Re-Verification (W1R, 2026-08-01) — scope: fixes only

W1 applied F-1 through F-6. Re-verified programmatically.

**F-1 — CLOSED.** `registry.json` now has top-level `technologies_and_concepts = {lead_in, items}`. `lead_in` = `"The following list contains technologies and concepts that might appear on the exam:"` (verbatim, PDF p.36). `len(items) == 14`, heads in source order: Claude Agent SDK, Model Context Protocol (MCP), Claude Code, Claude Code CLI, Claude API, Message Batches API, JSON Schema, Pydantic, Built-in tools, Few-shot prompting, Prompt chaining, Context window management, Session management, Confidence scoring. **All 14 match my PDF pp.36–37 transcription character-for-character (0 divergences), and all 14 are mirrored in `registry.md`.** The six previously-orphaned terms (`max_tokens`, `strict mode`, `polling for completion`, `token budgets`, `agent definitions`, `named sessions`) are now present.

**F-2 — CLOSED (one residual, MINOR).** `preparation_exercises[]` restructured to `{title, domains_reinforced, steps}`; **20 steps total (5 per exercise), 20/20 verbatim substrings of `part-3-pages-21-31.md` (lines 260–294), 0 non-verbatim**, all 20 mirrored in `registry.md`. The authored `summary` paraphrase is gone. *Residual:* the verbatim `Objective:` sentence for each exercise (e.g. `"Practice designing an agentic loop with tool integration, structured error handling, and escalation patterns."`) is now absent from both JSON and MD — it previously survived as the head of the removed `summary`. → **F-7 (MINOR): add `objective` per exercise, verbatim from `part-3-pages-21-31.md:258, 268, 278, 288`.**

**F-3/F-4/F-5/F-6 — CLOSED (one residual, MINOR).** `exam_meta.delivery` restored to the verbatim p.2 table value `"Proctored: online proctored and/or test center, per program policy"` with Pearson VUE detail split into `delivery_notes`; synthesized fields carry `*_verbatim: false`. `exam_policies` added (11 verbatim policy fields + `_source`). `section_intros` added for Sections 4, 6, 8, 9. `sample_questions_domains_provenance` records the derived-mapping caveat. Two new anomaly entries record the F-1/F-2 and F-3–F-6 remediation (ledger now 8 entries). *Residual:* `section_intros` omits Section 5's scenarios intro (`"The exam uses scenario-based questions. Each scenario presents a realistic production context that frames a set of questions…"`, PDF p.3). → **F-8 (MINOR): add `section_intros["5"]`.**

**Regression check — nothing previously PASSing was broken.** `registry.json` parses. Domains 5; **weights sum 100**; **30 task statements, 30 unique IDs**; K=113 / S=127 = 240 bullets, **0 non-verbatim against the shard corpus**; **12 sample questions**, every one with 4 options A–D, a correct letter (Q10 still `A`) and a verbatim rationale — 0 broken; 6 scenarios, all with narrative + primary_domains; in_scope 18 / out_of_scope 16. `registry.md` still contains every JSON item.

**REVISED GATE VERDICT: PASS-WITH-MINORS.** Both MAJORs (F-1, F-2) are closed with verbatim evidence; F-3–F-6 closed. Residual: 2 MINOR (F-7 exercise objectives, F-8 Section 5 intro), neither of which blocks the depth-4 question tree. Registry is cleared to freeze as canonical input; apply F-7/F-8 opportunistically.
